from __future__ import annotations

from datetime import datetime
from pathlib import Path

from PySide6.QtCore import QDate, QObject, QThread, Qt, QTimer, Signal, Slot
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QComboBox,
    QDialog,
    QFileDialog,
    QFrame,
    QGridLayout,
    QGroupBox,
    QHeaderView,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QLayout,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QProgressBar,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QTextEdit,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

from app.audit import (
    StatusSummary,
    export_history,
    export_results,
    summarize_batch,
    summarize_history_record,
)
from app.batch import ReportWorker, build_execution_jobs
from app.history import HistoryStore
from app.models import BatchResult, ExecutionRequest, ExecutionResult
from app.path_builder import validate_competencia
from app.report_registry import ReportRegistry
from app.report_runner import ReportRunner
from app.result_inspector import format_row_count
from app.settings import load_settings, save_settings
from app.snowflake_session import SnowflakeSession


class StatusDetailDialog(QDialog):
    """Readable, application-styled detail window for execution status."""

    def __init__(self, summary: StatusSummary, parent: QWidget | None = None):
        super().__init__(parent)
        self.setObjectName("statusDetailDialog")
        self.setWindowTitle(f"Detalhes da execução — {summary.label}")
        self.setModal(True)
        self.setMinimumSize(560, 330)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 22, 24, 18)
        layout.setSpacing(12)

        heading = QHBoxLayout()
        badge = QLabel(summary.label)
        badge.setObjectName("dialogStatus")
        badge.setProperty("statusLevel", summary.level)
        heading.addWidget(badge)
        heading.addStretch(1)
        layout.addLayout(heading)

        title = QLabel(self._title_for(summary))
        title.setObjectName("dialogTitle")
        title.setWordWrap(True)
        layout.addWidget(title)

        details = QTextEdit()
        details.setObjectName("dialogDetails")
        details.setReadOnly(True)
        details.setPlainText(summary.detail)
        details.setMinimumHeight(160)
        layout.addWidget(details, 1)

        note = QLabel("O mesmo detalhamento também fica disponível no Log e no Histórico.")
        note.setObjectName("dialogNote")
        note.setWordWrap(True)
        layout.addWidget(note)

        buttons = QHBoxLayout()
        buttons.addStretch(1)
        ok_button = QPushButton("OK")
        ok_button.setObjectName("dialogOkButton")
        ok_button.setMinimumWidth(100)
        ok_button.setDefault(True)
        ok_button.clicked.connect(self.accept)
        buttons.addWidget(ok_button)
        layout.addLayout(buttons)

    @staticmethod
    def _title_for(summary: StatusSummary) -> str:
        if summary.level == "success":
            return "Processo devidamente concluído"
        if summary.level == "warning":
            return "Processo concluído com ocorrências para análise"
        if summary.level == "cancelled":
            return "Processo interrompido antes da conclusão"
        if summary.level == "failed":
            return "A execução não foi concluída"
        return "Execução em andamento"


class ApplicationMessageDialog(QDialog):
    """Readable application-styled dialog for confirmations and user messages."""

    def __init__(
        self,
        title: str,
        message: str,
        level: str = "info",
        parent: QWidget | None = None,
    ):
        super().__init__(parent)
        self.setObjectName("applicationMessageDialog")
        self.setWindowTitle(title)
        self.setModal(True)
        self.setMinimumSize(560, 300)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 22, 24, 18)
        layout.setSpacing(12)

        badge_text = {
            "success": "Concluído",
            "warning": "Atenção",
            "error": "Erro",
            "info": "Informação",
        }.get(level, "Informação")
        badge = QLabel(badge_text)
        badge.setObjectName("messageBadge")
        badge.setProperty("messageLevel", level)
        layout.addWidget(badge, 0, Qt.AlignmentFlag.AlignLeft)

        heading = QLabel(self._heading_for(title, level))
        heading.setObjectName("messageTitle")
        heading.setWordWrap(True)
        layout.addWidget(heading)

        details = QTextEdit()
        details.setObjectName("messageDetails")
        details.setReadOnly(True)
        details.setPlainText(message)
        details.setMinimumHeight(120)
        layout.addWidget(details, 1)

        buttons = QHBoxLayout()
        buttons.addStretch(1)
        ok_button = QPushButton("OK")
        ok_button.setObjectName("messageOkButton")
        ok_button.setMinimumWidth(100)
        ok_button.setDefault(True)
        ok_button.clicked.connect(self.accept)
        buttons.addWidget(ok_button)
        layout.addLayout(buttons)

    @staticmethod
    def _heading_for(title: str, level: str) -> str:
        if level == "success":
            return f"{title} com sucesso"
        if level == "error":
            return "Não foi possível concluir a operação"
        if level == "warning":
            return "Verifique as informações abaixo"
        return title


class QtBatchJob(QObject):
    report_started = Signal(object, int, int)
    log_message = Signal(str)
    report_finished = Signal(object)
    progress_changed = Signal(int)
    finished = Signal(object)
    failed = Signal(str)

    def __init__(self, service: ReportWorker):
        super().__init__()
        self.service = service

    @Slot()
    def run(self) -> None:
        self.service.on_report_started = self.report_started.emit
        self.service.on_log = self.log_message.emit
        self.service.on_report_finished = self.report_finished.emit
        self.service.on_progress_changed = self.progress_changed.emit
        try:
            result = self.service.run()
        except Exception as exc:  # defensive boundary for the Qt thread
            self.failed.emit(str(exc))
        else:
            self.finished.emit(result)


class MainWindow(QMainWindow):
    def __init__(self, registry: ReportRegistry, settings_path: Path, legacy_root: Path):
        super().__init__()
        self.registry = registry
        self.settings_path = Path(settings_path)
        self.legacy_root = Path(legacy_root)
        self.settings = load_settings(self.settings_path)
        self.thread: QThread | None = None
        self.job: QtBatchJob | None = None
        self.service: ReportWorker | None = None
        self.session: SnowflakeSession | None = None
        self.history = HistoryStore(self.settings_path.parent / "history.json")
        self.history_records: list[dict] = []
        self.visible_history_records: list[dict] = []
        self.current_results: list[ExecutionResult] = []
        self._status_summary = StatusSummary(
            level="idle",
            label="Pronto",
            detail="Nenhuma execução foi iniciada. Clique no status para consultar os detalhes.",
        )
        self.timer = QTimer(self)
        self.timer.setInterval(500)
        self.timer.timeout.connect(self._update_elapsed)
        self._build_ui()
        self._load_history()

    def _build_ui(self) -> None:
        root = QWidget(self)
        root.setObjectName("root")
        layout = QVBoxLayout(root)
        layout.setContentsMargins(16, 14, 16, 12)
        layout.setSpacing(12)
        layout.setSizeConstraint(QLayout.SizeConstraint.SetMinimumSize)

        header = QFrame()
        header.setObjectName("headerCard")
        header_layout = QHBoxLayout(header)
        header_layout.setContentsMargins(22, 16, 18, 16)
        title_box = QVBoxLayout()
        title = QLabel("Relatórios Corporativos")
        title.setObjectName("appTitle")
        subtitle = QLabel("Central de extração, acompanhamento e histórico")
        subtitle.setObjectName("appSubtitle")
        title_box.addWidget(title)
        title_box.addWidget(subtitle)
        header_layout.addLayout(title_box, 1)
        self.status_button = QPushButton("Pronto")
        self.status_button.setObjectName("statusButton")
        self.status_button.setMinimumWidth(190)
        self.status_button.setToolTip("Clique para consultar os detalhes do status")
        self.status_button.clicked.connect(self._show_status_detail)
        header_layout.addWidget(self.status_button, 0, Qt.AlignmentFlag.AlignVCenter)
        layout.addWidget(header)

        parameters = QGroupBox("Parâmetros da execução")
        parameter_grid = QGridLayout(parameters)
        parameter_grid.setColumnStretch(2, 1)
        parameter_grid.setHorizontalSpacing(10)
        parameter_grid.addWidget(QLabel("COMPETÊNCIA"), 0, 0)
        default_competencia = self.settings.competencia_padrao or QDate.currentDate().toString("yyyyMM")
        self.competencia = QLineEdit(default_competencia)
        self.competencia.setMaxLength(6)
        self.competencia.setFixedWidth(120)
        parameter_grid.addWidget(self.competencia, 1, 0)
        parameter_grid.addWidget(QLabel("DESTINO"), 0, 1)
        self.destination = QComboBox()
        self.destination.addItems(["Rede corporativa", "OneDrive"])
        self.destination.setCurrentIndex(0 if self.settings.active_destination == "network" else 1)
        self.destination.currentIndexChanged.connect(self._destination_changed)
        self.destination.setMinimumWidth(240)
        parameter_grid.addWidget(self.destination, 1, 1)
        parameter_grid.addWidget(QLabel("PASTA DE SAÍDA"), 0, 2)
        self.path_label = QLabel()
        self.path_label.setWordWrap(True)
        self.path_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.path_label.setObjectName("pathLabel")
        parameter_grid.addWidget(self.path_label, 1, 2)
        browse = QPushButton("Escolher pasta")
        browse.setFixedWidth(170)
        browse.clicked.connect(self._choose_path)
        parameter_grid.addWidget(browse, 1, 3)
        self.separate_rs_checkbox = QCheckBox("Separar EQTL_RS em Gerados_RS")
        self.separate_rs_checkbox.setChecked(self.settings.separate_rs)
        parameter_grid.addWidget(self.separate_rs_checkbox, 2, 0, 1, 4)
        layout.addWidget(parameters)
        self._destination_changed(self.destination.currentIndex())

        selections = QGridLayout()
        selections.setColumnStretch(0, 1)
        selections.setColumnStretch(1, 1)
        report_box = QGroupBox("Relatórios")
        report_layout = QVBoxLayout(report_box)
        report_hint = QLabel("Escolha um ou vários relatórios para a fila")
        report_hint.setObjectName("helperText")
        report_layout.addWidget(report_hint)
        self.report_list = QListWidget()
        self.report_list.setMinimumHeight(170)
        for definition in self.registry.all():
            item = QListWidgetItem(definition.name)
            item.setData(Qt.ItemDataRole.UserRole, definition.id)
            item.setCheckState(Qt.CheckState.Unchecked)
            self.report_list.addItem(item)
        self.report_list.itemChanged.connect(self._update_selection_metrics)
        report_layout.addWidget(self.report_list, 1)
        report_actions = QHBoxLayout()
        all_reports = QPushButton("Todos")
        all_reports.clicked.connect(lambda: self._set_all(self.report_list, Qt.CheckState.Checked))
        report_actions.addWidget(all_reports)
        clear_reports = QPushButton("Limpar")
        clear_reports.clicked.connect(lambda: self._set_all(self.report_list, Qt.CheckState.Unchecked))
        report_actions.addWidget(clear_reports)
        report_layout.addLayout(report_actions)
        selections.addWidget(report_box, 0, 0)

        dist_box = QGroupBox("Distribuidoras")
        dist_layout = QVBoxLayout(dist_box)
        dist_hint = QLabel("Selecione as bases que serão consultadas")
        dist_hint.setObjectName("helperText")
        dist_layout.addWidget(dist_hint)
        self.dist_list = QListWidget()
        self.dist_list.setMinimumHeight(170)
        for name in ("EQTL_MA", "EQTL_PA", "EQTL_PI", "EQTL_AL", "EQTL_AP", "EQTL_RS"):
            item = QListWidgetItem(name)
            item.setData(Qt.ItemDataRole.UserRole, name)
            item.setCheckState(Qt.CheckState.Checked)
            self.dist_list.addItem(item)
        self.dist_list.itemChanged.connect(self._update_selection_metrics)
        dist_layout.addWidget(self.dist_list, 1)
        dist_actions = QHBoxLayout()
        all_dist = QPushButton("Todas")
        all_dist.clicked.connect(lambda: self._set_all(self.dist_list, Qt.CheckState.Checked))
        dist_actions.addWidget(all_dist)
        clear_dist = QPushButton("Limpar")
        clear_dist.clicked.connect(lambda: self._set_all(self.dist_list, Qt.CheckState.Unchecked))
        dist_actions.addWidget(clear_dist)
        dist_layout.addLayout(dist_actions)
        selections.addWidget(dist_box, 0, 1)
        layout.addLayout(selections, 3)

        control = QGroupBox("Controle da execução")
        control_layout = QVBoxLayout(control)
        actions = QHBoxLayout()
        actions.addWidget(QLabel("Acompanhe o progresso e consulte o motivo de cada status."), 1)
        self.run_button = QPushButton("▶  Executar selecionados")
        self.run_button.setMinimumWidth(195)
        self.run_button.clicked.connect(self._run)
        actions.addWidget(self.run_button)
        self.cancel_button = QPushButton("Cancelar")
        self.cancel_button.setFixedWidth(120)
        self.cancel_button.setEnabled(False)
        self.cancel_button.clicked.connect(self._cancel)
        actions.addWidget(self.cancel_button)
        control_layout.addLayout(actions)

        metrics = QGridLayout()
        self.selected_reports_value = QLabel("0")
        self.selected_distributors_value = QLabel("0")
        self.elapsed_label = QLabel("00:00:00")
        metrics.addWidget(self._metric("RELATÓRIOS SELECIONADOS", self.selected_reports_value), 0, 0)
        metrics.addWidget(self._metric("DISTRIBUIDORAS", self.selected_distributors_value), 0, 1)
        metrics.addWidget(self._metric("TEMPO TOTAL", self.elapsed_label), 0, 2)
        metrics.setColumnStretch(0, 1)
        metrics.setColumnStretch(1, 1)
        metrics.setColumnStretch(2, 1)
        control_layout.addLayout(metrics)
        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        control_layout.addWidget(self.progress)
        self.status_detail = QLabel(self._status_summary.detail)
        self.status_detail.setObjectName("statusDetail")
        self.status_detail.setWordWrap(True)
        self.status_detail.setMaximumHeight(48)
        self.status_detail.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        control_layout.addWidget(self.status_detail)
        layout.addWidget(control)

        self.tabs = QTabWidget()
        log_page = QWidget()
        log_layout = QVBoxLayout(log_page)
        self.log = QTextEdit()
        self.log.setReadOnly(True)
        self.log.setPlaceholderText("As mensagens da execução aparecerão aqui...")
        log_layout.addWidget(self.log)
        self.tabs.addTab(log_page, "Log")

        results_page = QWidget()
        results_layout = QVBoxLayout(results_page)
        results_actions = QHBoxLayout()
        results_actions.addWidget(QLabel("Detalhes dos relatórios processados"), 1)
        self.export_results_button = QPushButton("Baixar resultados")
        self.export_results_button.clicked.connect(self._export_results)
        results_actions.addWidget(self.export_results_button)
        results_layout.addLayout(results_actions)
        self.results = QTableWidget(0, 8)
        self.results.setHorizontalHeaderLabels(
            ["Relatório", "Categoria", "Competência", "Status", "Detalhes", "Arquivo", "Duração", "Linhas"]
        )
        self.results.setAlternatingRowColors(True)
        self.results.verticalHeader().setDefaultSectionSize(30)
        self.results.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.results.cellClicked.connect(self._on_result_cell_clicked)
        results_layout.addWidget(self.results)
        self.tabs.addTab(results_page, "Resultados")

        history_page = QWidget()
        history_layout = QVBoxLayout(history_page)
        history_actions = QHBoxLayout()
        history_actions.addWidget(QLabel("Execuções armazenadas para auditoria e análise de desempenho"), 1)
        self.export_history_button = QPushButton("Baixar histórico")
        self.export_history_button.clicked.connect(self._export_history)
        history_actions.addWidget(self.export_history_button)
        history_layout.addLayout(history_actions)
        self.history_table = QTableWidget(0, 6)
        self.history_table.setHorizontalHeaderLabels(
            ["Início", "Competência", "Status", "Detalhes", "Tempo total", "Relatórios"]
        )
        self.history_table.setAlternatingRowColors(True)
        self.history_table.verticalHeader().setDefaultSectionSize(30)
        history_header = self.history_table.horizontalHeader()
        for column in (0, 1, 2, 4, 5):
            history_header.setSectionResizeMode(column, QHeaderView.ResizeMode.ResizeToContents)
        history_header.setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        self.history_table.setMinimumHeight(180)
        self.history_table.cellClicked.connect(self._on_history_cell_clicked)
        history_layout.addWidget(self.history_table)
        self.tabs.addTab(history_page, "Histórico")
        self.tabs.setMinimumHeight(220)
        layout.addWidget(self.tabs, 2)

        footer = QLabel("Relatórios Corporativos  •  execução segura e rastreável")
        footer.setObjectName("footer")
        layout.addWidget(footer)

        scroll = QScrollArea(self)
        scroll.setObjectName("contentScroll")
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setWidget(root)
        self.setCentralWidget(scroll)
        self.setWindowTitle("Relatórios Corporativos")
        screen = QApplication.primaryScreen()
        if screen is not None:
            available = screen.availableGeometry()
            width = max(800, min(1280, available.width() - 24))
            height = max(600, min(900, available.height() - 24))
        else:
            width, height = 1100, 760
        self.resize(width, height)
        self._update_selection_metrics()

    @staticmethod
    def _metric(title: str, value: QLabel) -> QFrame:
        card = QFrame()
        card.setObjectName("metricCard")
        card_layout = QVBoxLayout(card)
        card_layout.setContentsMargins(12, 8, 12, 8)
        caption = QLabel(title)
        caption.setObjectName("metricCaption")
        value.setObjectName("metricValue")
        card_layout.addWidget(caption)
        card_layout.addWidget(value)
        return card

    def _set_all(self, widget: QListWidget, state: Qt.CheckState) -> None:
        widget.blockSignals(True)
        try:
            for index in range(widget.count()):
                widget.item(index).setCheckState(state)
        finally:
            widget.blockSignals(False)
        self._update_selection_metrics()

    def _checked(self, widget: QListWidget) -> list[str]:
        return [
            widget.item(index).data(Qt.ItemDataRole.UserRole)
            for index in range(widget.count())
            if widget.item(index).checkState() == Qt.CheckState.Checked
        ]

    def _update_selection_metrics(self, *_args) -> None:
        if hasattr(self, "selected_reports_value"):
            self.selected_reports_value.setText(str(len(self._checked(self.report_list))))
            self.selected_distributors_value.setText(str(len(self._checked(self.dist_list))))

    def _destination_changed(self, index: int) -> None:
        self.path_label.setText(self.settings.output_root if index == 0 else self.settings.onedrive_root)

    def _choose_path(self) -> None:
        selected = QFileDialog.getExistingDirectory(self, "Escolher pasta de saída")
        if not selected:
            return
        if self.destination.currentIndex() == 0:
            self.settings.output_root = selected
        else:
            self.settings.onedrive_root = selected
        self.path_label.setText(selected)
        save_settings(self.settings, self.settings_path)

    def _active_root(self) -> str:
        if self.destination.currentIndex() == 0:
            return self.settings.output_root
        return self.settings.onedrive_root

    def _set_status_summary(self, summary: StatusSummary) -> None:
        self._status_summary = summary
        self.status_button.setText(summary.label)
        self.status_detail.setText(summary.detail)
        self.status_button.setProperty("statusLevel", summary.level)
        style = self.status_button.style()
        style.unpolish(self.status_button)
        style.polish(self.status_button)
        self.status_button.update()

    def _show_status_detail(self) -> None:
        self.status_detail.setText(self._status_summary.detail)
        dialog = StatusDetailDialog(self._status_summary, self)
        dialog.exec()

    def _show_message(self, title: str, message: str, level: str = "info") -> None:
        message_dialog = ApplicationMessageDialog(title, message, level, self)
        message_dialog.exec()

    def _run(self) -> None:
        try:
            competencia = validate_competencia(self.competencia.text())
        except ValueError as exc:
            self._show_message("Competência inválida", str(exc), "warning")
            return
        report_ids = tuple(self._checked(self.report_list))
        distributors = tuple(self._checked(self.dist_list))
        if not report_ids or not distributors:
            self._show_message(
                "Seleção incompleta",
                "Selecione pelo menos um relatório e uma distribuidora.",
                "warning",
            )
            return
        root_text = self._active_root().strip()
        if not root_text:
            self._show_message(
                "Destino não configurado",
                "Escolha uma pasta de saída antes de executar.",
                "warning",
            )
            return

        self.settings.competencia_padrao = competencia
        self.settings.active_destination = "network" if self.destination.currentIndex() == 0 else "onedrive"
        self.settings.separate_rs = self.separate_rs_checkbox.isChecked()
        save_settings(self.settings, self.settings_path)
        request = ExecutionRequest(
            competencia=competencia,
            report_ids=report_ids,
            distribuidoras=distributors,
            output_root=Path(root_text),
            onedrive_root=Path(self.settings.onedrive_root) if self.settings.onedrive_root else None,
            active_destination=self.settings.active_destination,
            separate_rs=self.settings.separate_rs,
        )
        jobs = build_execution_jobs(request, self.registry)
        self.session = SnowflakeSession()
        runner = ReportRunner(self.legacy_root, session=self.session)
        self.service = ReportWorker(runner, request, jobs)
        self.job = QtBatchJob(self.service)
        self.thread = QThread(self)
        self.job.moveToThread(self.thread)
        self.thread.started.connect(self.job.run)
        self.job.report_started.connect(self._on_report_started)
        self.job.log_message.connect(self._append_log)
        self.job.report_finished.connect(self._on_report_finished)
        self.job.progress_changed.connect(self.progress.setValue)
        self.job.finished.connect(self._on_batch_finished)
        self.job.failed.connect(self._on_worker_failed)
        self.job.finished.connect(self.thread.quit)
        self.job.failed.connect(self.thread.quit)
        self.thread.finished.connect(self._thread_finished)
        self.run_button.setEnabled(False)
        self.cancel_button.setEnabled(True)
        self.progress.setValue(0)
        self.current_results.clear()
        self.results.setRowCount(0)
        self.log.clear()
        self._set_status_summary(
            StatusSummary(
                level="running",
                label="Executando",
                detail="A execução foi iniciada. Clique no status para acompanhar a etapa atual.",
            )
        )
        self._append_log("Iniciando lote...")
        self.tabs.setCurrentIndex(0)
        self.timer.start()
        self.thread.start()

    def _cancel(self) -> None:
        if self.service is not None:
            self.service.cancel()
            self._set_status_summary(
                StatusSummary(
                    level="running",
                    label="Cancelando",
                    detail="Cancelamento solicitado; aguardando o relatório atual terminar de forma segura.",
                )
            )

    def _update_elapsed(self) -> None:
        if self.service is None:
            return
        self.elapsed_label.setText(self._format_seconds(self.service.elapsed_seconds))

    def _on_report_started(self, definition, index: int, total: int) -> None:
        self._set_status_summary(
            StatusSummary(
                level="running",
                label=f"Executando {index}/{total}",
                detail=f"Relatório atual: {definition.name}. O lote ainda está em processamento.",
            )
        )

    def _append_log(self, message: str) -> None:
        self.log.append(message)

    @staticmethod
    def _result_detail(result: ExecutionResult) -> str:
        if result.error:
            return result.error
        if result.message:
            return result.message
        if result.status == "success":
            return "Arquivo gerado conforme esperado."
        return "O relatório não foi concluído e não apresentou uma justificativa detalhada."

    def _on_report_finished(self, result: ExecutionResult) -> None:
        self.current_results.append(result)
        row = self.results.rowCount()
        self.results.insertRow(row)
        detail = self._result_detail(result)
        values = [
            result.report_name,
            result.category,
            result.competencia,
            result.status,
            detail,
            str(result.output_path or ""),
            self._format_seconds(result.duration_seconds),
            format_row_count(result.rows),
        ]
        for column, value in enumerate(values):
            item = QTableWidgetItem(value)
            if column in (3, 4):
                item.setToolTip(detail)
            self.results.setItem(row, column, item)

    def _on_result_cell_clicked(self, row: int, _column: int) -> None:
        if row >= len(self.current_results):
            return
        result = self.current_results[row]
        summary = summarize_batch((result,))
        self._set_status_summary(summary)
        self._show_status_detail()

    def _on_batch_finished(self, batch: BatchResult) -> None:
        if self.session is not None:
            self.session.close()
        if self.service is not None:
            self.history.append_batch(self.service.request, batch)
        summary = summarize_batch(batch.results, cancelled=batch.cancelled)
        self._set_status_summary(summary)
        self.elapsed_label.setText(self._format_seconds(batch.duration_seconds))
        self._append_log(f"Status final: {summary.label}")
        self._append_log(f"Tempo total: {self._format_seconds(batch.duration_seconds)}")
        self._load_history()
        self.tabs.setCurrentIndex(1)

    def _on_worker_failed(self, message: str) -> None:
        if self.session is not None:
            self.session.close()
        if self.service is not None and self.service.started_at is not None:
            finished_at = datetime.now()
            failed_batch = BatchResult(
                results=(),
                started_at=self.service.started_at.isoformat(timespec="seconds"),
                finished_at=finished_at.isoformat(timespec="seconds"),
                duration_seconds=self.service.elapsed_seconds,
            )
            self.history.append_batch(self.service.request, failed_batch, execution_error=message)
        summary = summarize_batch((), execution_error=message)
        self._set_status_summary(summary)
        self._append_log(f"Falha do worker: {message}")
        self._load_history()
        self.tabs.setCurrentIndex(0)

    def _thread_finished(self) -> None:
        self.timer.stop()
        self.run_button.setEnabled(True)
        self.cancel_button.setEnabled(False)
        self.job = None
        self.thread = None
        self.service = None

    def _load_history(self) -> None:
        self.history_records = self.history.load()
        self.visible_history_records = list(reversed(self.history_records[-20:]))
        self.history_table.setRowCount(0)
        for record in self.visible_history_records:
            row = self.history_table.rowCount()
            self.history_table.insertRow(row)
            summary = summarize_history_record(record)
            values = [
                record.get("started_at", ""),
                record.get("competencia", ""),
                summary.label,
                summary.detail,
                self._format_seconds(record.get("duration_seconds", 0)),
                str(len(record.get("results", []))),
            ]
            for column, value in enumerate(values):
                item = QTableWidgetItem(str(value))
                if column in (2, 3):
                    item.setToolTip(summary.detail)
                self.history_table.setItem(row, column, item)

    def _on_history_cell_clicked(self, row: int, _column: int) -> None:
        if row >= len(self.visible_history_records):
            return
        summary = summarize_history_record(self.visible_history_records[row])
        self._set_status_summary(summary)
        self._show_status_detail()

    @staticmethod
    def _default_export_name(prefix: str) -> str:
        return f"{prefix}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"

    def _export_results(self) -> None:
        if not self.current_results:
            self._show_message("Sem resultados", "Ainda não há resultados para baixar.")
            return
        filename, _ = QFileDialog.getSaveFileName(
            self,
            "Baixar resultados",
            self._default_export_name("resultados"),
            "Excel (*.xlsx);;CSV (*.csv)",
        )
        if not filename:
            return
        try:
            path = export_results(self.current_results, Path(filename))
        except Exception as exc:
            self._show_message("Falha ao exportar resultados", str(exc), "error")
            return
        self._show_message("Resultados baixados", f"Arquivo salvo em:\n{path}", "success")

    def _export_history(self) -> None:
        if not self.history_records:
            self._show_message("Histórico vazio", "Ainda não há histórico para baixar.")
            return
        filename, _ = QFileDialog.getSaveFileName(
            self,
            "Baixar histórico",
            self._default_export_name("historico"),
            "Excel (*.xlsx);;CSV (*.csv)",
        )
        if not filename:
            return
        try:
            path = export_history(self.history_records, Path(filename))
        except Exception as exc:
            self._show_message("Falha ao exportar histórico", str(exc), "error")
            return
        self._show_message("Histórico baixado", f"Arquivo salvo em:\n{path}", "success")

    @staticmethod
    def _format_seconds(seconds: float) -> str:
        total = max(0, int(seconds))
        hours, remainder = divmod(total, 3600)
        minutes, secs = divmod(remainder, 60)
        return f"{hours:02d}:{minutes:02d}:{secs:02d}"
