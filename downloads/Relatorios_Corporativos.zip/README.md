# Relatórios Desktop

Aplicativo Windows para executar os 16 relatórios Snowflake existentes, com seleção de competência, relatórios e distribuidoras, saída mensal, log, cronômetro, histórico e recursos de auditoria.

O status da execução fica disponível em um botão clicável. Ao selecionar **Concluído**, **Concluído com alerta**, **Falha na execução** ou **Execução cancelada**, o sistema apresenta a explicação registrada para o lote ou para o relatório selecionado.

As abas **Resultados** e **Histórico** possuem botões para baixar as informações em Excel (`.xlsx`) ou CSV (`.csv`), incluindo duração, quantidade de linhas, arquivo gerado, mensagens e motivos de falha.

## Teste no VS Code

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python app.py
```

Na primeira execução, use uma pasta local e apenas um relatório/distribuidora. A autenticação Snowflake será feita pelo navegador.

## Gerar o executável

Em um Windows com acesso ao Snowflake:

```powershell
.\build_windows.bat
```

O executável será criado em `dist\RelatoriosDesktop\RelatoriosDesktop.exe`. Distribua a pasta `dist\RelatoriosDesktop` inteira, pois ela contém as bibliotecas e os dados dos relatórios.

O pacote instala e valida o `keyring` antes da compilação. Essa dependência permite que o Snowflake reutilize o cache seguro da autenticação do navegador, evitando uma nova janela de login para cada distribuidora.

As consultas originais ficam em `relatorios/legado`. O arquivo `source_manifest.json` registra os hashes dos módulos usados para impedir alterações acidentais de SQL e regras de negócio.
