@echo off
setlocal
python -m pip install --upgrade pip
if errorlevel 1 exit /b 1
python -m pip install -r requirements.txt
if errorlevel 1 exit /b 1
python -m pip install pyinstaller
if errorlevel 1 exit /b 1
python -c "import keyring; print('keyring disponivel')"
if errorlevel 1 (
    echo ERRO: o keyring nao foi instalado. O executavel abriria varias autenticacoes Snowflake.
    exit /b 1
)
python -m PyInstaller --clean --noconfirm RelatoriosDesktop.spec
if errorlevel 1 exit /b 1
if not exist "dist\RelatoriosDesktop\RelatoriosDesktop.exe" exit /b 1
echo.
echo Executavel criado em dist\RelatoriosDesktop\RelatoriosDesktop.exe
echo Distribua a pasta dist\RelatoriosDesktop inteira.
endlocal
