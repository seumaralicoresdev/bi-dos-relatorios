# PyInstaller onedir specification for Windows.
from pathlib import Path

from PyInstaller.utils.hooks import collect_all, collect_submodules


project_root = Path(SPECPATH)
datas = [
    (str(project_root / "relatorios"), "relatorios"),
    (str(project_root / "ui"), "ui"),
    (str(project_root / "source_manifest.json"), "."),
    (str(project_root / "README.md"), "."),
]
binaries = []
hiddenimports = [
    "snowflake.connector.pandas_tools",
    "snowflake.connector.arrow_context",
]

snowflake_datas, snowflake_binaries, snowflake_hiddenimports = collect_all("snowflake.connector")
datas += snowflake_datas
binaries += snowflake_binaries
hiddenimports += snowflake_hiddenimports
hiddenimports += collect_submodules("snowflake")

# The external-browser authenticator discovers keyring backends dynamically.
# Bundle the backend explicitly so the token can be cached on Windows.
keyring_datas, keyring_binaries, keyring_hiddenimports = collect_all("keyring")
datas += keyring_datas
binaries += keyring_binaries
hiddenimports += keyring_hiddenimports
hiddenimports += collect_submodules("keyring")

a = Analysis(
    [str(project_root / "app.py")],
    pathex=[str(project_root)],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
)
pyz = PYZ(a.pure)
exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="RelatoriosDesktop",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=False,
)
coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=False,
    name="RelatoriosDesktop",
)
