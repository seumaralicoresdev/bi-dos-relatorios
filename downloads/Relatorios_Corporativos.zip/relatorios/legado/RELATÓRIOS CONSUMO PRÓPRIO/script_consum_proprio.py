import snowflake.connector
import pandas as pd
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

# -----------------------------
# Configuração
# -----------------------------
DISTRIBUIDORAS = {
   "EQTL_MA": "EQTL_MA",
   "EQTL_PA": "EQTL_PA",
   "EQTL_PI": "EQTL_PI",
   "EQTL_AL": "EQTL_AL",
   "EQTL_AP": "EQTL_AP",
   "EQTL_RS": "EQTL_RS",
}

MES_COMPET = "202608"

OUTPUT_PATH = Path(
    rf"\\CMRSPPRARQ02\Gerencia Corporativa de Receita\Executiva de Inteligência e Gestão\14 - COLABORADORES\Elias\relatorio\gerados\202608\Tributario\consumo_proprio_{MES_COMPET}.xlsx"
)

OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)

# -----------------------------
# Colunas numéricas reais do SQL
# -----------------------------
DECIMAL_COLS = ["BC_ICMS", "ICMS_TOTAL", "VALOR_TOTAL", "CONSUMO_FATURADO"]

# -----------------------------
# Conexão Snowflake
# -----------------------------
def get_connection():
    return snowflake.connector.connect(
        account="khb56279.us-east-1",
        user="elias.correa@equatorialenergia.com.br",
        authenticator="externalbrowser",
        warehouse="WH_EQTLINFO",
        database="EQTLINFO_PRD",
        schema="PUBLIC",
    )

# -----------------------------
# SQL Template
# -----------------------------
SQL_TEMPLATE = """
WITH BASE_ICMS AS (
    SELECT
        DOCUMENTO_IMPRESSAO,
        DOCUMENTO_CALCULO,
        SUM(BASE_IMPOSTO) AS SUM_BASE_IMPOSTO
    FROM EQTLINFO_PRD.{SCHEMA}.ITENS_FATURAMENTO
    WHERE TIPO_IMPOSTO = 'MW2'
      AND FLAG = 'R'
    GROUP BY
        DOCUMENTO_IMPRESSAO,
        DOCUMENTO_CALCULO
)
SELECT
    B.EMPRESA,
    COALESCE(B.CNPJ, COALESCE(E.CNPJ, E.CPF)) AS CNPJ_OU_CPF,
    COALESCE(B.NOME, E.NOME) AS RAZAO_SOCIAL,
    A.INSTALACAO,
    A.CONTA_CONTRATO,
    SUBSTR(A.FATURA,8) AS NUMERO,
    COALESCE(A.PARCEIRO_NEGOCIO,E.PARCEIRO_NEGOCIO) AS PARCEIRO_NEGOCIO,
    A.TIPO_CALCULO,
    CASE
        WHEN A.TIPO_CALCULO = 'CP' THEN 'PERIÓDICA'
        WHEN A.TIPO_CALCULO = 'CF' THEN 'DESLIGAMENTO'
    END AS TIPO_FATURAMENTO,
    CASE
        WHEN A.TIPO_CALCULO = 'CP' THEN '01'
        WHEN A.TIPO_CALCULO = 'CF' THEN '03'
    END AS COD_TP_FAT,
    A.FATURA,
    A.CONTRATO,
    A.DOCUMENTO_IMPRESSAO,
    CASE
        WHEN C.OPERANDO = 'FL_ISOLADO'
        THEN 'SISTEMA ISOLADO'
        ELSE 'SISTEMA INTERLIGADO'
    END AS TIPO_SISTEMA,
    B.SUBCLASSE AS CLASSE_CONSUMO,
    B.REGIONAL,
    B.DISTRITAL,
    B.SECCIONAL,
    B.MUNICIPIO,
    B.LOCALIDADE,
    B.ENDERECO,
    B.BAIRRO,
    B.NUMERO,
    B.COMPLEMENTO,
    B.COMPLEMENTO2,
    A.MES_COMPETENCIA AS COMPETENCIA,
    CASE
        WHEN A.MES_COMPETENCIA = A.MES_REFERENCIA
        THEN 'FATURA NORMAL'
        ELSE 'ESTORNO DE OUTRA REFERENCIA'
    END AS SITUACAO_DOCUMENTO,
    B.CLASSE_PRINCIPAL,
    A.TIPO_CALCULO AS CDC,
    D.SUM_BASE_IMPOSTO AS BC_ICMS,
    A.ICMS AS ICMS_TOTAL,
    A.VALOR_FATURA AS VALOR_TOTAL,
    A.CONSUMO_FATURADO
FROM EQTLINFO_PRD.{SCHEMA}.FATURAMENTO A
LEFT JOIN EQTLINFO_PRD.{SCHEMA}.FOTO_CADASTRO B
       ON A.INSTALACAO = B.INSTALACAO
      AND TO_VARCHAR(B.MES_COMPETENCIA,'YYYYMM') = A.MES_REFERENCIA
LEFT JOIN EQTLINFO_PRD.{SCHEMA}.TAB_OPERANDOS_MEDICAO C
       ON A.INSTALACAO = C.INSTALACAO
      AND TO_DATE(A.MES_REFERENCIA||'01','YYYYMMDD')
          BETWEEN TO_DATE(C.DATA_DE,'YYYYMMDD')
          AND TO_DATE(C.DATA_ATE,'YYYYMMDD')
      AND C.OPERANDO = 'FL_ISOLADO'
LEFT JOIN BASE_ICMS D
       ON A.DOCUMENTO_CALCULO = D.DOCUMENTO_CALCULO
      AND A.DOCUMENTO_IMPRESSAO = D.DOCUMENTO_IMPRESSAO
LEFT JOIN EQTLINFO_PRD.{SCHEMA}.TAB_PARCEIRO_NEGOCIO E
       ON A.PARCEIRO_NEGOCIO = E.PARCEIRO_NEGOCIO
WHERE
      A.MES_COMPETENCIA = '{MES_COMPET}'
  AND A.TIPO_CALCULO IN ('CP','CF')
  AND SUBSTR(A.SUBCLASSE,1,2) = 'CP'
  AND A.ESTORNO_PLENO IS NULL
"""

# -----------------------------
# Execução SQL paralela e otimizada
# -----------------------------
def run_query(empresa_nome, schema):
    print(f"[Iniciando] Carga: {empresa_nome} (schema: {schema})...")
    conn = get_connection()
    cur = conn.cursor()

    try:
        sql = SQL_TEMPLATE.format(
            SCHEMA=schema,
            MES_COMPET=MES_COMPET
        )
        cur.execute(sql)

        # Download binário nativo ultra rápido direto para o DataFrame Pandas
        df = cur.fetch_pandas_all()

        if df.empty:
            print(f"[Atenção] {empresa_nome} sem registros.")
            return empresa_nome, df

        # Padronizar nomes de colunas em caixa alta
        df.columns = [col.upper() for col in df.columns]

        # Ajuste de colunas numéricas de forma segura
        for col in DECIMAL_COLS:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors="coerce").round(2)

        # Remover timezone ativo para evitar quebra do xlsxwriter
        tz_cols = df.select_dtypes(include=["datetimetz"]).columns
        for col in tz_cols:
            df[col] = df[col].dt.tz_localize(None)

        print(f"[Sucesso] {empresa_nome} → {len(df):,} registros carregados.")
        return empresa_nome, df

    except Exception as e:
        print(f"[Erro] Falha ao processar a distribuidora {empresa_nome}: {e}")
        return empresa_nome, pd.DataFrame()

    finally:
        cur.close()
        conn.close()

# -----------------------------
# Pipeline principal
# -----------------------------
def main():
    resultados = {}

    print("Disparando extrações simultâneas de Consumo Próprio para o Snowflake...")
    # Executa todas as distribuidoras do dicionário estritamente juntas em paralelo
    with ThreadPoolExecutor(max_workers=len(DISTRIBUIDORAS)) as executor:
        futures = {
            executor.submit(run_query, nome, schema): nome
            for nome, schema in DISTRIBUIDORAS.items()
        }

        for future in as_completed(futures):
            empresa = futures[future]
            try:
                empresa_nome, df = future.result()
                resultados[empresa_nome] = df
            except Exception as e:
                print(f"[Erro crítico] A thread de extração da empresa {empresa} gerou um erro: {e}")

    # -----------------------------
    # Exportação Excel Consolidada
    # -----------------------------
    print("\nGerando arquivo Excel consolidado na rede...")
    if resultados and any(not df.empty for df in resultados.values()):
        with pd.ExcelWriter(OUTPUT_PATH, engine="xlsxwriter") as writer:
            for empresa, df in resultados.items():
                if df.empty:
                    continue
                sheet = empresa[:31]
                df.to_excel(writer, sheet_name=sheet, index=False)
        print(f"✔ Arquivo criado com sucesso!")
    else:
        print("\n[Aviso] Nenhuma informação útil retornou para salvar na planilha.")

    print(f"\nProcesso finalizado. Destino:\n{OUTPUT_PATH}")

# -----------------------------
# Entrypoint
# -----------------------------
if __name__ == "__main__":
    main()
