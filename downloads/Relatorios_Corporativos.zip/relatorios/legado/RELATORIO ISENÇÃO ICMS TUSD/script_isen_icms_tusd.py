import snowflake.connector
import pandas as pd
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

# -----------------------------
# Configuração
# -----------------------------
DISTRIBUIDORAS = {
    "EQTL_MA": "EQTL_MA",
    "EQTL_PA": "EQTL_PA",
    "EQTL_PI": "EQTL_PI",
    "EQTL_AL": "EQTL_AL",
    "EQTL_AP": "EQTL_AP",
    "EQTL_RS": "EQTL_RS",
}

MAX_THREADS = 6
MES_COMPET = "202608"

OUTPUT_PATH = Path(
    rf"\\CMRSPPRARQ02\Gerencia Corporativa de Receita\Executiva de Inteligência e Gestão\14 - COLABORADORES\Elias\relatorio\gerados\202608\Tributario\isencao_icms_tusd_{MES_COMPET}.xlsx"
)

OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)

# -----------------------------
# Conexão Snowflake
# -----------------------------
def get_connection():
    return snowflake.connector.connect(
        account="khb56279.us-east-1",
        user="elias.correa@equatorialenergia.com.br",
        authenticator="externalbrowser",
        warehouse="WH_EQTLINFO",
        database="EQTLINFO_PRD",
        schema="PUBLIC",
    )

# -----------------------------
# SQL
# -----------------------------
SQL_TEMPLATE = """
WITH BASE AS (
    SELECT
        '{EMP}' AS EMPRESA,
        A.MES_COMPETENCIA,
        C.MES_REFERENCIA,
        B.COD_MUNICIPIO AS MUNICIPIO,
        C.INSTALACAO,
        C.CONTA_CONTRATO,
        D.NOME,
        D.CPF,
        D.CNPJ,
        C.GRUPO,
        C.CATEGORIA_TARIFA AS TARIFA,

        CASE
            WHEN C.SUBCLASSE IN ('REPLN','REBXR') THEN 'RESIDENCIAL'
            WHEN C.SUBCLASSE IN ('COMER','COMOS') THEN 'COMERCIAL'
            ELSE 'OUTROS'
        END AS CLASSE,

        A.RECEITA,
        C.ICMS,
        C.VALOR_FATURA

    FROM EQTLINFO_PRD.{SCHEMA}.ITENS_FATURAMENTO A

    LEFT JOIN EQTLINFO_PRD.{SCHEMA}.SIGLA_MUNICIPIOS B
        ON SUBSTR(A.DOMICILIO_FISCAL,4,7) = B.COD_MUNICIPIO

    LEFT JOIN EQTLINFO_PRD.{SCHEMA}.FATURAMENTO C
        ON A.DOCUMENTO_IMPRESSAO = C.DOCUMENTO_IMPRESSAO

    LEFT JOIN EQTLINFO_PRD.{SCHEMA}.TAB_CADASTRO D
        ON C.INSTALACAO = D.INSTALACAO
       AND C.CONTA_CONTRATO = D.CONTA_CONTRATO

    WHERE
        A.OPERACAO = '0153'
        AND A.MES_COMPETENCIA BETWEEN
            TO_VARCHAR(DATEADD(MONTH,-3,CURRENT_DATE()),'YYYYMM')
        AND TO_VARCHAR(DATEADD(MONTH,-1,CURRENT_DATE()),'YYYYMM')
)
SELECT
    EMPRESA,
    MES_COMPETENCIA,
    MES_REFERENCIA,
    MUNICIPIO,
    INSTALACAO,
    CONTA_CONTRATO,
    NOME,
    CPF,
    CNPJ,
    GRUPO,
    TARIFA,
    CLASSE,
    SUM(RECEITA) AS REDUCAO,
    SUM(ICMS) AS ICMS,
    VALOR_FATURA
FROM BASE
GROUP BY
    EMPRESA,
    MES_COMPETENCIA,
    MES_REFERENCIA,
    MUNICIPIO,
    INSTALACAO,
    CONTA_CONTRATO,
    NOME,
    CPF,
    CNPJ,
    GRUPO,
    TARIFA,
    CLASSE,
    VALOR_FATURA
"""

# -----------------------------
# Colunas numéricas
# -----------------------------
DECIMAL_COLS = ["REDUCAO", "ICMS", "VALOR_FATURA"]

# -----------------------------
# Execução SQL por Thread
# -----------------------------
def run_query(schema, empresa):
    print(f"[Iniciando] Carregando dados de {empresa}")
    conn = get_connection()
    cur = conn.cursor()

    try:
        sql = SQL_TEMPLATE.format(
            SCHEMA=schema,
            EMP=empresa
        )
        cur.execute(sql)

        # Download binário nativo de alta performance direta para o Pandas
        df = cur.fetch_pandas_all()

        if df.empty:
            print(f"[Alerta] {empresa} sem dados.")
            return empresa, df

        # Padronizar nomes das colunas em maiúsculo
        df.columns = [col.upper() for col in df.columns]

        # Converter numéricos de forma segura
        for col in DECIMAL_COLS:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors="coerce").round(2)

        # Remover timezone de colunas datetime (Evita corromper arquivo Excel)
        datetime_cols = df.select_dtypes(include=["datetimetz"]).columns
        for col in datetime_cols:
            df[col] = df[col].dt.tz_localize(None)

        print(f"[Sucesso] {empresa} retornou {len(df):,} registros")
        return empresa, df

    except Exception as e:
        print(f"[Erro] Falha ao extrair dados de {empresa}: {e}")
        return empresa, pd.DataFrame()

    finally:
        cur.close()
        conn.close()

# -----------------------------
# Pipeline principal
# -----------------------------
def main():
    resultados = {}

    print("Disparando extrações simultâneas de Isenção ICMS TUSD para o Snowflake...")
    with ThreadPoolExecutor(max_workers=MAX_THREADS) as executor:
        futures = {
            executor.submit(run_query, schema, empresa): empresa
            for empresa, schema in DISTRIBUIDORAS.items()
        }

        for future in as_completed(futures):
            empresa = futures[future]
            try:
                empresa_nome, df = future.result()
                resultados[empresa_nome] = df
            except Exception as e:
                print(f"[Erro crítico] A thread da empresa {empresa} gerou um erro de execução: {e}")

    # -----------------------------
    # Exportação Excel Consolidada
    # -----------------------------
    print("\nGerando arquivo Excel consolidado na rede...")
    if resultados and any(not df.empty for df in resultados.values()):
        with pd.ExcelWriter(OUTPUT_PATH, engine="xlsxwriter") as writer:
            for empresa, df in resultados.items():
                if df.empty:
                    continue
                sheet = empresa[:31]
                df.to_excel(writer, sheet_name=sheet, index=False)
        print(f"✔ Arquivo consolidado gerado com sucesso!")
    else:
        print("\n[Alerta] Nenhuma informação válida retornou das distribuidoras.")

    print(f"\nProcesso finalizado. Destino:\n{OUTPUT_PATH}")


# -----------------------------
# Entrypoint
# -----------------------------
if __name__ == "__main__":
    main()
