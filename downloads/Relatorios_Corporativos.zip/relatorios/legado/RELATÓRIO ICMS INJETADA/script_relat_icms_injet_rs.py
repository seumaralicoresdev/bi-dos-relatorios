import snowflake.connector
import pandas as pd
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed  # <-- IMPORTANTE PARA PARALELISMO

# ---------------------------------------------------------
# Configuração
# ---------------------------------------------------------
DISTRIBUIDORAS = {
    # "EQTL_MA": "EQTL_MA",
    # "EQTL_PA": "EQTL_PA",
    # "EQTL_PI": "EQTL_PI",
    # "EQTL_AL": "EQTL_AL",
    # "EQTL_AP": "EQTL_AP",
    "EQTL_RS": "EQTL_RS",
}

MES_COMPET = "202606"

OUTPUT_PATH = Path(
    r"\\CMRSPPRARQ02\Gerencia Corporativa de Receita\Executiva de Inteligência e Gestão",
    r"14 - COLABORADORES\Elias\relatorio\gerados\202606\Tributario\Gerados_RS",
    f"icms_injetada_rs_{MES_COMPET}.xlsx"
)
OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)

# ---------------------------------------------------------
# Conexão Snowflake
# ---------------------------------------------------------
def get_connection():
    return snowflake.connector.connect(
        account="khb56279.us-east-1",
        user="elias.correa@equatorialenergia.com.br",
        authenticator="externalbrowser",
        warehouse="WH_EQTLINFO",
        database="SB_FATURAMENTO",
        schema="PUBLIC",
    )

# ---------------------------------------------------------
# SQL TEMPLATE
# ---------------------------------------------------------
SQL_TEMPLATE = """
SELECT '{EMP}' AS EMPRESA,
       A.MES_COMPETENCIA,
       B.MES_REFERENCIA,
       B.DOCUMENTO_IMPRESSAO,
       NULL AS DATA_EMISSAO,
       NULL AS NUMERO_NF3E,
       NULL AS CHAVE_ACESSO,
       C.NOME,
       D.ENDERECO || ', ' || D.NUMERO || ', ' || D.BAIRRO || ', ' || D.MUNICIPIO || ', ' || D.CEP AS ENDERECO,
       NVL(C.CPF, C.CNPJ) AS CPF_CNPJ,
       C.INSCRICAO_ESTADUAL,
       B.INSTALACAO,

       SUM(CASE WHEN A.ITEM_DOCUMENTO IN ('ZEGAT','ZEGFP','ZEGIT','ZEGNP','ZEGRV') 
                THEN A.CONSUMO END) AS CONSUMO,

       SUM(CASE WHEN A.ITEM_DOCUMENTO IN (
                   'ZEGAT','ZEGFP','ZEGIT','ZEGNP','ZEGRV',
                   'ZTGAT','ZTGFP','ZTGIT','ZTGNP','ZTGRV'
               ) THEN A.RECEITA END) AS RECEITA,

       CASE WHEN ZZ.ITEM_DOCUMENTO = 'ZPGAT' THEN ZZ.CONSUMO END AS TOTAL_INJET

  FROM (
        SELECT *
        FROM EQTLINFO_PRD.{SCHEMA}.ITENS_FATURAMENTO A
        WHERE A.MES_COMPETENCIA = '{MES}'
          AND (
                (A.OPERACAO IN ('0100','0200','0300') AND A.SUB_OPERACAO IN ('0016','0026','0010'))
                OR A.ITEM_DOCUMENTO = 'ZPGAT'
              )) A

  LEFT JOIN (
        SELECT *
        FROM (
            SELECT *
            FROM EQTLINFO_PRD.{SCHEMA}.ITENS_FATURAMENTO A
            WHERE A.MES_COMPETENCIA = '{MES}'
              AND (
                    (A.OPERACAO IN ('0100','0200','0300') AND A.SUB_OPERACAO IN ('0016','0026','0010'))
                    OR A.ITEM_DOCUMENTO = 'ZPGAT'
                  )
        ) Z
        WHERE Z.ITEM_DOCUMENTO = 'ZPGAT'
          AND Z.MES_COMPETENCIA = '{MES}'
       ) ZZ
       ON A.DOCUMENTO_IMPRESSAO = ZZ.DOCUMENTO_IMPRESSAO
      AND A.DOCUMENTO_CALCULO = ZZ.DOCUMENTO_CALCULO

  LEFT JOIN (
        SELECT *
        FROM EQTLINFO_PRD.{SCHEMA}.FATURAMENTO A
        WHERE A.MES_COMPETENCIA = '{MES}'
          AND A.DOCUMENTO_IMPRESSAO IN (
                SELECT DOCUMENTO_IMPRESSAO
                FROM EQTLINFO_PRD.{SCHEMA}.ITENS_FATURAMENTO
                WHERE MES_COMPETENCIA = '{MES}'
                  AND OPERACAO IN ('0100','0200','0300')
                  AND SUB_OPERACAO IN ('0016','0026','0010')
           )
       ) B
       ON A.DOCUMENTO_CALCULO = B.DOCUMENTO_CALCULO
      AND A.DOCUMENTO_IMPRESSAO = B.DOCUMENTO_IMPRESSAO

  LEFT JOIN EQTLINFO_PRD.{SCHEMA}.TAB_PARCEIRO_NEGOCIO C
       ON B.PARCEIRO_NEGOCIO = C.PARCEIRO_NEGOCIO

  LEFT JOIN EQTLINFO_PRD.{SCHEMA}.TAB_CADASTRO D
       ON B.INSTALACAO = D.INSTALACAO

WHERE A.MES_COMPETENCIA = '{MES}'
  AND A.OPERACAO IN ('0100','0200','0300')
  AND A.SUB_OPERACAO IN ('0016','0026','0010')

GROUP BY
       '{EMP}' || SUBSTR(A.DOMICILIO_FISCAL, 1, 2),
       A.MES_COMPETENCIA,
       B.MES_REFERENCIA,
       B.DOCUMENTO_IMPRESSAO,
       C.NOME,
       D.ENDERECO || ', ' || D.NUMERO || ', ' || D.BAIRRO || ', ' || D.MUNICIPIO || ', ' || D.CEP,
       NVL(C.CPF, C.CNPJ),
       C.INSCRICAO_ESTADUAL,
       B.INSTALACAO,
       CASE WHEN ZZ.ITEM_DOCUMENTO='ZPGAT' THEN ZZ.CONSUMO END
"""

# ---------------------------------------------------------
# Colunas decimais
# ---------------------------------------------------------
DECIMAL_COLS = [
    "CONSUMO",
    "RECEITA",
    "TOTAL_INJET"
]

# ---------------------------------------------------------
# Função Executada por cada Thread Paralela
# ---------------------------------------------------------
def processar_distribuidora(empresa_nome, schema):
    print(f"[Iniciando] Carga paralela: {empresa_nome} (schema: {schema})...")
    conn = get_connection()
    cur = conn.cursor()
    
    try:
        sql = SQL_TEMPLATE.format(SCHEMA=schema, MES=MES_COMPET, EMP=empresa_nome)
        cur.execute(sql)
        
        # Coleta de alta velocidade utilizando Arrow (Mapeamento de colunas automático)
        df = cur.fetch_pandas_all()

        if df.empty:
            print(f"[Aviso] {empresa_nome} retornou sem registros.")
            return empresa_nome, df

        # Padronizar nomes de colunas em caixa alta (UPPERCASE)
        df.columns = [col.upper() for col in df.columns]

        # Ajuste decimal das colunas numéricas
        for col in DECIMAL_COLS:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors="coerce").round(2)

        # Remover Timezone ativo de colunas datetime (Evita estouro de erro no Excel)
        tz_cols = df.select_dtypes(include=["datetimetz"]).columns
        for col in tz_cols:
            df[col] = df[col].dt.tz_localize(None)

        print(f"[Sucesso] {empresa_nome} → {len(df):,} linhas carregadas.")
        return empresa_nome, df

    except Exception as e:
        print(f"[Erro] Falha ao processar {empresa_nome}: {e}")
        return empresa_nome, pd.DataFrame()

    finally:
        cur.close()
        conn.close()

# ---------------------------------------------------------
# Main Pipeline
# ---------------------------------------------------------
def main():
    resultados = {}

    print("Disparando extrações simultâneas de ICMS Energia Injetada para o Snowflake...")
    # Processa as distribuidoras ativas ao mesmo tempo limitando o pool ao tamanho do dicionário
    with ThreadPoolExecutor(max_workers=len(DISTRIBUIDORAS)) as executor:
        futures = {
            executor.submit(processar_distribuidora, emp, sch): emp
            for emp, sch in DISTRIBUIDORAS.items()
        }
        
        for future in as_completed(futures):
            empresa = futures[future]
            try:
                empresa_nome, df = future.result()
                resultados[empresa_nome] = df
            except Exception as e:
                print(f"[Erro crítico] A thread de extração da empresa {empresa} quebrou: {e}")

    # Exportação final consolidada
    print("\nGerando arquivo Excel consolidado na rede...")
    if resultados and any(not df.empty for df in resultados.values()):
        with pd.ExcelWriter(OUTPUT_PATH, engine="xlsxwriter") as writer:
            for empresa, df in resultados.items():
                if df.empty:
                    continue
                sheet = empresa[:31]
                df.to_excel(writer, sheet_name=sheet, index=False)
        print(f"✔ Arquivo criado com sucesso!")
    else:
        print("\n[Aviso] Nenhuma informação útil retornou para salvar no Excel.")

    print(f"\nProcesso finalizado. Destino:\n{OUTPUT_PATH}")

# ---------------------------------------------------------
# Entrypoint
# ---------------------------------------------------------
if __name__ == "__main__":
    main()
