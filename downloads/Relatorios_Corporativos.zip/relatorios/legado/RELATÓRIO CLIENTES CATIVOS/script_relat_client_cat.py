import logging
import snowflake.connector
import pandas as pd
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor  # <-- IMPORTANTE PARA PARALELISMO

# -----------------------------
# Configuração
# -----------------------------
DISTRIBUIDORAS = {
    "EQTL_MA": {"prd_schema": "EQTL_MA", "raw_schema": "CCS_MA"},
    "EQTL_PA": {"prd_schema": "EQTL_PA", "raw_schema": "CCS_PA"},
    "EQTL_PI": {"prd_schema": "EQTL_PI", "raw_schema": "CCS_PI"},
    "EQTL_AL": {"prd_schema": "EQTL_AL", "raw_schema": "CCS_AL"},
    "EQTL_AP": {"prd_schema": "EQTL_AP", "raw_schema": "CCS_AP"},
    "EQTL_RS": {"prd_schema": "EQTL_RS", "raw_schema": "CCS_RS"},
}

MES_COMPET = "202608"

OUTPUT_PATH = Path(
    r"\\CMRSPPRARQ02\Gerencia Corporativa de Receita\Executiva de Inteligência e Gestão"
    rf"\14 - COLABORADORES\Elias\relatorio\gerados\202608\Contabilidade\clientes_cativos_{MES_COMPET}.xlsx"
)
OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)
# -----------------------------
# LOGGING
# -----------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s"
)

# -----------------------------
# Conexão Snowflake
# -----------------------------
def get_connection():
    return snowflake.connector.connect(
        account="khb56279.us-east-1",
        user="elias.correa@equatorialenergia.com.br",
        authenticator="externalbrowser",
        warehouse="WH_EQTLINFO",
        database="SB_FATURAMENTO",
        schema="PUBLIC",
    )

# -----------------------------
# SQL OTIMIZADA (Corrigida e Dinâmica)
# -----------------------------

SQL_TEMPLATE = """
    SELECT 
    '{EMP}' as  empresa, mes_referencia, a.mes_competencia, nvl(cl2.codigo_classe,cl.codigo_classe) AS codigo_classe, 
nvl(cl2.classe_principal,CL.CLASSE_PRINCIPAL) AS classe_principal, NVL(DECODE(B.SUBCLASSE,' ',NULL,B.SUBCLASSE),CAD.CODIGO_SUBCLASSE) AS subclasse,
nvl(cl2.subclasse_descricao,CL.SUBCLASSE_DESCRICAO) AS SUBCLASSE_DESCRICAO, cnr, substr(NVL(categoria_tarifa,TIPO_TARIFA),1,1) AS grupo,
substr(NVL(categoria_tarifa,TIPO_TARIFA),1,2) as sub_grupo_tensao, NVL(categoria_tarifa,TIPO_TARIFA) as cod_categoria_tarifa, b.cliente_livre, a.item_documento, TEXT30 AS descricao_item_documento, etapa,
SUM(valor_faturado) AS valor_faturado,
SUM(a.consumo_faturado) AS consumo_faturado,
SUM(montante_cofins) AS montante_cofins,
SUM(montante_icms) AS montante_icms,
SUM(montante_pis) AS montante_pis,
SUM(valor_faturado) - (SUM(montante_cofins)+SUM(montante_icms)+SUM(montante_pis)) as valor_sem_imposto
  from 
       (
        select mes_competencia,  documento_calculo,  documento_impressao,  item_ordenacao,
 				max(item_documento)as item_documento,
 				sum(consumo)consumo_faturado,
 				sum(receita) valor_faturado,
 				max(NVL(icms,0)) montante_icms,
 				max(NVL(pis,0)) montante_pis ,
				max(NVL(cofins,0)) montante_cofins
          from 
              (
               select mes_COMPETENCIA,  documento_calculo, documento_impressao, case when item_documento <> 'SUBT' then item_documento end as item_documento,
		               nvl(item_ordenacao, item_documento) as item_ordenacao, consumo,
		               sum(receita) as receita,
		               (SUM(case when tipo_imposto = 'MW2' THEN RECEITA END)) ICMS,
		               (SUM(case when tipo_imposto = 'PIS' THEN RECEITA END)) PIS,
		               (SUM(case when tipo_imposto = 'COF' THEN RECEITA END)) COFINS
                 from EQTLINFO_PRD.{PRD_SCHEMA}.ITENS_FATURAMENTO
                where 1=1
                  AND mes_competencia = '{MES}'
                  and documento_impressao in (
                                           select b.documento_impressao
                                             from EQTLINFO_PRD.{PRD_SCHEMA}.FATURAMENTO B
                                            where 1=1
                                              AND b.mes_competencia = '{MES}'
                                              AND CLIENTE_LIVRE IS NULL
                                          )
                  and flag in ('C', 'R')
                group by ALL
                )
		   group by  ALL
      )a  inner join EQTLINFO_PRD.{PRD_SCHEMA}.FATURAMENTO b on  a.mes_competencia = b.mes_competencia
				                                     and a.documento_impressao = b.documento_impressao
				                                     and a.documento_calculo = b.documento_calculo 
    left join EQTLINFO_RAW.{RAW_SCHEMA}.TE835T c on a.item_documento = C.BELZART AND SPRAS = 'P' and c.mandt in ('401','402','403','404','405','406')
   LEFT JOIN EQTLINFO_PRD.{PRD_SCHEMA}.TAB_CADASTRO CAD ON CAD.INSTALACAO = B.INSTALACAO
   LEFT JOIN SB_FATURAMENTO.EQTL_RS.DESCRICAO_CLASSE_SUBCLASSE CL ON CL.SUBCLASSE = NVL(DECODE(B.SUBCLASSE,' ',NULL,B.SUBCLASSE),CAD.CODIGO_SUBCLASSE)
   LEFT JOIN EQTLINFO_PRD.{PRD_SCHEMA}.TAB_DESCRICAO_CLASSE CL2 ON CL2.SUBCLASSE = NVL(DECODE(B.SUBCLASSE,' ',NULL,B.SUBCLASSE),CAD.CODIGO_SUBCLASSE)
GROUP BY all
"""

DECIMAL_COLS = [
    "VALOR_FATURADO",
    "CONSUMO_FATURADO",
    "MONTANTE_COFINS",
    "MONTANTE_ICMS",
    "MONTANTE_PIS",
    "VALOR_SEM_IMPOSTO",
]

# -----------------------------
# Função de Carga por Distribuidora (Trabalhadora)
# -----------------------------
def processar_distribuidora(empresa_nome, schema):
    print(f"Carga para: {empresa_nome}...")
    
    # Cada thread abre e fecha sua própria conexão
    conn = get_connection()
    cur = conn.cursor()
    
    try:
        sql = SQL_TEMPLATE.format(
            PRD_SCHEMA=schema["prd_schema"],
            RAW_SCHEMA=schema["raw_schema"],
            MES=MES_COMPET,
            EMP=empresa_nome,
        )
        
        cur.execute(sql)
        df = cur.fetch_pandas_all()
        
        # Tratamento numérico
        for col in DECIMAL_COLS:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors="coerce").round(2)
                
        print(f"[Sucesso] {empresa_nome}: gerou -> {len(df):,} linhas carregadas.")
        return empresa_nome, df
        
    except Exception as e:
        print(f"[Erro] Falha ao processar {empresa_nome}: {e}")
        return empresa_nome, pd.DataFrame()  # Retorna vazio em caso de falha
        
    finally:
        cur.close()
        conn.close()

# -----------------------------
# Pipeline principal
# -----------------------------
def main():
    resultados = {}
    
    # Dispara o pool de threads em paralelo (limite de 6 processos simultâneos)
    print("Disparando requisições paralelas ao Snowflake...")
    with ThreadPoolExecutor(max_workers=len(DISTRIBUIDORAS)) as executor:
        # Envia todas as tarefas ao mesmo tempo
        futures = [
            executor.submit(processar_distribuidora, emp, sch) 
            for emp, sch in DISTRIBUIDORAS.items()
        ]
        
        # Coleta as tabelas conforme elas vão terminando
        for future in futures:
            empresa, df = future.result()
            if not df.empty:
                resultados[empresa] = df

    # Exportação única e consolidada para o Excel
    if resultados:
        print("\nGerando arquivo Excel consolidado...")
        with pd.ExcelWriter(OUTPUT_PATH, engine="xlsxwriter") as writer:
            for empresa, df in resultados.items():
                df.to_excel(writer, sheet_name=empresa[:31], index=False)
        print("Arquivo criado com sucesso!")
    else:
        print("\nNenhum dado foi carregado para exportação.")

    print(f"\nProcesso finalizado. Destino:\n{OUTPUT_PATH}")

# -----------------------------
# Entrypoint
# -----------------------------
if __name__ == "__main__":
    main()
