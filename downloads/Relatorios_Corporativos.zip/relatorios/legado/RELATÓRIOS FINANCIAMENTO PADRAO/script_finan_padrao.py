import snowflake.connector
import pandas as pd
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed  # <-- IMPORTANTE PARA PARALELISMO

# -----------------------------
# Configuração
# -----------------------------
DISTRIBUIDORAS = {
    "EQTL_MA": "EQTL_MA",
    "EQTL_PA": "EQTL_PA",
    "EQTL_PI": "EQTL_PI",
    "EQTL_AL": "EQTL_AL",
    "EQTL_AP": "EQTL_AP",
    "EQTL_RS": "EQTL_RS",
}

MES_COMPET = "202608"

OUTPUT_PATH = Path(
    rf"\\CMRSPPRARQ02\Gerencia Corporativa de Receita\Executiva de Inteligência e Gestão\14 - COLABORADORES\Elias\relatorio\gerados\202608\Tributario\financ_padrao_{MES_COMPET}.xlsx"
)
OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)

# -----------------------------
# Conexão Snowflake
# -----------------------------
def get_connection():
    return snowflake.connector.connect(
        account="khb56279.us-east-1",
        user="elias.correa@equatorialenergia.com.br",
        authenticator="externalbrowser",
        warehouse="WH_EQTLINFO",
        database="SB_FATURAMENTO",
        schema="PUBLIC",
    )

# -----------------------------
# SQL TEMPLATE
# -----------------------------
SQL_TEMPLATE = """
SELECT
    '{EMP}' AS EMPRESA,
    doc.NOTA,
    doc.MANDANTE,
    doc.INSTALACAO,
    doc.CONTA_CONTRATO,
    doc.PARCEIRO_NEGOCIO,
    doc.PEP_ODS,
    doc.TIPO,
    doc.DATA_CADASTRO,
    doc.NUMERO_DOCUMENTO,
    doc.CANCELAMENTO,
    doc.DATA_CANC,
    doc.ORGANIZACAO_VENDAS,
    doc.NOME,
    doc.SOBRENOME,
    doc.NR_ID_FISCAL,
    doc.MONTANTE,
    doc.TIPO_DOC_VENDAS,
    doc.QTD_ORDEM,
    doc.STATUS_INTERFACE,
    doc.ALTERADO_POR,
    doc.MATERIAL,
    doc.RUA,
    doc.ENDERECO_EMAIL,
    doc.CODIGO_POSTAL,
    doc.NUMERO,
    doc.CIDADE,
    doc.PAIS,
    doc.MOEDA,
    doc.CRIADO_POR,
    doc.NUMERO_NFSE,
    doc.DATA_ENTRADA,
    doc.CENTRO_LUCRO,
    doc.REGIAO,
    doc.COD_DOMI_FISCAL,
    doc.DOCUMENTO_VENDAS,
    doc.NR_NOTA_FISCAL,
    CASE
        WHEN SUB.STATUS_COMPENSACAO = '9'
         AND SUB.MOTIVO_COMPENSACAO = '05'
        THEN 'INATIVO'
        ELSE 'ATIVO'
    END AS STATUS_FINANCIAMENTO_FAT,
    COUNT(sub.texto_item) AS QTD_PARCELAS,
    SUM(sub.MONTANTE_COMPENSACAO) AS MONTANTE_COMPENSACAO
FROM EQTLINFO_PRD.{SCHEMA}.finpad_notas DOC
LEFT JOIN EQTLINFO_PRD.{SCHEMA}.ITENS_FINANCEIRO SUB
    ON SUB.NUMERO_DOCUMENTO = DOC.NUMERO_DOCUMENTO
WHERE doc.Tipo_doc_vendas = 'ZPAD'
  AND TO_CHAR(doc.data_entrada,'yyyymm') = '{MES}'
GROUP BY ALL
"""

# -----------------------------
# Ajuste decimal
# -----------------------------
DECIMAL_COLS = ["MONTANTE", "MONTANTE_COMPENSACAO"]

# -----------------------------
# Função Executada por cada Thread
# -----------------------------
def processar_distribuidora(empresa_nome, schema):
    print(f"[Iniciando] Carga: {empresa_nome}")
    
    # Cada thread gerencia sua própria conexão para viabilizar o paralelismo
    conn = get_connection()
    cur = conn.cursor()
    
    try:
        sql = SQL_TEMPLATE.format(
            SCHEMA=schema,
            MES=MES_COMPET,
            EMP=empresa_nome,
        )
        cur.execute(sql)
        
        # Coleta rápida binária nativa para DataFrame Pandas
        df = cur.fetch_pandas_all()

        if df.empty:
            print(f"[Aviso] {empresa_nome} retornou sem registros.")
            return empresa_nome, df

        # Padronizar nomes de colunas em maiúsculo
        df.columns = [col.upper() for col in df.columns]

        # Formatador decimal
        for col in DECIMAL_COLS:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors="coerce").round(2)

        # Remover Timezone de colunas datetime (Evita quebra ao exportar para o Excel)
        tz_cols = df.select_dtypes(include=["datetimetz"]).columns
        for col in tz_cols:
            df[col] = df[col].dt.tz_localize(None)

        print(f"[Sucesso] {empresa_nome} → {len(df):,} registros extraídos.")
        return empresa_nome, df

    except Exception as e:
        print(f"[Erro] Falha ao processar {empresa_nome}: {e}")
        return empresa_nome, pd.DataFrame()

    finally:
        cur.close()
        conn.close()

# -----------------------------
# Main pipeline
# -----------------------------
def main():
    resultados = {}

    print("Disparando extrações simultâneas de Financiamento Padrão para o Snowflake...")
    # Executa todas as distribuidoras em threads paralelas simultâneas
    with ThreadPoolExecutor(max_workers=len(DISTRIBUIDORAS)) as executor:
        futures = {
            executor.submit(processar_distribuidora, emp, sch): emp
            for emp, sch in DISTRIBUIDORAS.items()
        }
        
        # Consolida os DataFrames conforme a conclusão de cada tarefa
        for future in as_completed(futures):
            empresa = futures[future]
            try:
                empresa_nome, df = future.result()
                resultados[empresa_nome] = df
            except Exception as e:
                print(f"[Erro crítico] Exceção na thread da empresa {empresa}: {e}")

    # Exportação final consolidada para a rede
    print("\nGerando arquivo Excel consolidado...")
    if resultados and any(not df.empty for df in resultados.values()):
        with pd.ExcelWriter(OUTPUT_PATH, engine="xlsxwriter") as writer:
            for empresa, df in resultados.items():
                if df.empty:
                    print(f"⚠ {empresa} sem dados na extração (Aba ignorada)")
                    continue
                sheet = empresa[:31]
                df.to_excel(writer, sheet_name=sheet, index=False)
        print(f"✔ Arquivo gerado com sucesso!")
    else:
        print("\n[Aviso] Nenhuma informação válida foi retornada para gerar a planilha.")

    print(f"\nProcesso finalizado. Destino:\n{OUTPUT_PATH}")

# -----------------------------
# Entrypoint
# -----------------------------
if __name__ == "__main__":
    main()
