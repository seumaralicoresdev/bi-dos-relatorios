import snowflake.connector
import pandas as pd
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed  # <-- IMPORTANTE PARA PARALELISMO

# --------------------------
# Configuração
# -----------------------------
DISTRIBUIDORAS = {
    "EQTL_MA": {"prd_schema": "EQTL_MA", "raw_schema": "CCS_MA"},
    "EQTL_PA": {"prd_schema": "EQTL_PA", "raw_schema": "CCS_PA"},
    "EQTL_PI": {"prd_schema": "EQTL_PI", "raw_schema": "CCS_PI"},
    "EQTL_AL": {"prd_schema": "EQTL_AL", "raw_schema": "CCS_AL"},
    "EQTL_AP": {"prd_schema": "EQTL_AP", "raw_schema": "CCS_AP"},
    "EQTL_RS": {"prd_schema": "EQTL_RS", "raw_schema": "CCS_RS"},
}

MES_COMPET = "202608"

OUTPUT_PATH = Path(
    r"\\CMRSPPRARQ02\Gerencia Corporativa de Receita\Executiva de Inteligência e Gestão"
    rf"\14 - COLABORADORES\Elias\relatorio\gerados\{MES_COMPET}\Contabilidade\clientes_livres_{MES_COMPET}.xlsx"
)
OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)

# -----------------------------
# Conexão Snowflake
# -----------------------------
def get_connection():
    return snowflake.connector.connect(
        account="khb56279.us-east-1",
        user="elias.correa@equatorialenergia.com.br",
        authenticator="externalbrowser",
        warehouse="WH_EQTLINFO",
        database="SB_FATURAMENTO",
        schema="PUBLIC",
    )

# -----------------------------
# SQL OTIMIZADA
# -----------------------------
SQL_TEMPLATE = """
SELECT EMPRESA,
       INSTALACAO,
       DOCUMENTO_IMPRESSAO,
       NUMERO_FATURA,
       CONTA_CONTRATO,
       MES_REFERENCIA,
       MES_COMPETENCIA,
       CLASSE,
       CNR,
       GRUPO,
       SUB_GRUPO_TENSAO,
       COD_CATEGORIA_TARIFA,
       CLIENTE_LIVRE,
       ITEM_DOCUMENTO,
       DESCRICAO_ITEM_DOCUMENTO,
       ETAPA,
       VALOR_FATURADO,
       CONSUMO_FATURADO,
       MONTANTE_COFINS,
       MONTANTE_ICMS,
       MONTANTE_PIS,
       VALOR_sem_imposto
FROM (
       SELECT A.empresa, A.instalacao, documento_impressao, numero_fatura, A.conta_contrato, mes_referencia, mes_competencia, nvl(classe,substr(nvl(CL2.classe_principal,cl.classe_principal),1,2)) AS classe,
       cnr, nvl(grupo,grupo_tensao) AS grupo, substr(nvl(cod_categoria_tarifa,tipo_tarifa),1,2) AS sub_grupo_tensao, ETAPA, nvl(cod_categoria_tarifa,tipo_tarifa) AS cod_categoria_tarifa,
       A.cliente_livre, max(a.item_documento) as item_documento, substr(max(a.item_documento||'  '||TEXT30),7,100) AS descricao_item_documento, documento_calculo, item_ordenacao,
			 nvl(sum(consumo),0) AS consumo_faturado,
			 nvl(sum(receita),0) valor_faturado,
			 nvl(max(icms),0) montante_icms,
			 nvl(max(pis),0) montante_pis,
			 nvl(max(cofins),0) montante_cofins,
			 nvl(sum(receita),0)-(nvl(max(icms),0)+nvl(max(pis),0)+nvl(max(cofins),0)) AS VALOR_sem_imposto
 		 FROM 
 			 (
				select '{EMP}' as empresa,
			      b.instalacao,
			      a.documento_impressao,
			      b.fatura as numero_fatura,
			      b.conta_contrato,
			      b.mes_referencia,
			      a.mes_competencia,
			      substr(b.subclasse,1,2) as classe,
			      b.subclasse,
					b.cnr,
					b.grupo,
					substr(b.categoria_tarifa,1,2) as sub_grupo_tensao,
					b.categoria_tarifa as cod_categoria_tarifa,
					b.cliente_livre,
					b.etapa,
					consumo,
					case when item_documento <> 'SUBT' then item_documento end as item_documento,
					a.documento_calculo,
			       nvl(item_ordenacao, item_documento) as item_ordenacao,
			       sum(receita) as receita,
			       (SUM(case when tipo_imposto = 'MW2' THEN RECEITA END)) ICMS,
			       (SUM(case when tipo_imposto = 'PIS' THEN RECEITA END)) PIS,
			       (SUM(case when tipo_imposto = 'COF' THEN RECEITA END)) COFINS
			        from EQTLINFO_PRD.{PRD_SCHEMA}.FATURAMENTO b
			             inner join EQTLINFO_PRD.{PRD_SCHEMA}.ITENS_FATURAMENTO A on a.mes_competencia = b.mes_competencia
			                     											and a.documento_impressao = b.documento_impressao
										                                     and a.documento_calculo = b.documento_calculo
										                                     and flag in ('C', 'R')
			       where 1=1
			         AND b.MES_COMPETENCIA = '{MES}'
			         AND cliente_livre = 'X'
			       group by ALL
			      ) a 
  left join EQTLINFO_RAW.{RAW_SCHEMA}.TE835T c on a.item_documento = c.belzart AND c.spras = 'P' and c.mandt in ('401','402','403','404','405','406')
    LEFT JOIN EQTLINFO_PRD.{PRD_SCHEMA}.TAB_CADASTRO CAD ON CAD.INSTALACAO = a.INSTALACAO
   LEFT JOIN SB_FATURAMENTO.EQTL_RS.DESCRICAO_CLASSE_SUBCLASSE CL ON CL.SUBCLASSE = NVL(DECODE(A.SUBCLASSE,' ',NULL,A.SUBCLASSE),CAD.CODIGO_SUBCLASSE)
   LEFT JOIN EQTLINFO_PRD.{PRD_SCHEMA}.TAB_DESCRICAO_CLASSE CL2 ON CL2.SUBCLASSE = NVL(DECODE(A.SUBCLASSE,' ',NULL,A.SUBCLASSE),CAD.CODIGO_SUBCLASSE)
		GROUP BY ALL
		)
		GROUP BY ALL
"""

# -----------------------------
# Ajuste decimal
# -----------------------------
DECIMAL_COLS = [
    "VALOR_FATURADO",
    "CONSUMO_FATURADO",
    "MONTANTE_COFINS",
    "MONTANTE_ICMS",
    "MONTANTE_PIS",
    "VALOR_SEM_IMPOSTO",
]

# -----------------------------
# Execução por thread
# -----------------------------
def processar_distribuidora(empresa_nome, schema):
    print(f"[Iniciando] Carga paralela: {empresa_nome}...")
    conn = get_connection()
    cur = conn.cursor()
    try:
        sql = SQL_TEMPLATE.format(
            PRD_SCHEMA=schema["prd_schema"],
            RAW_SCHEMA=schema["raw_schema"],
            MES=MES_COMPET,
            EMP=empresa_nome,
        )
        cur.execute(sql)
        df = cur.fetch_pandas_all()

        for col in DECIMAL_COLS:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors="coerce").round(2)

        print(f"[Sucesso] {empresa_nome} → {len(df):,} linhas carregadas.")
        return empresa_nome, df
    except Exception as e:
        print(f"[Erro] Falha ao processar {empresa_nome}: {e}")
        return empresa_nome, pd.DataFrame()
    finally:
        cur.close()
        conn.close()

# -----------------------------
# Pipeline principal
# -----------------------------
def main():
    resultados = {}

    print("Disparando extrações simultâneas para o Snowflake...")
    with ThreadPoolExecutor(max_workers=len(DISTRIBUIDORAS)) as executor:
        futures = {
            executor.submit(processar_distribuidora, nome, schemas): nome
            for nome, schemas in DISTRIBUIDORAS.items()
        }

        for future in as_completed(futures):
            empresa = futures[future]
            try:
                empresa_nome, df = future.result()
                resultados[empresa_nome] = df
            except Exception as e:
                print(f"[Erro crítico] A thread da empresa {empresa} gerou uma exceção: {e}")

    # Exportação Excel
    print("\nGerando arquivo Excel consolidado...")
    if resultados and any(not df.empty for df in resultados.values()):
        with pd.ExcelWriter(OUTPUT_PATH, engine="xlsxwriter") as writer:
            for empresa, df in resultados.items():
                if df.empty:
                    continue
                df.to_excel(writer, sheet_name=empresa[:31], index=False)
        print("\nArquivo Excel consolidado criado com sucesso!")
    else:
        print("\n[Aviso] Nenhuma informação válida foi retornada para gerar o arquivo.")

    print(f"\nArquivo salvo em:\n{OUTPUT_PATH}")

# -----------------------------
# Entrypoint
# -----------------------------
if __name__ == "__main__":
    main()
