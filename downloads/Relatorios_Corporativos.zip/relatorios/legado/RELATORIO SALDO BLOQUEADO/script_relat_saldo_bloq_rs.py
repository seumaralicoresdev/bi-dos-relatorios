import snowflake.connector
import pandas as pd
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

# -----------------------------
# Configuração
# -----------------------------
DISTRIBUIDORAS = {
    # "EQTL_MA": {"prd_schema": "EQTL_MA", "raw_schema": "CCS_MA"},
    # "EQTL_PA": {"prd_schema": "EQTL_PA", "raw_schema": "CCS_PA"},
    # "EQTL_PI": {"prd_schema": "EQTL_PI", "raw_schema": "CCS_PI"},
    # "EQTL_AL": {"prd_schema": "EQTL_AL", "raw_schema": "CCS_AL"},
    # "EQTL_AP": {"prd_schema": "EQTL_AP", "raw_schema": "CCS_AP"},
    "EQTL_RS": {"prd_schema": "EQTL_RS", "raw_schema": "CCS_RS"},
}

MES_COMPET = "202606"

OUTPUT_PATH = Path(
    rf"\\CMRSPPRARQ02\Gerencia Corporativa de Receita\Executiva de Inteligência e Gestão\14 - COLABORADORES\Elias\relatorio\gerados\202606\Contabilidade\Gerados_RS\saldo_bloqueado_rs_{MES_COMPET}.xlsx"
)

OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)

# -----------------------------
# Colunas numéricas
# -----------------------------
DECIMAL_COLS = ["QUANTIDADE"]

# -----------------------------
# Conexão Snowflake
# -----------------------------
def get_connection():
    return snowflake.connector.connect(
        account="khb56279.us-east-1",
        user="elias.correa@equatorialenergia.com.br",
        authenticator="externalbrowser",
        warehouse="WH_EQTLINFO",
        database="EQTLINFO_PRD",
        schema="PUBLIC",
    )

# -----------------------------
# SQL Template
# -----------------------------
SQL_TEMPLATE = """
 SELECT B.*, A.CONTA_CONTRATO
FROM (
    SELECT
        '{PRD_SCHEMA}' AS EMPRESA,
        '{MES_COMPET}'  AS REFERENCIA,
        A.GEN_CONTRACT  AS CONTRATO_GERACAO,
        TO_CHAR(TRUNC(SUM(A.QUANT))) AS QUANTIDADE,
        SUBSTR(RUSE_ENDDATE, 1, 6) AS MES_ORIGEM_CREDITO
    FROM EQTLINFO_RAW.{RAW_SCHEMA}.EENRGY_CR_BR A
    WHERE 1=1
      AND RUSE_ENDDATE < TO_CHAR(ADD_MONTHS(TO_DATE('{MES_COMPET}' || '01', 'YYYYMMDD'), -60), 'YYYYMMDD')
      AND A.CREATEDDATE < TO_CHAR(ADD_MONTHS(TO_DATE('{MES_COMPET}' || '06', 'YYYYMMDD'),  1), 'YYYYMMDD')
    GROUP BY ALL
) B
INNER JOIN EQTLINFO_PRD.{PRD_SCHEMA}.TAB_CONTRATO A
    ON A.CONTRATO = B.CONTRATO_GERACAO
WHERE QUANTIDADE <> 0
"""

# -----------------------------
# Execução SQL (Função Isolada por Thread)
# -----------------------------
def run_query(empresa_nome, prd_schema, raw_schema):
    print(f"[Iniciando] Carga paralela: {empresa_nome}...")
    
    # Cada thread gerencia sua própria conexão de forma segura
    conn = get_connection()
    cur = conn.cursor()

    sql = SQL_TEMPLATE.format(
        PRD_SCHEMA=prd_schema,
        RAW_SCHEMA=raw_schema,
        MES_COMPET=MES_COMPET,
    )

    try:
        cur.execute(sql)
        df = cur.fetch_pandas_all()

        if df.empty:
            print(f"[Aviso] {empresa_nome} retornou sem dados.")
            return empresa_nome, df

        # Ajuste colunas numéricas
        for col in DECIMAL_COLS:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors="coerce").round(2)

        # Remover timezone (Excel não aceita)
        tz_cols = df.select_dtypes(include=["datetimetz"]).columns
        for col in tz_cols:
            df[col] = df[col].dt.tz_localize(None)

        print(f"[Sucesso] {empresa_nome} → {len(df):,} registros carregados.")
        return empresa_nome, df

    except Exception as e:
        print(f"[Erro] Falha catastrófica em {empresa_nome}: {e}")
        return empresa_nome, pd.DataFrame()

    finally:
        cur.close()
        conn.close()

# -----------------------------
# Pipeline principal
# -----------------------------
def main():
    resultados = {}

    print("Disparando requisições paralelas e seguras ao Snowflake...")
    # Ajustado max_workers dinâmico para cobrir todas as distribuidoras simultaneamente
    with ThreadPoolExecutor(max_workers=len(DISTRIBUIDORAS)) as executor:

        futures = {
            executor.submit(
                run_query,
                nome,
                schemas["prd_schema"],
                schemas["raw_schema"],
            ): nome
            for nome, schemas in DISTRIBUIDORAS.items()
        }

        for future in as_completed(futures):
            empresa = futures[future]
            try:
                empresa_nome, df = future.result()
                resultados[empresa_nome] = df
            except Exception as exc:
                print(f"[Erro] A thread da empresa {empresa} gerou uma exceção: {exc}")

    # Exportação Excel
    print("\nGerando arquivo Excel consolidado...")
    if resultados and any(not df.empty for df in resultados.values()):
        with pd.ExcelWriter(OUTPUT_PATH, engine="xlsxwriter") as writer:
            for empresa, df in resultados.items():
                if df.empty:
                    continue
                df.to_excel(writer, sheet_name=empresa[:31], index=False)

        print(f"\nArquivo gerado com sucesso:")
        print(OUTPUT_PATH)
    else:
        print("\n[Aviso] Nenhuma informação válida foi coletada para criar o arquivo.")

# -----------------------------
# Entrypoint
# -----------------------------
if __name__ == "__main__":
    main()
