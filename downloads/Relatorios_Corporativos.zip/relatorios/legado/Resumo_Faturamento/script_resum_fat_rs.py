import snowflake.connector
import pandas as pd
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor  # <-- IMPORTANTE PARA PARALELISMO

# -----------------------------
# Configuração
# -----------------------------
DISTRIBUIDORAS = { 
    # "EQTL_MA": "EQTL_MA",
    # "EQTL_PA": "EQTL_PA",
    # "EQTL_PI": "EQTL_PI",
    # "EQTL_AL": "EQTL_AL",
    # "EQTL_AP": "EQTL_AP",
    "EQTL_RS": "EQTL_RS",
}

MES_COMPET = "202606"

OUTPUT_PATH = Path(
    r"\\CMRSPPRARQ02\Gerencia Corporativa de Receita\Executiva de Inteligência e Gestão\14 - COLABORADORES\Elias\relatorio\gerados\202606\Contabilidade\Gerados_RS\resumo_fat_tributos_{}.xlsx".format(
        MES_COMPET
    )
)
OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)

# -----------------------------
# Conexão Snowflake
# -----------------------------
def get_connection():
    return snowflake.connector.connect(
        account="khb56279.us-east-1",
        user="elias.correa@equatorialenergia.com.br",
        authenticator="externalbrowser",
        warehouse="WH_EQTLINFO",
        database="SB_FATURAMENTO",
        schema="PUBLIC",
    )

# -----------------------------
# SQL TEMPLATE
# -----------------------------
SQL_TEMPLATE = """
SELECT
    '{EMP}' AS EMPRESA,
    A.*
FROM SB_FATURAMENTO.{SCHEMA}.RESUMO_FAT_TRIBUTOS A
WHERE A.CLASSE IS NOT NULL
  AND A.MES_COMPETENCIA = '{MES}'
"""

# -----------------------------
# Ajuste decimal → duas casas
# -----------------------------
DECIMAL_COLS = [
    "ICMS",
    "PIS",
    "COFINS",
    "SUBVENCAO_BXRENDA",
]

# -----------------------------
# Função Executada por cada Thread
# -----------------------------
def processar_distribuidora(empresa_nome, schema):
    print(f"[Iniciando] Carga paralela: {empresa_nome} (schema: {schema})...")
    
    # Abrindo conexões isoladas por linha/thread para o paralelismo funcionar
    conn = get_connection()
    cur = conn.cursor()
    
    try:
        sql = SQL_TEMPLATE.format(SCHEMA=schema, MES=MES_COMPET, EMP=empresa_nome)
        cur.execute(sql)
        
        # Leitura de alta performance direto da API interna para DataFrame
        df = cur.fetch_pandas_all()

        # Formatador decimal
        for col in DECIMAL_COLS:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors="coerce").round(2)

        print(f"[Sucesso] {empresa_nome}: {len(df):,} linhas extraídas.")
        return empresa_nome, df

    except Exception as e:
        print(f"[Erro] Falha ao processar {empresa_nome}: {e}")
        return empresa_nome, pd.DataFrame()

    finally:
        cur.close()
        conn.close()

# -----------------------------
# Main pipeline
# -----------------------------
def main():
    resultados = {}

    print("Disparando extrações simultâneas de Tributos para o Snowflake...")
    # Dispara e gerencia as threads de forma paralela
    with ThreadPoolExecutor(max_workers=len(DISTRIBUIDORAS)) as executor:
        futures = [
            executor.submit(processar_distribuidora, emp, sch)
            for emp, sch in DISTRIBUIDORAS.items()
        ]
        
        # Junta todas as abas resolvidas ao final do processamento
        for future in futures:
            empresa, df = future.result()
            if not df.empty:
                resultados[empresa] = df

    # Exportação final para a rede
    if resultados:
        print("\nGerando arquivo Excel consolidado...")
        with pd.ExcelWriter(OUTPUT_PATH, engine="xlsxwriter") as writer:
            for empresa, df in resultados.items():
                sheet = empresa[:31]
                df.to_excel(writer, sheet_name=sheet, index=False)
        print("Processo finalizado com sucesso!")
    else:
        print("\n[Aviso] Nenhum dado foi capturado para geração do relatório.")

    print(f"\nArquivo salvo em:\n{OUTPUT_PATH}")

# Entrypoint
if __name__ == "__main__":
    main()
