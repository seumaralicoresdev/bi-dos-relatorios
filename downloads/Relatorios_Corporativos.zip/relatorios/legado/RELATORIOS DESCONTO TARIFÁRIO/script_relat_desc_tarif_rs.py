import snowflake.connector
import pandas as pd
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import logging
import time

# -----------------------------
# CONFIGURAÇÃO
# -----------------------------
DISTRIBUIDORAS = {
    # "EQTL_MA": "EQTL_MA",
    # "EQTL_PA": "EQTL_PA",
    # "EQTL_PI": "EQTL_PI",
    # "EQTL_AL": "EQTL_AL",
    # "EQTL_AP": "EQTL_AP",
    "EQTL_RS": "EQTL_RS",
}

MES_COMPET = "202606"

OUTPUT_PATH = Path(
    rf"\\CMRSPPRARQ02\Gerencia Corporativa de Receita\Executiva de Inteligência e Gestão",
    rf"14 - COLABORADORES\Elias\relatorio\gerados\202606\Contabilidade\Gerados_RS\desconto_tarifario_{MES_COMPET}.xlsx"
)
OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)

MAX_WORKERS = 6
MAX_RETRIES = 3
RETRY_DELAY = 5  # segundos

# -----------------------------
# LOGGING
# -----------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s"
)

# -----------------------------
# CONEXÃO SNOWFLAKE
# -----------------------------
def get_connection():
    return snowflake.connector.connect(
        account="khb56279.us-east-1",
        user="elias.correa@equatorialenergia.com.br",
        authenticator="externalbrowser",
        warehouse="WH_EQTLINFO",
        database="SB_FATURAMENTO",
        schema="PUBLIC",
    )

# -----------------------------
# SQL TEMPLATE
# -----------------------------
SQL_TEMPLATE = """
SELECT EMPRESA, MES_COMPETENCIA, ITEM_ORDENACAO, ITEM_DOCUMENTO, SUB_OPERACAO, CHAVE_RECONCILIACAO, 
  INSTALACAO, CONTA_CONTRATO, CONTRATO, FATURA, CATEGORIA_TARIFA, SUBCLASSE,
  SUM(RECEITA) AS RECEITA, 
  DOCUMENTO_IMPRESSAO, CASE WHEN ITEM_ORDENACAO <> 'ZBTL' THEN 'X' END AS GD,
  FROM
	  (
		SELECT '{EMP}' AS EMPRESA,
				a.mes_competencia,
		        item_ordenacao,
		        CASE WHEN item_documento = 'SUBT' THEN ITEM_ORDENACAO ELSE ITEM_DOCUMENTO END AS ITEM_DOCUMENTO,
		        MAX(MAX(a.sub_operacao)) OVER (PARTITION BY B.DOCUMENTO_IMPRESSAO, A.ITEM_ORDENACAO) AS sub_operacao,
		        b.chave_reconciliacao,
		        b.instalacao,
		        b.conta_contrato,
		        b.contrato, 
		        b.fatura,
		        B.categoria_tarifa,
		        B.subclasse, 
		        a.RECEITA,
		        b.documento_impressao,
		        a.linha,
		FROM EQTLINFO_PRD.{SCHEMA}.ITENS_FATURAMENTO A
		INNER JOIN EQTLINFO_PRD.{SCHEMA}.FATURAMENTO b ON a.documento_impressao = b.documento_impressao and a.documento_calculo = b.documento_calculo
		WHERE 1=1
		and A.mes_competencia = '{MES}'
		--AND CHAVE_RECONCILIACAO = 'R260429000R4'
		and (A.ITEM_ORDENACAO in ('YBTL','Z02L','Z03L','Z12L','Z13L','Z22L','Z23L','Z32L','Z33L','Z42L','Z43L','Z52L','Z53L','Z62L','Z63L','Z72L','Z73L','Z82L','Z83L',
			'Z92L','Z93L','ZBCL','ZBGL','ZBIL','ZBLP','ZBLS','ZBSL','ZBTL') OR A.ITEM_ORDENACAO LIKE 'ZL%')
		AND ITEM_DOCUMENTO <> 'ZBTLBR'
		GROUP BY all
	 )
 WHERE RECEITA <> 0 
   AND SUB_OPERACAO NOT IN ('0053', '0063')
 GROUP BY ALL
 HAVING SUM(RECEITA) <> 0
"""

# -----------------------------
# UTIL: EXECUÇÃO QUERY
# -----------------------------
def run_query(conn, sql: str) -> pd.DataFrame:
    with conn.cursor() as cur:
        cur.execute(sql)
        cols = [col[0] for col in cur.description]
        data = cur.fetchall()

    df = pd.DataFrame(data, columns=cols)

    if "RECEITA" in df.columns:
        df["RECEITA"] = pd.to_numeric(df["RECEITA"], errors="coerce").round(2)

    return df

# -----------------------------
# PROCESSAMENTO COM RETRY
# -----------------------------
def processar_distribuidora(empresa: str, schema: str):
    for tentativa in range(1, MAX_RETRIES + 1):
        try:
            logging.info(f"[{empresa}] Iniciando processamento (tentativa {tentativa})")

            conn = get_connection()

            sql = SQL_TEMPLATE.format(
                SCHEMA=schema,
                MES=MES_COMPET,
                EMP=empresa
            )

            df = run_query(conn, sql)

            logging.info(f"[{empresa}] gerou -> {len(df):,} linhas")
            return empresa, df

        except Exception as e:
            logging.error(f"[{empresa}] Erro: {e}")

            if tentativa < MAX_RETRIES:
                logging.info(f"[{empresa}] Retry em {RETRY_DELAY}s...")
                time.sleep(RETRY_DELAY)
            else:
                logging.error(f"[{empresa}] Falha definitiva.")
                return empresa, pd.DataFrame()

        finally:
            try:
                conn.close()
            except:
                pass

# -----------------------------
# PIPELINE PRINCIPAL
# -----------------------------
def main():
    logging.info("Iniciando pipeline paralelo...")

    resultados = {}

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = [
            executor.submit(processar_distribuidora, emp, schema)
            for emp, schema in DISTRIBUIDORAS.items()
        ]

        for future in as_completed(futures):
            empresa, df = future.result()
            resultados[empresa] = df

    # -----------------------------
    # EXPORTAÇÃO
    # -----------------------------
    logging.info("Exportando para Excel...")

    with pd.ExcelWriter(OUTPUT_PATH, engine="xlsxwriter") as writer:
        for empresa, df in resultados.items():
            sheet = empresa[:31]
            df.to_excel(writer, sheet_name=sheet, index=False)

    logging.info(f"Arquivo gerado em: {OUTPUT_PATH}")

# -----------------------------
# ENTRYPOINT
# -----------------------------
if __name__ == "__main__":
    main()