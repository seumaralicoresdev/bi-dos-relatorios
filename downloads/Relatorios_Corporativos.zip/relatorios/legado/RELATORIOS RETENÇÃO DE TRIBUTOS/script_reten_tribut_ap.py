import snowflake.connector
import pandas as pd
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

# -----------------------------
# Configuração
# -----------------------------
DISTRIBUIDORAS = {
    # "EQTL_MA": "EQTL_MA",
    # "EQTL_PA": "EQTL_PA",
    # "EQTL_PI": "EQTL_PI",
    # "EQTL_AL": "EQTL_AL",
    # "EQTL_AP": "EQTL_AP",
    "EQTL_RS": "EQTL_RS",
}

MES_COMPET = "202606"
    
OUTPUT_PATH = Path(
    rf"\\CMRSPPRARQ02\Gerencia Corporativa de Receita\Executiva de Inteligência e Gestão\14 - COLABORADORES\Elias\relatorio\gerados\202606\Tributario\Gerados_RS\retencao_tributos_{MES_COMPET}.xlsx"
)

OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)

# -----------------------------
# Colunas numéricas
# -----------------------------
DECIMAL_COLS = ["REDUCAO", "ICMS", "VALOR_FATURA"]

# -----------------------------
# Conexão Snowflake
# -----------------------------
def get_connection():
    return snowflake.connector.connect(
        account="khb56279.us-east-1",
        user="elias.correa@equatorialenergia.com.br",
        authenticator="externalbrowser",
        warehouse="WH_EQTLINFO",
        database="EQTLINFO_PRD",
        schema="PUBLIC",
    )

# -----------------------------
# SQL Template
# -----------------------------
SQL_TEMPLATE = """
SELECT *
FROM SB_FATURAMENTO.{SCHEMA}.BASE_IMPOSTO_RETIDO
WHERE MES_COMPETENCIA = '{MES_COMPET}'
"""

# -----------------------------
# Execução SQL paralela e otimizada
# -----------------------------
def run_query(empresa_nome, schema):
    print(f"[Iniciando] Carga: {empresa_nome}")
    
    # Cada thread gerencia sua própria conexão de forma segura
    conn = get_connection()
    cur = conn.cursor()

    sql = SQL_TEMPLATE.format(
        SCHEMA=schema,
        MES_COMPET=MES_COMPET
    )

    try:
        cur.execute(sql)

        # Download direto e ultra rápido em DataFrame Pandas via Arrow
        df = cur.fetch_pandas_all()

        if df.empty:
            print(f"[Aviso] {empresa_nome} sem dados cadastrados.")
            return empresa_nome, df

        # Forçar caixa alta nos nomes das colunas para evitar conflitos de mapeamento
        df.columns = [col.upper() for col in df.columns]

        # Ajuste de colunas numéricas
        for col in DECIMAL_COLS:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors="coerce").round(2)

        # Remover fuso horário (Evita que o xlsxwriter quebre a exportação)
        tz_cols = df.select_dtypes(include=["datetimetz"]).columns
        for col in tz_cols:
            df[col] = df[col].dt.tz_localize(None)

        print(f"[Sucesso] {empresa_nome} → {len(df):,} registros")
        return empresa_nome, df

    except Exception as e:
        print(f"[Erro] Falha ao extrair dados de {empresa_nome}: {e}")
        return empresa_nome, pd.DataFrame()

    finally:
        cur.close()
        conn.close()

# -----------------------------
# Pipeline principal
# -----------------------------
def main():
    resultados = {}

    print("Disparando requisições paralelas e simultâneas ao Snowflake...")
    # max_workers dinâmico configurado para rodar as 6 distribuidoras estritamente juntas
    with ThreadPoolExecutor(max_workers=len(DISTRIBUIDORAS)) as executor:

        futures = {
            executor.submit(run_query, nome, schema): nome
            for nome, schema in DISTRIBUIDORAS.items()
        }

        for future in as_completed(futures):
            empresa = futures[future]
            try:
                empresa_nome, df = future.result()
                resultados[empresa_nome] = df
            except Exception as exc:
                print(f"[Erro crítico] A thread da empresa {empresa} gerou uma exceção: {exc}")

    # -----------------------------
    # Exportação Excel consolidada
    # -----------------------------
    print("\nGerando arquivo Excel consolidado na rede...")
    if resultados and any(not df.empty for df in resultados.values()):
        with pd.ExcelWriter(OUTPUT_PATH, engine="xlsxwriter") as writer:
            for empresa, df in resultados.items():
                if df.empty:
                    continue
                df.to_excel(writer, sheet_name=empresa[:31], index=False)

        print(f"✔ Arquivo gerado com sucesso:")
        print(OUTPUT_PATH)
    else:
        print("\n[Aviso] Nenhuma informação válida foi retornada para gerar planilhas.")

# -----------------------------
# Entrypoint
# -----------------------------
if __name__ == "__main__":
    main()
