import snowflake.connector
import pandas as pd
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor  # <-- IMPORTANTE PARA PARALELISMO

# -----------------------------
# Configuração
# -----------------------------
DISTRIBUIDORAS = {
    "EQTL_MA": "EQTL_MA",
    "EQTL_PA": "EQTL_PA",
    "EQTL_PI": "EQTL_PI",
    "EQTL_AL": "EQTL_AL",
    "EQTL_AP": "EQTL_AP",
    "EQTL_RS": "EQTL_RS",
}

MES_COMPET = "202608"  # Formato: YYYYMM    

OUTPUT_PATH = Path(
    r"\\CMRSPPRARQ02\Gerencia Corporativa de Receita\Executiva de Inteligência e Gestão\14 - COLABORADORES\Elias\relatorio\gerados\202608\Contabilidade\reativos_excedente_{}.xlsx".format(
        MES_COMPET
    )
)
OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)

# -----------------------------
# Conexão Snowflake
# -----------------------------
def get_connection():
    return snowflake.connector.connect(
        account="khb56279.us-east-1",
        user="elias.correa@equatorialenergia.com.br",
        authenticator="externalbrowser",
        warehouse="WH_EQTLINFO",
        database="SB_FATURAMENTO",
        schema="PUBLIC",
    )

# -----------------------------
# SQL TEMPLATE
# -----------------------------
SQL_TEMPLATE = """
-- RELATÓRIO EXCEDENTE REATIVO
SELECT 
    '{EMP}' AS empresa, 
    B.instalacao, 
    a.documento_impressao, 
    mes_referencia,
    a.mes_competencia,
    SUBSTR(NVL(DECODE(B.subclasse, ' ', NULL, B.SUBCLASSE), CAD.CODIGO_SUBCLASSE), 1, 2) AS classe, 
    NVL(DECODE(B.subclasse, ' ', NULL, B.SUBCLASSE), CAD.CODIGO_SUBCLASSE) AS subclasse, 
    SUBSTR(NVL(DECODE(B.CATEGORIA_TARIFA, ' ', NULL, B.CATEGORIA_TARIFA), CAD.TIPO_TARIFA), 1, 1) AS grupo,
    SUBSTR(NVL(DECODE(B.CATEGORIA_TARIFA, ' ', NULL, B.CATEGORIA_TARIFA), CAD.TIPO_TARIFA), 1, 2) AS sub_grupo_tensao,
    a.item_ordenacao, 
    a.item_documento, 
    ITEM_DOCUMENTO_DESCRICAO AS descricao_item_documento,
    valor_faturado,
    valor_faturado - (montante_cofins + montante_icms + montante_pis) AS valor_sem_imposto
FROM (
    SELECT 
        mes_competencia, 
        documento_calculo, 
        documento_impressao, 
        MAX(item_documento) AS item_documento,  
        SUM(consumo) AS consumo_faturado, 
        item_ordenacao, 
        SUM(receita) AS valor_faturado,
        SUM(icms) AS montante_icms, 
        SUM(pis) AS montante_pis,
        SUM(cofins) AS montante_cofins
    FROM (
        SELECT 
            mes_COMPETENCIA, 
            documento_calculo, 
            documento_impressao, 
            CASE WHEN item_documento <> 'SUBT' THEN item_documento END AS item_documento, 
            NVL(item_ordenacao, item_documento) AS item_ordenacao, 
            consumo,
            SUM(receita) AS receita,
            (SUM(CASE WHEN tipo_imposto = 'MW2' THEN RECEITA ELSE 0 END)) AS ICMS,
            (SUM(CASE WHEN tipo_imposto = 'PIS' THEN RECEITA ELSE 0 END)) AS PIS,
            (SUM(CASE WHEN tipo_imposto = 'COF' THEN RECEITA ELSE 0 END)) AS COFINS
        FROM EQTLINFO_PRD.{SCHEMA}.itens_faturamento
        WHERE ITEM_ordenacao IN (
            'ZCRF', 'ZCRP', 'ZCRR', 'ZCRE', 'ZDRE', 'ZDRF', 'ZDRP',
            'YCRE', 'YCRF', 'YCRI', 'YCRP', 'YCRR', 'YDRE', 'YDRF', 'YDRP', 
            'YPD1', 'YPD2', 'YPD3', 'YTR1', 'YTR2', 'YTR3', 'YTR4', 'YTR5', 
            'Z565', 'Z566', 'Z567', 'ZCRE', 'ZCRF', 'ZCRI', 'ZCRP', 'ZCRR', 
            'ZDRE', 'ZDRF', 'ZDRP', 'ZPD1', 'ZPD2', 'ZPD3', 'ZTR1', 'ZTR2', 
            'ZTR3', 'ZTR4', 'ZTR5', 'ZCFI', 'ZCNI'
        ) 
        AND flag IN ('C', 'R')
        AND mes_competencia = '{MES}'
        GROUP BY 
            consumo, 
            mes_competencia, 
            CASE WHEN item_documento <> 'SUBT' THEN item_documento END, 
            NVL(item_ordenacao, item_documento), 
            documento_calculo, 
            documento_impressao
    ) zxc 
    GROUP BY 
        mes_competencia, 
        documento_calculo, 
        documento_impressao, 
        item_ordenacao
) a
INNER JOIN EQTLINFO_PRD.{SCHEMA}.faturamento b 
    ON a.mes_competencia = b.mes_competencia 
    AND a.documento_impressao = b.documento_impressao 
    AND a.documento_calculo = b.documento_calculo 
LEFT JOIN EQTLINFO_PRD.{SCHEMA}.TAB_item_documento c 
    ON a.item_documento = c.item_documento
INNER JOIN EQTLINFO_PRD.{SCHEMA}.TAB_CADASTRO CAD 
    ON CAD.INSTALACAO = B.INSTALACAO

"""

# -----------------------------
# Ajuste decimal → duas casas
# -----------------------------
DECIMAL_COLS = [
    "VALOR_FATURADO",
    "VALOR_SEM_IMPOSTO"
]

# -----------------------------
# Função Executada por cada Thread
# -----------------------------
def processar_distribuidora(empresa_nome, schema):
    print(f"[Iniciando] Carga paralela: {empresa_nome} (schema: {schema})...")
    
    # Cada consulta abre sua própria conexão para trabalhar em paralelo
    conn = get_connection()
    cur = conn.cursor()
    
    try:
        sql = SQL_TEMPLATE.format(SCHEMA=schema, MES=MES_COMPET, EMP=empresa_nome)
        cur.execute(sql)
        
        # fetch_pandas_all() elimina a necessidade de mapear colunas manualmente
        df = cur.fetch_pandas_all()

        # Formatador decimal
        for col in DECIMAL_COLS:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors="coerce").round(2)

        print(f"[Sucesso] {empresa_nome}: {len(df):,} linhas extraídas.")
        return empresa_nome, df

    except Exception as e:
        print(f"[Erro] Falha ao processar {empresa_nome}: {e}")
        return empresa_nome, pd.DataFrame()  # Retorna DataFrame vazio se falhar

    finally:
        cur.close()
        conn.close()

# -----------------------------
# Main pipeline
# -----------------------------
def main():
    resultados = {}

    print("Disparando extrações paralelas para o Snowflake...")
    # max_workers=6 garante que todos os estados rodem rigorosamente juntos
    with ThreadPoolExecutor(max_workers=len(DISTRIBUIDORAS)) as executor:
        futures = [
            executor.submit(processar_distribuidora, emp, sch)
            for emp, sch in DISTRIBUIDORAS.items()
        ]
        
        # Coleta os resultados assim que finalizarem
        for future in futures:
            empresa, df = future.result()
            if not df.empty:
                resultados[empresa] = df

    # Exportação final consolidada
    if resultados:
        print("\nGerando arquivo Excel consolidado...")
        with pd.ExcelWriter(OUTPUT_PATH, engine="xlsxwriter") as writer:
            for empresa, df in resultados.items():
                sheet = empresa[:31]
                df.to_excel(writer, sheet_name=sheet, index=False)
        print(f"Processo finalizado com sucesso!")
    else:
        print("\n[Aviso] Nenhuma informação válida foi retornada para o Excel.")

    print(f"\nArquivo salvo em:\n{OUTPUT_PATH}")

# Entrypoint
if __name__ == "__main__":
    main()
