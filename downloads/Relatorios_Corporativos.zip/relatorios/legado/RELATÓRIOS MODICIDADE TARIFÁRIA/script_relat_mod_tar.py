import snowflake.connector
import pandas as pd
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed  # <-- IMPORTANTE PARA PARALELISMO

# -----------------------------
# Configuração
# -----------------------------
DISTRIBUIDORAS = {
    "EQTL_MA": "EQTL_MA",
    "EQTL_PA": "EQTL_PA",
    "EQTL_PI": "EQTL_PI",
    "EQTL_AL": "EQTL_AL",
    "EQTL_AP": "EQTL_AP",
    "EQTL_RS": "EQTL_RS",
}

MES_COMPET = "202608"

OUTPUT_PATH = Path(
    r"\\CMRSPPRARQ02\Gerencia Corporativa de Receita\Executiva de Inteligência e Gestão\14 - COLABORADORES\Elias\relatorio\gerados\202608\Contabilidade\modicidade_tarifaria_{}.xlsx".format(
        MES_COMPET
    )
)
OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)

# -----------------------------
# Conexão Snowflake
# -----------------------------
def get_connection():
    return snowflake.connector.connect(
        account="khb56279.us-east-1",
        user="elias.correa@equatorialenergia.com.br",
        authenticator="externalbrowser",
        warehouse="WH_EQTLINFO",
        database="SB_FATURAMENTO",
        schema="PUBLIC",
    )

# -----------------------------
# SQL TEMPLATE
# -----------------------------
SQL_TEMPLATE = """
-- ===========================================
-- BLOCO MODIC TARIFÁRIA
-- ===========================================
SELECT
    '{EMP}' AS EMPRESA, REFERENCIA, MES_LANCAMENTO, CATEGORIA_DOC_SUBSTITUTO,
    STATUS_DOC_SUBST, OPERACAO, SUB_OPERACAO, DESCRICAO, ITEM_ESTATISTICO, max(CLASSE) AS classe,
    CONTA_CONTRATO, NUMERO_DOCUMENTO, BLOQUEIO, VALOR
FROM SB_FATURAMENTO.{SCHEMA}.BASE_MODIC_TAR_NOVO
WHERE REFERENCIA = '{MES}'
GROUP BY ALL
"""

# -----------------------------
# Ajuste decimal → duas casas
# -----------------------------
DECIMAL_COLS = [
    "VALOR"
]

# -----------------------------
# Função Executada por cada Thread
# -----------------------------
def processar_distribuidora(empresa_nome, schema):
    print(f"[Iniciando] Carga paralela: {empresa_nome} (schema: {schema})...")
    
    # Cada thread gerencia sua própria conexão para viabilizar o paralelismo
    conn = get_connection()
    cur = conn.cursor()
    
    try:
        sql = SQL_TEMPLATE.format(SCHEMA=schema, MES=MES_COMPET, EMP=empresa_nome)
        cur.execute(sql)
        
        # Coleta de alta velocidade utilizando Arrow
        df = cur.fetch_pandas_all()

        # Formatador decimal
        for col in DECIMAL_COLS:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors="coerce").round(2)

        print(f"[Sucesso] {empresa_nome} → {len(df):,} linhas carregadas.")
        return empresa_nome, df

    except Exception as e:
        print(f"[Erro] Falha ao processar {empresa_nome}: {e}")
        return empresa_nome, pd.DataFrame()

    finally:
        cur.close()
        conn.close()

# -----------------------------
# Main pipeline
# -----------------------------
def main():
    resultados = {}

    print("Disparando extrações simultâneas de Modicidade Tarifária para o Snowflake...")
    # Executa todas as distribuidoras do dicionário em paralelo
    with ThreadPoolExecutor(max_workers=len(DISTRIBUIDORAS)) as executor:
        futures = {
            executor.submit(processar_distribuidora, emp, sch): emp
            for emp, sch in DISTRIBUIDORAS.items()
        }
        
        # Consolida as respostas assim que as tarefas terminam
        for future in as_completed(futures):
            empresa = futures[future]
            try:
                empresa_nome, df = future.result()
                resultados[empresa_nome] = df
            except Exception as e:
                print(f"[Erro crítico] Exceção na thread da empresa {empresa}: {e}")

    # Exportação final consolidada
    print("\nGerando arquivo Excel consolidado...")
    if resultados and any(not df.empty for df in resultados.values()):
        with pd.ExcelWriter(OUTPUT_PATH, engine="xlsxwriter") as writer:
            for empresa, df in resultados.items():
                if df.empty:
                    continue
                sheet = empresa[:31]
                df.to_excel(writer, sheet_name=sheet, index=False)
        print("Arquivo Excel consolidado criado com sucesso!")
    else:
        print("\n[Aviso] Nenhuma informação válida foi retornada para gerar o arquivo.")

    print(f"\nArquivo salvo em:\n{OUTPUT_PATH}") 

# Entrypoint
if __name__ == "__main__":
    main()
