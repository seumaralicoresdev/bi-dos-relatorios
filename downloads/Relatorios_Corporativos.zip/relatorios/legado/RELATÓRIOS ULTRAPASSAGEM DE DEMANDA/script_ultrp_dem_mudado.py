import snowflake.connector
import pandas as pd
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor  # <-- IMPORTANTE PARA PARALELISMO

# -----------------------------
# Configuração
# -----------------------------
DISTRIBUIDORAS = {
   "EQTL_MA": "EQTL_MA",
   "EQTL_PA": "EQTL_PA",
   "EQTL_PI": "EQTL_PI",
   "EQTL_AL": "EQTL_AL",
   "EQTL_AP": "EQTL_AP",
   "EQTL_RS": "EQTL_RS",
}

MES_COMPET = "202608"

OUTPUT_PATH = Path(
    r"\\CMRSPPRARQ02\Gerencia Corporativa de Receita\Executiva de Inteligência e Gestão\14 - COLABORADORES\Elias\relatorio\gerados\202608\Contabilidade\ultrapassagem_demanda_{}.xlsx".format(
        MES_COMPET
    )
)
OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)

# -----------------------------
# Conexão Snowflake
# -----------------------------
def get_connection():
    return snowflake.connector.connect(
        account="khb56279.us-east-1",
        user="elias.correa@equatorialenergia.com.br",
        authenticator="externalbrowser",
        warehouse="WH_EQTLINFO",
        database="SB_FATURAMENTO",
        schema="PUBLIC",
    )

# -----------------------------
# SQL TEMPLATE
# -----------------------------
# Corrigido marcador da empresa para minúsculo '{emp}' para bater com o .format() da query antiga
SQL_TEMPLATE = """
SELECT 
    '{EMP}' AS empresa, 
    b.instalacao, 
    a.documento_impressao, 
    b.mes_referencia, 
    a.mes_competencia, 
    SUBSTR(NVL(DECODE(b.subclasse, ' ', NULL, b.subclasse), d.codigo_subclasse), 1, 2) AS classe, 
    NVL(DECODE(b.subclasse, ' ', NULL, b.subclasse), d.codigo_subclasse) AS subclasse, 
    SUBSTR(NVL(b.categoria_tarifa, d.tipo_tarifa), 1, 1) AS grupo, 
    SUBSTR(NVL(b.categoria_tarifa, d.tipo_tarifa), 1, 2) AS sub_grupo_tensao, 
    a.item_documento, 
    c.item_documento_descricao AS descricao_item_documento, 
    a.valor_faturado, 
    a.valor_faturado - (a.montante_cofins + a.montante_icms + a.montante_pis) AS valor_sem_imposto 
FROM ( 
    SELECT 
        mes_competencia, 
        documento_calculo, 
        documento_impressao, 
        item_ordenacao, 
        MAX(item_documento) AS item_documento, 
        SUM(consumo) AS consumo_faturado, 
        SUM(receita) AS valor_faturado, 
        MAX(icms) AS montante_icms, 
        MAX(pis) AS montante_pis, 
        MAX(cofins) AS montante_cofins 
    FROM ( 
        SELECT 
            mes_competencia, 
            documento_calculo, 
            documento_impressao, 
            CASE WHEN item_documento <> 'SUBT' THEN item_documento END AS item_documento, 
            NVL(item_ordenacao, item_documento) AS item_ordenacao, 
            consumo, 
            SUM(receita) AS receita, 
            SUM(CASE WHEN tipo_imposto = 'MW2' THEN receita ELSE 0 END) AS icms, 
            SUM(CASE WHEN tipo_imposto = 'PIS' THEN receita ELSE 0 END) AS pis, 
            SUM(CASE WHEN tipo_imposto = 'COF' THEN receita ELSE 0 END) AS cofins 
        FROM EQTLINFO_PRD.{SCHEMA}.itens_faturamento 
        WHERE item_ordenacao IN ( 
            'YDGU', 'ZDGU', 'YRUF', 'ZRUF', 'YRUP', 'ZRUP', 'YDU', 'Z340', 'ZDU', 
            'YDUF', 'ZDUF', 'YDUP', 'ZDUP', 'YMUE', 'ZMUE', 'YMUT', 'ZMUT', 
            'YUUF', 'ZUUF', 'YUUP', 'ZUUP', 'YUUL', 'ZUUL' 
        ) 
        AND flag IN ('C', 'R') 
        AND mes_competencia = '{MES}' 
        GROUP BY 
            consumo, 
            mes_competencia, 
            CASE WHEN item_documento <> 'SUBT' THEN item_documento END, 
            NVL(item_ordenacao, item_documento), 
            documento_calculo, 
            documento_impressao 
    ) zxc 
    GROUP BY 
        mes_competencia, 
        documento_calculo, 
        documento_impressao, 
        item_ordenacao 
) a 
INNER JOIN EQTLINFO_PRD.{SCHEMA}.faturamento b 
    ON a.mes_competencia = b.mes_competencia 
    AND a.documento_impressao = b.documento_impressao 
    AND a.documento_calculo = b.documento_calculo 
LEFT JOIN EQTLINFO_PRD.{SCHEMA}.tab_item_documento c 
    ON a.item_documento = c.item_documento 
LEFT JOIN EQTLINFO_PRD.{SCHEMA}.tab_cadastro d 
    ON d.instalacao = b.instalacao

"""

# -----------------------------
# Ajuste decimal → duas casas
# -----------------------------
DECIMAL_COLS = [
    "VALOR_FATURADO",
    "CONSUMO_FATURADO",
    "MONTANTE_COFINS",
    "MONTANTE_ICMS",
    "MONTANTE_PIS",
    "VALOR_SEM_IMPOSTO"
]

# -----------------------------
# Função de Carga por Distribuidora (Trabalhadora)
# -----------------------------
def processar_distribuidora(empresa_nome, schema):
    print(f"[Iniciando] Carga paralela: {empresa_nome} (schema: {schema})...")
    
    # Abrindo conexões independentes por thread
    conn = get_connection()
    cur = conn.cursor()
    
    try:
        sql = SQL_TEMPLATE.format(SCHEMA=schema, MES=MES_COMPET, EMP=empresa_nome)
        cur.execute(sql)
        
        # Uso do fetch rápido para DataFrame direto da API binária
        df = cur.fetch_pandas_all()

        # Formatador decimal
        for col in DECIMAL_COLS:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors="coerce").round(2)

        print(f"[Sucesso] {empresa_nome}: {len(df):,} linhas carregadas.")
        return empresa_nome, df

    except Exception as e:
        print(f"[Erro] Falha ao processar {empresa_nome}: {e}")
        return empresa_nome, pd.DataFrame()

    finally:
        cur.close()
        conn.close()

# -----------------------------
# Main pipeline
# -----------------------------
def main():
    resultados = {}

    print("Disparando extrações simultâneas para o Snowflake...")
    # Roda as distribuidoras descomentadas de forma paralela no pool
    with ThreadPoolExecutor(max_workers=len(DISTRIBUIDORAS)) as executor:
        futures = [
            executor.submit(processar_distribuidora, emp, sch)
            for emp, sch in DISTRIBUIDORAS.items()
        ]
        
        for future in futures:
            empresa, df = future.result()
            if not df.empty:
                resultados[empresa] = df

    # Geração única consolidada para a planilha da rede
    if resultados:
        print("\nGerando arquivo Excel consolidado...")
        with pd.ExcelWriter(OUTPUT_PATH, engine="xlsxwriter") as writer:
            for empresa, df in resultados.items():
                sheet = empresa[:31]
                df.to_excel(writer, sheet_name=sheet, index=False)
        print("Arquivo criado com sucesso!")
    else:
        print("\n[Aviso] Nenhuma informação retornou das distribuidoras.")

    print(f"\nProcesso finalizado. Destino:\n{OUTPUT_PATH}")

# Entrypoint
if __name__ == "__main__":
    main()