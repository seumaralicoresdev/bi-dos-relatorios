import snowflake.connector
import pandas as pd
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor  # <-- IMPORTANTE PARA PARALELISMO

# -----------------------------
# Configuração
# -----------------------------
DISTRIBUIDORAS = {
    # "CCS_MA": "CCS_MA",
    # "CCS_PA": "CCS_PA",
    # "CCS_PI": "CCS_PI",
    # "CCS_AL": "CCS_AL",
    # "CCS_AP": "CCS_AP",
    "CCS_RS": "CCS_RS",
}

MES_COMPET = "202607"

OUTPUT_PATH = Path(
    rf"\\CMRSPPRARQ02\Gerencia Corporativa de Receita\Executiva de Inteligência e Gestão\14 - COLABORADORES\Elias\relatorio\gerados\202607\Contabilidade\RS_mmgd_{MES_COMPET}.xlsx"
)
OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)

# -----------------------------
# Conexão Snowflake
# -----------------------------
def get_connection():
    return snowflake.connector.connect(
        account="khb56279.us-east-1",
        user="elias.correa@equatorialenergia.com.br",
        authenticator="externalbrowser",
        warehouse="WH_EQTLINFO",
        database="SB_FATURAMENTO",
        schema="PUBLIC",
    )

# -----------------------------
# SQL TEMPLATE (CORRIGIDO)
# -----------------------------
SQL_TEMPLATE = """
SELECT 
    '{EMP}' AS EMPRESA,
    SUBSTR(A.ALLOC_DATE, 1, 6) AS MES,
    SUM(A.QUANT) AS KWH
FROM EQTLINFO_RAW.{SCHEMA}.EENRGY_CR_BR A
WHERE SUBSTR(A.ALLOC_DATE, 1, 6) BETWEEN 
      TO_CHAR(ADD_MONTHS(TO_DATE('{MES}01','YYYYMMDD'),-60),'YYYYMM')
      AND '{MES}'
GROUP BY 
    SUBSTR(A.ALLOC_DATE, 1, 6)
ORDER BY MES
"""

# -----------------------------
# Função de Carga por Distribuidora (Trabalhadora)
# -----------------------------
def processar_distribuidora(empresa_nome, schema):
    print(f"[Iniciando] Carga paralela: {empresa_nome} (schema: {schema})...")
    
    # Cada consulta abre sua própria conexão para trabalhar em paralelo
    conn = get_connection()
    
    try:
        with conn.cursor() as cur:
            sql = SQL_TEMPLATE.format(
                SCHEMA=schema,
                MES=MES_COMPET,
                EMP=empresa_nome
            )
            cur.execute(sql)
            
            # Extração rápida em formato tabular binário nativo
            df = cur.fetch_pandas_all()
            
        print(f"[Sucesso] {empresa_nome}: {len(df):,} linhas extraídas.")
        return empresa_nome, df

    except Exception as e:
        print(f"[Erro] Falha ao processar {empresa_nome}: {e}")
        return empresa_nome, pd.DataFrame()

    finally:
        conn.close()

# -----------------------------
# Main pipeline
# -----------------------------
def main():
    resultados = {}

    print("Disparando extrações simultâneas de MMGD para o Snowflake...")
    # Executa em lotes simultâneos para todas as distribuidoras do dicionário
    with ThreadPoolExecutor(max_workers=len(DISTRIBUIDORAS)) as executor:
        futures = [
            executor.submit(processar_distribuidora, emp, sch)
            for emp, sch in DISTRIBUIDORAS.items()
        ]
        
        # Consolida as respostas ao fim do processamento de cada thread
        for future in futures:
            empresa, df = future.result()
            if not df.empty:
                resultados[empresa] = df

    # Exportação final unificada
    if resultados:
        print("\nGerando arquivo Excel consolidado...")
        with pd.ExcelWriter(OUTPUT_PATH, engine="xlsxwriter") as writer:
            for empresa, df in resultados.items():
                sheet = empresa[:31]
                df.to_excel(writer, sheet_name=sheet, index=False)
        print("Processo finalizado com sucesso!")
    else:
        print("\n[Aviso] Nenhum dado foi retornado pelas distribuidoras para montagem das abas.")

    print(f"\nArquivo salvo em:\n{OUTPUT_PATH}")


if __name__ == "__main__":
    main()
