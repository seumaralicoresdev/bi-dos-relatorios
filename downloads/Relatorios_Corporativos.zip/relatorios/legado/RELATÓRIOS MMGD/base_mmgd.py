import snowflake.connector
import pandas as pd
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor

# ----------------------------------------------------
# CONFIGURAÇÃO
# ----------------------------------------------------
# O dicionário mapeia o nome de exibição da empresa ao seu respectivo Schema
DISTRIBUIDORAS = {
    "EQTL_MA": "EQTL_MA",
    "EQTL_PA": "EQTL_PA",
    "EQTL_PI": "EQTL_PI",
    "EQTL_AL": "EQTL_AL",
    "EQTL_AP": "EQTL_AP",
    "EQTL_RS": "EQTL_RS",
}

MES_COMPET = "202608"

# Define o caminho da pasta com o nome exato solicitado dentro de 'Contabilidade'
DIRETORIO_CONTABILIDADE = Path(
    rf"\\CMRSPPRARQ02\Gerencia Corporativa de Receita\Executiva de Inteligência e Gestão\14 - COLABORADORES\Elias\relatorio\gerados\202608\Contabilidade"
)
PASTA_BASES = DIRETORIO_CONTABILIDADE / f"base_mmgd_{MES_COMPET}"

# Cria a nova pasta especificada e toda a árvore de diretórios anterior, se necessário
PASTA_BASES.mkdir(parents=True, exist_ok=True)

# ----------------------------------------------------
# CONEXÃO
# ----------------------------------------------------
def get_connection():
    return snowflake.connector.connect(
        account="khb56279.us-east-1",
        user="elias.correa@equatorialenergia.com.br",
        authenticator="externalbrowser",
        warehouse="WH_EQTLINFO",
        database="SB_FATURAMENTO",
        schema="PUBLIC",
    )

# ----------------------------------------------------
# SQL (CORRIGIDO PARA O SNOWFLAKE)
# ----------------------------------------------------
SQL_TEMPLATE = """
SELECT
    A.MES_COMPETENCIA AS MES_COMPETENCIA,
    A.MES AS MES,
    REPLACE(TO_CHAR(SUM(A.KWH)), '.', ',') AS KWH,
    A.CONTRATO_GERADORA AS CONTRATO_GERADORA,
    COALESCE(A.CONTA_CONTRATO_GERADORA, 'SEM_CONTA') AS CONTA_CONTRATO_GERADORA
FROM SB_FATURAMENTO.{SCHEMA}.BASE_MMGD_CREDITOS A 
WHERE A.MES BETWEEN 
      TO_CHAR(ADD_MONTHS(TO_DATE('{MES}', 'YYYYMM'), -60), 'YYYYMM')
      AND '{MES}'
GROUP BY
    A.MES_COMPETENCIA,
    A.MES,
    A.CONTRATO_GERADORA,
    A.CONTA_CONTRATO_GERADORA
HAVING SUM(A.KWH) <> 0
ORDER BY
    MES,
    CONTRATO_GERADORA
"""

# ----------------------------------------------------
# PROCESSAMENTO
# ----------------------------------------------------
def processar_distribuidora(empresa, schema):

    print(f"[Iniciando] {empresa}")

    conn = get_connection()

    try:
        with conn.cursor() as cur:
            # Substitui {SCHEMA} e {MES} com as variáveis corretas
            sql = SQL_TEMPLATE.format(
                SCHEMA=schema,
                MES=MES_COMPET
            )
            
            cur.execute(sql)
            df = cur.fetch_pandas_all()

        print(f"[Sucesso] {empresa}: {len(df):,} linhas")
        return empresa, df

    except Exception as e:
        print(f"[Erro] {empresa}")
        print(e)
        return empresa, pd.DataFrame()

    finally:
        conn.close()

# ----------------------------------------------------
# MAIN
# ----------------------------------------------------
def main():

    resultados = {}

    print("Disparando extrações simultâneas de MMGD...")

    with ThreadPoolExecutor(max_workers=len(DISTRIBUIDORAS)) as executor:

        # Correção na iteração: desempacota chave e valor direto do dicionário plano
        futures = [
            executor.submit(processar_distribuidora, empresa, schema)
            for empresa, schema in DISTRIBUIDORAS.items()
        ]

        for future in futures:

            empresa, df = future.result()

            if not df.empty:
                resultados[empresa] = df

    if resultados:

        print(f"\nGerando arquivos CSV na pasta '{PASTA_BASES.name}'...")

        for empresa, df in resultados.items():
            
            # Define o caminho de salvamento direto dentro da pasta solicitada
            csv_path = PASTA_BASES / f"base_mmgd_{MES_COMPET}_{empresa}.csv"
            
            print(f"Salvando {empresa} em: {PASTA_BASES.name}\\{csv_path.name}")
            
            # Exportação com ";" e encoding correto para o Excel PT-BR reconhecer acentos/vírgulas
            df.to_csv(
                csv_path,
                index=False,
                sep=";",
                encoding="utf-8-sig"
            )

        print("\nTodos os arquivos CSV individuais foram salvos com sucesso!")

    else:
        print("\nNenhum dado populado foi retornado pelo Snowflake.")

    print(f"\nOs relatórios foram gravados na pasta:\n{PASTA_BASES}")

# ----------------------------------------------------
if __name__ == "__main__":
    main()
