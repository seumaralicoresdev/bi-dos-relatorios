import snowflake.connector
import pandas as pd
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor

# ----------------------------------------------------
# CONFIGURAÇÃO
# ----------------------------------------------------
DISTRIBUIDORAS = {
    # "EQTL_MA": {"prd_schema": "EQTL_MA", "raw_schema": "CCS_MA"},
    # "EQTL_PA": {"prd_schema": "EQTL_PA", "raw_schema": "CCS_PA"},
    # "EQTL_PI": {"prd_schema": "EQTL_PI", "raw_schema": "CCS_PI"},
    # "EQTL_AL": {"prd_schema": "EQTL_AL", "raw_schema": "CCS_AL"},
    # "EQTL_AP": {"prd_schema": "EQTL_AP", "raw_schema": "CCS_AP"},
    "EQTL_RS": {"prd_schema": "EQTL_RS", "raw_schema": "CCS_RS"},
}

MES_COMPET = "202607"

# Define o caminho da pasta com o nome exato solicitado dentro de 'Contabilidade'
OUTPUT_PATH = Path(
    rf"\\CMRSPPRARQ02\Gerencia Corporativa de Receita\Executiva de Inteligência e Gestão\14 - COLABORADORES\Elias\relatorio\gerados\202607\Contabilidade\rs_base_mmgd_{MES_COMPET}.xlsx"
)
PASTA_BASES = OUTPUT_PATH.parent
PASTA_BASES.mkdir(parents=True, exist_ok=True)

# ----------------------------------------------------
# CONEXÃO
# ----------------------------------------------------
def get_connection():
    return snowflake.connector.connect(
        account="khb56279.us-east-1",
        user="elias.correa@equatorialenergia.com.br",
        authenticator="externalbrowser",
        warehouse="WH_EQTLINFO",
        database="SB_FATURAMENTO",
        schema="PUBLIC",
    )

# ----------------------------------------------------
# SQL
# ----------------------------------------------------
SQL_TEMPLATE = """
SELECT
    SUBSTR(A.ALLOC_DATE,1,6) AS MES,
    REPLACE(TO_CHAR(SUM(A.QUANT)),'.',',') AS KWH,
    A.GEN_CONTRACT AS CONTRATO_GERADORA,
    COALESCE(CT.CONTA_CONTRATO, 'SEM_CONTA') AS CONTA_CONTRATO_GERADORA
FROM EQTLINFO_RAW.{RAW_SCHEMA}.EENRGY_CR_BR A
LEFT JOIN (
    SELECT
        CONTRATO,
        MAX(CONTA_CONTRATO) AS CONTA_CONTRATO
    FROM EQTLINFO_PRD.{PRD_SCHEMA}.TAB_CONTRATO
    GROUP BY CONTRATO
) CT ON CT.CONTRATO = A.GEN_CONTRACT
WHERE SUBSTR(A.ALLOC_DATE, 1, 6) BETWEEN 
      TO_CHAR(ADD_MONTHS(TO_DATE('{MES}01', 'YYYYMMDD'), -60), 'YYYYMM')
      AND '{MES}'
GROUP BY
    SUBSTR(A.ALLOC_DATE, 1, 6),
    A.GEN_CONTRACT,
    CT.CONTA_CONTRATO
HAVING SUM(A.QUANT) <> 0
ORDER BY
    MES,
    CONTRATO_GERADORA
"""

# ----------------------------------------------------
# PROCESSAMENTO
# ----------------------------------------------------
def processar_distribuidora(empresa, schemas):

    raw_schema = schemas["raw_schema"]
    prd_schema = schemas["prd_schema"]

    print(f"[Iniciando] {empresa}")

    conn = get_connection()

    try:
        with conn.cursor() as cur:
            sql = SQL_TEMPLATE.format(
                RAW_SCHEMA=raw_schema,
                PRD_SCHEMA=prd_schema,
                MES=MES_COMPET
            )
            
            cur.execute(sql)
            df = cur.fetch_pandas_all()

        print(f"[Sucesso] {empresa}: {len(df):,} linhas")
        return empresa, df

    except Exception as e:
        print(f"[Erro] {empresa}")
        print(e)
        return empresa, pd.DataFrame()

    finally:
        conn.close()

# ----------------------------------------------------
# MAIN
# ----------------------------------------------------
def main():

    resultados = {}

    print("Disparando extrações simultâneas de MMGD...")

    with ThreadPoolExecutor(max_workers=len(DISTRIBUIDORAS)) as executor:

        futures = [
            executor.submit(processar_distribuidora, empresa, schemas)
            for empresa, schemas in DISTRIBUIDORAS.items()
        ]

        for future in futures:

            empresa, df = future.result()

            if not df.empty:
                resultados[empresa] = df

    if resultados:

        print(f"\nGerando arquivos CSV na pasta '{PASTA_BASES.name}'...")

        for empresa, df in resultados.items():
            
            # Define o caminho de salvamento direto dentro da pasta solicitada
            csv_path = PASTA_BASES / f"base_mmgd_{MES_COMPET}_{empresa}.csv"
            
            print(f"Salvando {empresa} em: {PASTA_BASES.name}\\{csv_path.name}")
            
            # Exportação com ";" e encoding correto para o Excel PT-BR reconhecer acentos/vírgulas
            df.to_csv(
                csv_path,
                index=False,
                sep=";",
                encoding="utf-8-sig"
            )

        print("\nTodos os arquivos CSV individuais foram salvos com sucesso!")

    else:
        print("\nNenhum dado populado foi retornado pelo Snowflake.")

    print(f"\nOs relatórios foram gravados na pasta:\n{PASTA_BASES}")

# ----------------------------------------------------
if __name__ == "__main__":
    main()
