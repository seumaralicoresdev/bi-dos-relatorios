import snowflake.connector
import pandas as pd
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed  # <-- IMPORTANTE PARA PARALELISMO

# -----------------------------
# Configuração
# -----------------------------
DISTRIBUIDORAS = {
#    "EQTL_MA": "EQTL_MA",
#    "EQTL_PA": "EQTL_PA",
#    "EQTL_PI": "EQTL_PI",
#    "EQTL_AL": "EQTL_AL",
#    "EQTL_AP": "EQTL_AP",
   "EQTL_RS": "EQTL_RS",
}

MES_COMPET = "202606"

OUTPUT_PATH = Path(
    r"\\CMRSPPRARQ02\Gerencia Corporativa de Receita\Executiva de Inteligência e Gestão",
    r"14 - COLABORADORES\Elias\relatorio\gerados\202606\Tributario\Gerados_RS",
    f"escassez_hidrica_rs_{MES_COMPET}.xlsx"
)
OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)

# -----------------------------
# Conexão Snowflake
# -----------------------------
def get_connection():
    return snowflake.connector.connect(
        account="khb56279.us-east-1",
        user="elias.correa@equatorialenergia.com.br",
        authenticator="externalbrowser",
        warehouse="WH_EQTLINFO",
        database="SB_FATURAMENTO",
        schema="PUBLIC",
    )

# -----------------------------
# SQL TEMPLATE
# -----------------------------
SQL_TEMPLATE = """
WITH BASE AS (
    SELECT
        '{EMP}' AS ESTADO,
        A.MES_COMPETENCIA,
        B.MES_REFERENCIA,
        A.DOCUMENTO_IMPRESSAO,
        B.ESTORNADO,
        B.INSTALACAO,
        (B.CONSUMO_FATURADO / 1000) AS MWH,
        A.RECEITA,
        B.DATA_DADOS
    FROM EQTLINFO_PRD.{SCHEMA}.ITENS_FATURAMENTO A
    LEFT JOIN EQTLINFO_PRD.{SCHEMA}.FATURAMENTO B
        ON A.DOCUMENTO_IMPRESSAO = B.DOCUMENTO_IMPRESSAO
    WHERE A.ITEM_DOCUMENTO = 'ZESCAS'
      AND A.MES_COMPETENCIA BETWEEN
            TO_VARCHAR(DATEADD(MONTH,-6,CURRENT_DATE()),'YYYYMM')
        AND TO_VARCHAR(DATEADD(MONTH,-1,CURRENT_DATE()),'YYYYMM')
)
SELECT *
FROM BASE

UNION ALL

SELECT
    '{EMP}' AS ESTADO,
    TO_VARCHAR(DATEADD(MONTH,-1,CURRENT_DATE()),'YYYYMM') AS MES_COMPETENCIA,
    TO_VARCHAR(DATEADD(MONTH,-1,CURRENT_DATE()),'YYYYMM') AS MES_REFERENCIA,
    NULL AS DOCUMENTO_IMPRESSAO,
    NULL AS ESTORNADO,
    NULL AS INSTALACAO,
    0 AS MWH,
    0 AS RECEITA,
    NULL AS DATA_DADOS
"""

# -----------------------------
# Ajuste decimal → Colunas Reais do Script
# -----------------------------
DECIMAL_COLS = ["MWH", "RECEITA"]

# -----------------------------
# Função Executada por cada Thread
# -----------------------------
def processar_distribuidora(empresa_nome, schema):
    print(f"[Iniciando] Carga paralela: {empresa_nome} (schema: {schema})...")
    conn = get_connection()
    cur = conn.cursor()
    
    try:
        sql = SQL_TEMPLATE.format(
            SCHEMA=schema,
            MES=MES_COMPET,
            EMP=empresa_nome,
        )
        cur.execute(sql)
        
        # Coleta ultra rápida convertida de Arrow binário para DataFrame
        df = cur.fetch_pandas_all()

        if df.empty:
            print(f"[Aviso] {empresa_nome} sem registros.")
            return empresa_nome, df

        # Padronizar nomes de colunas em caixa alta
        df.columns = [col.upper() for col in df.columns]

        # Formatador decimal
        for col in DECIMAL_COLS:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors="coerce").round(2)

        # Remover Timezone de colunas datetime (Evita problemas ao salvar no Excel)
        tz_cols = df.select_dtypes(include=["datetimetz"]).columns
        for col in tz_cols:
            df[col] = df[col].dt.tz_localize(None)

        print(f"[Sucesso] {empresa_nome} → {len(df):,} registros carregados.")
        return empresa_nome, df

    except Exception as e:
        print(f"[Erro] Falha ao processar {empresa_nome}: {e}")
        return empresa_nome, pd.DataFrame()

    finally:
        cur.close()
        conn.close()

# -----------------------------
# Main pipeline
# -----------------------------
def main():
    resultados = {}

    print("Disparando extrações simultâneas de Escassez Hídrica para o Snowflake...")
    with ThreadPoolExecutor(max_workers=len(DISTRIBUIDORAS)) as executor:
        futures = {
            executor.submit(processar_distribuidora, emp, sch): emp
            for emp, sch in DISTRIBUIDORAS.items()
        }
        
        for future in as_completed(futures):
            empresa = futures[future]
            try:
                empresa_nome, df = future.result()
                resultados[empresa_nome] = df
            except Exception as e:
                print(f"[Erro crítico] Exceção gerada na thread {empresa}: {e}")

    # Exportação final unificada
    print("\nGerando arquivo Excel consolidado...")
    if resultados and any(not df.empty for df in resultados.values()):
        with pd.ExcelWriter(OUTPUT_PATH, engine="xlsxwriter") as writer:
            for empresa, df in resultados.items():
                if df.empty:
                    continue
                sheet = empresa[:31]
                df.to_excel(writer, sheet_name=sheet, index=False)
        print(f"✔ Arquivo criado com sucesso!")
    else:
        print("\n[Aviso] Nenhuma informação útil retornou para salvar na planilha.")

    print(f"\nProcesso finalizado. Destino:\n{OUTPUT_PATH}")


if __name__ == "__main__":
    main()
