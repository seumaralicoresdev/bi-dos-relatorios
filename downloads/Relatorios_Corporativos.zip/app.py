from __future__ import annotations

from pathlib import Path
import sys

from PySide6.QtGui import QIcon
from PySide6.QtWidgets import QApplication

from app.report_registry import ReportRegistry
from app.settings import default_settings_path
from ui.main_window import MainWindow


def _application_root() -> Path:
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        return Path(sys._MEIPASS)  # type: ignore[attr-defined]
    return Path(__file__).resolve().parent


def main() -> int:
    root = _application_root()
    application = QApplication(sys.argv)
    icon_path = root / "ui" / "assets" / "app_icon.svg"
    if icon_path.is_file():
        application.setWindowIcon(QIcon(str(icon_path)))
    style_path = root / "ui" / "styles.qss"
    if style_path.is_file():
        application.setStyleSheet(style_path.read_text(encoding="utf-8"))
    window = MainWindow(ReportRegistry.default(), default_settings_path(), root / "relatorios" / "legado")
    if icon_path.is_file():
        window.setWindowIcon(QIcon(str(icon_path)))
    window.show()
    return application.exec()


if __name__ == "__main__":
    raise SystemExit(main())
