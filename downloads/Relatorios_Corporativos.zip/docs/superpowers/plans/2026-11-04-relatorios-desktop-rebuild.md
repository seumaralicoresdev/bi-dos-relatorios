# Relatórios Desktop — Rebuild and Verification Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Deliver a Windows-ready PySide6 desktop package that executes the 16 existing Snowflake reports from the original source ZIP, writes them to the configured monthly folders, and remains responsive while reporting per-report and total duration.

**Architecture:** Keep the original report scripts and SQL as the source of truth. The application loads each script through a controlled adapter, overrides only competence, selected distributors, output paths, and Snowflake connection settings, and executes reports sequentially while preserving each script's internal distributor parallelism. A batch bootstrap authenticates once and enables Snowflake temporary-credential caching; query workers use independent connections, because a live Snowflake connection must not be shared across the scripts' concurrent distributor threads.

**Tech Stack:** Python 3.11+, PySide6, pandas, XlsxWriter, openpyxl, Snowflake Connector for Python, standard-library `unittest`, PyInstaller for Windows.

**Spec:** `docs/superpowers/specs/2026-09-03-relatorios-desktop-pyside6-design.md` (the approved design is retained in the project documentation and reconstructed from the Library source when packaging).

## Global Constraints

- Preserve SQL, joins, filters, transformations, worksheet names, and report business rules from `scripts_relatorios_py.zip`.
- Do not make the desktop application depend on the installation directory for writable settings or history.
- Accept competence only as `YYYYMM`, with a valid month.
- Support `EQTL_MA`, `EQTL_PA`, `EQTL_PI`, `EQTL_AL`, `EQTL_AP`, and `EQTL_RS` individually.
- Default output is `{root}\\{YYYYMM}\\Contabilidade` or `{root}\\{YYYYMM}\\Tributario`.
- Do not create `Gerados_RS` unless the explicit option is enabled.
- Never store a Snowflake password or token in settings.
- Do not share one live Snowflake connection between distributor threads.
- The package must run from a fresh Windows checkout with `python app.py`; the Windows executable is built with `build_windows.bat`.

## Review Focus

- Unicode folder/module names and Windows paths: tests must load report modules and build paths without ASCII-only assumptions.
- Partial distributor selection: the adapter must pass only the selected distributors, including the nested schema mapping used by Clientes and Saldo Bloqueado.
- Empty result or missing output: the runner must report an actionable warning/error instead of marking a report successful.
- Snowflake authentication/cache failure: the batch must fail clearly and close all connections without leaving the UI worker stuck.
- PySide6 enum compatibility: checkbox state operations must use `Qt.CheckState`, never integer literals.

### Task 1: Bootstrap project and preserve the original report source

**Files:**
- Create: `app/`, `ui/`, `config/`, `tests/`, `relatorios/legado/`
- Create: `source_manifest.json`
- Copy: the 35 Python modules from `scripts_relatorios_py.zip` into `relatorios/legado/`
- Create: `requirements.txt`, `requirements-dev.txt`, `README.md`, `build_windows.bat`
- Test: `tests/test_source_inventory.py`

**Interfaces:**
- Produces a package-relative legacy root and a manifest of report IDs, original relative paths, and SHA-256 hashes.

- [ ] Write failing inventory tests for 16 main report entrypoints, the MMGD helper, Unicode paths, and unchanged SQL fingerprints.
- [ ] Run `python -m unittest tests.test_source_inventory -v`; expect failure because the application tree is absent.
- [ ] Extract/copy the recovered original modules and implement the inventory/manifest check.
- [ ] Run the inventory test and a Python compilation pass; expect all source files to parse.
- [ ] Record the source archive and hashes in `source_manifest.json`.

### Task 2: Domain models, settings, path builder, and report catalog

**Files:**
- Create: `app/models.py`
- Create: `app/settings.py`
- Create: `app/path_builder.py`
- Create: `app/report_registry.py`
- Test: `tests/test_domain.py`

**Interfaces:**
- `ExecutionRequest`, `ReportDefinition`, and `ExecutionResult` are immutable/simple domain records.
- `validate_competencia(value) -> str` validates `YYYYMM`.
- `build_report_path(root, competencia, definition, separate_rs=False) -> Path` builds the final output path.
- `ReportRegistry.all()`, `.by_id(report_id)`, and `.for_category(category)` expose the 16 reports.

- [ ] Write failing tests for competence validation, both categories, nested distributor metadata, normal output paths, and optional `Gerados_RS`.
- [ ] Run the focused tests and verify they fail for missing modules.
- [ ] Implement the domain layer with no Snowflake or Qt imports.
- [ ] Run `python -m unittest tests.test_domain -v` and the complete current suite.

### Task 3: Snowflake connection policy and legacy adapter

**Files:**
- Create: `app/snowflake_session.py`
- Create: `app/legacy_adapter.py`
- Create: `app/report_runner.py`
- Test: `tests/test_adapter.py`
- Test: `tests/test_runner.py`

**Interfaces:**
- `SnowflakeSession.prepare()` performs the one-time external-browser bootstrap with temporary-credential caching when available.
- `SnowflakeSession.connect()` returns a new independent connector connection for a distributor thread.
- `LegacyAdapter.run(definition, request, output_path, log) -> Path | None` loads a module, overrides only runtime globals, and invokes its `main()`.
- `ReportRunner.run(definition, request, log) -> ExecutionResult` captures output, verifies artifacts, and records duration.

- [ ] Write failing tests for independent connections, cleanup, selected-distributor override, output override, MMGD base-folder override, and runner missing-artifact handling using a temporary fake legacy module.
- [ ] Run the focused tests and verify the expected failures.
- [ ] Implement the connection policy and adapter. Do not modify the original SQL or share live connections across threads.
- [ ] Run the focused tests, source hash check, and complete suite.

### Task 4: Batch queue, timers, logging, history, and result inspection

**Files:**
- Create: `app/batch.py`
- Create: `app/history.py`
- Create: `app/result_inspector.py`
- Test: `tests/test_batch.py`
- Test: `tests/test_history.py`

**Interfaces:**
- `build_execution_jobs(request, registry) -> list[ReportDefinition]` preserves catalog order.
- `ReportWorker` runs reports sequentially, emits report and batch events, supports cooperative cancellation, and exposes `started_at`, `report_started_at`, and `elapsed_seconds`.
- History is stored in a user-writable JSON file and never beside a one-file executable's temporary extraction directory.

- [ ] Write failing tests for sequential order, per-report duration, total duration, cancellation before the next report, and history round-trip.
- [ ] Run focused tests and verify failure.
- [ ] Implement the worker as a Qt-independent service first, with optional Qt signal bridge.
- [ ] Run focused tests and complete suite.

### Task 5: PySide6 interface and compatibility correction

**Files:**
- Create: `ui/main_window.py`
- Create: `ui/styles.qss`
- Create: `app.py`
- Test: `tests/test_ui_contract.py`

**Interfaces:**
- The UI exposes competence, network/OneDrive destination, report selection, distributor selection, execute/cancel actions, logs, results, individual durations, total elapsed timer, and history.
- All checklist operations use `Qt.CheckState.Unchecked`/`Checked` and comparisons against `Qt.CheckState.Checked`.

- [ ] Write failing source-contract tests that reject integer `setCheckState` calls and require the Qt enum import.
- [ ] Run the focused test and verify it fails before the UI exists.
- [ ] Implement the UI without importing Snowflake in the main thread and route work through the batch worker.
- [ ] Run contract tests, import/compile tests, and a headless UI smoke import where Qt is available.

### Task 6: Packaging, documentation, and final verification

**Files:**
- Create: `RelatoriosDesktop.spec`
- Modify: `requirements.txt`, `README.md`
- Create: `docs/operator-guide.md`
- Create: `tests/test_packaging.py`
- Create: `deliverables/RelatoriosDesktop-teste.zip`

- [ ] Write failing packaging tests for the spec, data directories, Windows build script, and fresh-start instructions.
- [ ] Run focused packaging tests and verify failure.
- [ ] Implement the spec and Windows build script with Snowflake dynamic imports and legacy data included.
- [ ] Run the entire test suite, `compileall`, source hash validation, and a package-content audit.
- [ ] Build the available non-Windows smoke package; document that `.exe` compilation must run on Windows.
- [ ] Create the final ZIP and verify it can be extracted into a clean directory with no stale-cache files.

## Self-review

- All 15 acceptance areas from the approved design map to Tasks 1–6.
- The catalog and runner interfaces use the same report IDs and category values throughout.
- The adapter isolates legacy globals without rewriting SQL, and the source manifest makes accidental changes detectable.
- The UI contract test specifically prevents the `setCheckState(0)` regression from returning.
- Real Snowflake execution remains an environment-dependent verification step because this runtime has no corporate network or browser SSO.
