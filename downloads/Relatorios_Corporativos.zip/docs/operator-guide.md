# Guia de operação

## Primeira execução no VS Code

Extraia o ZIP em uma pasta nova e abra essa pasta no VS Code. Use o terminal
integrado:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
py -m pip install --upgrade pip
py -m pip install -r requirements.txt
python app.py
```

Use uma pasta local de teste, por exemplo `C:\TesteRelatorios`, antes de usar
a rede corporativa. Não execute uma cópia antiga da pasta: o pacote atual usa
`Qt.CheckState.Unchecked` e `Qt.CheckState.Checked` para os controles de seleção.

## Execução

1. Informe a competência no formato `YYYYMM`, por exemplo `202611`.
2. Escolha Rede corporativa ou OneDrive e confirme a pasta.
3. Marque um ou mais relatórios.
4. Marque uma ou mais distribuidoras, como `EQTL_MA`.
5. Clique em **Executar selecionados**.

Na primeira conexão, o Snowflake usará `externalbrowser`. Conclua a validação
no navegador e retorne ao aplicativo. O lote faz um bootstrap da autenticação
antes de iniciar qualquer relatório, usa o cache seguro do `keyring` e cria
conexões independentes para as threads de cada relatório. Isso evita compartilhar
uma conexão viva entre distribuidoras e reduz novas janelas de autenticação sem
bloquear a fila.

O painel mostra o relatório atual, o log, a duração individual e o **Tempo
total**. O status no cabeçalho é clicável: ele apresenta o motivo detalhado de
uma conclusão, alerta, cancelamento ou falha. O botão **Cancelar** impede o
próximo relatório; uma consulta já iniciada termina de forma cooperativa para
não corromper o arquivo.

## Saída e histórico

Os arquivos seguem a estrutura:

```text
<raiz>\<YYYYMM>\Contabilidade\...
<raiz>\<YYYYMM>\Tributario\...
```

O histórico é salvo na pasta de dados do usuário, não dentro da pasta
temporária do executável. Nenhuma senha ou token Snowflake é gravado.

Na aba **Resultados**, use **Baixar resultados** para gerar um arquivo Excel ou
CSV com cada relatório processado, incluindo status, detalhes, erro, arquivo,
duração e quantidade de linhas. Na aba **Histórico**, use **Baixar histórico**
para exportar todas as execuções armazenadas, inclusive falhas ocorridas antes
do primeiro relatório.

## Executável Windows

Em um Windows com acesso à rede e ao Snowflake:

```powershell
.\build_windows.bat
```

O resultado será `dist\RelatoriosDesktop\RelatoriosDesktop.exe`. O PyInstaller
deve rodar no Windows; o ambiente de desenvolvimento Linux não produz um
`.exe` Windows. Distribua a pasta inteira `dist\RelatoriosDesktop`.

## Diagnóstico rápido

- **A janela não abre:** confirme que o terminal está usando `.venv\Scripts\python.exe`.
- **Erro `setCheckState`:** a pasta contém versão antiga; extraia o ZIP em uma nova pasta.
- **Destino inacessível:** teste primeiro uma pasta local e depois valide o acesso à VPN/rede.
- **Autenticação repetida:** verifique se o pacote `keyring` foi instalado no ambiente de compilação, gere o executável novamente e confirme se o armazenamento seguro do Windows está disponível. Instalar o pacote depois de compilar não altera um executável já criado.
- **Um relatório demora:** o log mostra cada distribuidora; o arquivo só é considerado concluído depois que a etapa inteira termina.
