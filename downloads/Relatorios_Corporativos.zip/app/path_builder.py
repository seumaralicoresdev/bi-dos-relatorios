from __future__ import annotations

import re
from pathlib import Path

from app.models import ReportDefinition


_COMPETENCIA_RE = re.compile(r"^\d{6}$")


def validate_competencia(value: str) -> str:
    normalized = str(value).strip()
    if not _COMPETENCIA_RE.fullmatch(normalized):
        raise ValueError("A competência deve usar o formato YYYYMM.")
    month = int(normalized[4:])
    if month < 1 or month > 12:
        raise ValueError("O mês da competência deve estar entre 01 e 12.")
    return normalized


def build_report_path(
    root: Path,
    competencia: str,
    definition: ReportDefinition,
    separate_rs: bool = False,
) -> Path:
    competencia = validate_competencia(competencia)
    folder = root / competencia / definition.category
    suffix = "_rs" if separate_rs else ""
    if separate_rs:
        folder = folder / "Gerados_RS"
    return folder / f"{definition.filename_stem}{suffix}_{competencia}{definition.extension}"
