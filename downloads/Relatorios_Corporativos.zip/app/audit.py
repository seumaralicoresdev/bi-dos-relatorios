from __future__ import annotations

import csv
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Mapping, Sequence

from app.models import ExecutionResult


STATUS_LABELS = {
    "success": "Concluído",
    "warning": "Concluído com alerta",
    "failed": "Falha na execução",
    "cancelled": "Execução cancelada",
}


@dataclass(frozen=True)
class StatusSummary:
    level: str
    label: str
    detail: str


def _detail_for_result(result: ExecutionResult | Mapping[str, object]) -> str:
    if isinstance(result, ExecutionResult):
        message = result.message.strip()
        error = (result.error or "").strip()
        status = result.status
        name = result.report_name
    else:
        message = str(result.get("message") or "").strip()
        error = str(result.get("error") or "").strip()
        status = str(result.get("status") or "")
        name = str(result.get("report_name") or result.get("report_id") or "Relatório")

    reason = error or message
    if not reason:
        if status == "success":
            reason = "Arquivo gerado conforme esperado."
        elif status == "warning":
            reason = "O relatório terminou com um alerta não detalhado."
        else:
            reason = "O relatório não foi concluído e não apresentou uma justificativa detalhada."
    return f"{name}: {reason}"


def _status_for_result(result: ExecutionResult | Mapping[str, object]) -> str:
    if isinstance(result, ExecutionResult):
        return result.status
    return str(result.get("status") or "")


def summarize_batch(
    results: Iterable[ExecutionResult | Mapping[str, object]],
    *,
    cancelled: bool = False,
    execution_error: str | None = None,
) -> StatusSummary:
    results = tuple(results)
    if execution_error:
        return StatusSummary(
            level="failed",
            label=STATUS_LABELS["failed"],
            detail=f"A execução falhou antes de ser concluída. Motivo: {execution_error.strip()}",
        )
    if cancelled:
        processed = len(results)
        return StatusSummary(
            level="cancelled",
            label=STATUS_LABELS["cancelled"],
            detail=(
                f"A execução foi cancelada pelo usuário após {processed} relatório(s). "
                "Os relatórios que não aparecem na aba Resultados não foram processados."
            ),
        )
    if not results:
        return StatusSummary(
            level="failed",
            label="Não concluído",
            detail="Nenhum relatório foi concluído; verifique o log para identificar o motivo.",
        )

    failed = tuple(result for result in results if _status_for_result(result) == "failed")
    warnings = tuple(result for result in results if _status_for_result(result) == "warning")
    if failed:
        details = "\n".join(f"• {_detail_for_result(result)}" for result in failed)
        return StatusSummary(
            level="failed",
            label=STATUS_LABELS["failed"],
            detail=f"A execução não foi concluída integralmente. Motivos encontrados:\n{details}",
        )
    if warnings:
        details = "\n".join(f"• {_detail_for_result(result)}" for result in warnings)
        return StatusSummary(
            level="warning",
            label=STATUS_LABELS["warning"],
            detail=f"O lote terminou, mas foram encontrados alertas:\n{details}",
        )
    return StatusSummary(
        level="success",
        label=STATUS_LABELS["success"],
        detail=(
            f"Processo devidamente concluído. Os {len(results)} relatório(s) selecionado(s) "
            "foram processados e não apresentaram alertas."
        ),
    )


def summarize_history_record(record: Mapping[str, object]) -> StatusSummary:
    results_data = record.get("results") or ()
    results = tuple(result for result in results_data if isinstance(result, Mapping))
    return summarize_batch(
        results,
        cancelled=bool(record.get("cancelled", False)),
        execution_error=str(record.get("execution_error") or "") or None,
    )


def _status_label(status: object) -> str:
    return STATUS_LABELS.get(str(status), str(status or "Não informado"))


def _result_row(result: ExecutionResult) -> list[object]:
    return [
        result.report_name,
        result.report_id,
        result.category,
        result.competencia,
        _status_label(result.status),
        result.message or ("Arquivo gerado conforme esperado." if result.status == "success" else ""),
        result.error or "",
        str(result.output_path or ""),
        round(result.duration_seconds, 3),
        result.rows if result.rows is not None else "",
        ", ".join(result.sheets),
    ]


RESULT_HEADERS = [
    "Relatório",
    "ID",
    "Categoria",
    "Competência",
    "Status",
    "Detalhes",
    "Erro",
    "Arquivo",
    "Duração (s)",
    "Linhas",
    "Abas",
]

HISTORY_HEADERS = [
    "Início",
    "Fim",
    "Competência",
    "Status",
    "Detalhes",
    "Tempo total (s)",
    "Cancelado",
    "Relatórios solicitados",
    "Distribuidoras",
    "Sucesso",
    "Alertas",
    "Falhas",
    "Arquivos gerados",
    "Pasta de saída",
]


def _history_row(record: Mapping[str, object]) -> list[object]:
    result_data = tuple(item for item in (record.get("results") or ()) if isinstance(item, Mapping))
    summary = summarize_history_record(record)
    success_count = sum(1 for result in result_data if result.get("status") == "success")
    warning_count = sum(1 for result in result_data if result.get("status") == "warning")
    failed_count = sum(1 for result in result_data if result.get("status") == "failed")
    generated_count = sum(1 for result in result_data if result.get("output_path"))
    return [
        record.get("started_at", ""),
        record.get("finished_at", ""),
        record.get("competencia", ""),
        summary.label,
        summary.detail,
        round(float(record.get("duration_seconds") or 0), 3),
        "Sim" if record.get("cancelled") else "Não",
        ", ".join(str(value) for value in (record.get("report_ids") or ())),
        ", ".join(str(value) for value in (record.get("distribuidoras") or ())),
        success_count,
        warning_count,
        failed_count,
        generated_count,
        record.get("output_root", ""),
    ]


def _write_xlsx(path: Path, sheet_name: str, headers: Sequence[str], rows: Iterable[Sequence[object]]) -> None:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill

    workbook = Workbook()
    sheet = workbook.active
    sheet.title = sheet_name
    sheet.append(list(headers))
    for row in rows:
        sheet.append(list(row))
    for cell in sheet[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="173C32")
    sheet.freeze_panes = "A2"
    sheet.auto_filter.ref = sheet.dimensions
    for column in sheet.columns:
        values = [len(str(cell.value or "")) for cell in column]
        width = min(max(max(values, default=10) + 2, 12), 55)
        sheet.column_dimensions[column[0].column_letter].width = width
    workbook.save(path)


def _write_csv(path: Path, headers: Sequence[str], rows: Iterable[Sequence[object]]) -> None:
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.writer(handle, delimiter=";")
        writer.writerow(headers)
        writer.writerows(rows)


def export_results(results: Iterable[ExecutionResult], path: Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    rows = [_result_row(result) for result in results]
    if path.suffix.lower() == ".csv":
        _write_csv(path, RESULT_HEADERS, rows)
    else:
        _write_xlsx(path, "Resultados", RESULT_HEADERS, rows)
    return path


def export_history(records: Iterable[Mapping[str, object]], path: Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    rows = [_history_row(record) for record in records]
    if path.suffix.lower() == ".csv":
        _write_csv(path, HISTORY_HEADERS, rows)
    else:
        _write_xlsx(path, "Histórico", HISTORY_HEADERS, rows)
    return path
