from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Mapping


@dataclass(frozen=True)
class ReportDefinition:
    id: str
    name: str
    category: str
    module_path: str
    filename_stem: str
    entrypoint: str = "main"
    extension: str = ".xlsx"
    distributor_template: Mapping[str, object] = field(default_factory=dict)
    supporting_module_path: str | None = None


@dataclass(frozen=True)
class ExecutionRequest:
    competencia: str
    report_ids: tuple[str, ...]
    distribuidoras: tuple[str, ...]
    output_root: Path
    onedrive_root: Path | None = None
    active_destination: str = "network"
    separate_rs: bool = False


@dataclass(frozen=True)
class ExecutionResult:
    report_id: str
    report_name: str
    category: str
    competencia: str
    status: str
    output_path: Path | None
    duration_seconds: float
    rows: int | None = None
    sheets: tuple[str, ...] = ()
    message: str = ""
    error: str | None = None


@dataclass(frozen=True)
class BatchResult:
    results: tuple[ExecutionResult, ...]
    started_at: str
    finished_at: str
    duration_seconds: float
    cancelled: bool = False
