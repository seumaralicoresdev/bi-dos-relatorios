from __future__ import annotations

from dataclasses import replace
from types import MappingProxyType
from typing import Iterable

from app.models import ReportDefinition


ALL_DISTRIBUTORS = ("EQTL_MA", "EQTL_PA", "EQTL_PI", "EQTL_AL", "EQTL_AP", "EQTL_RS")
_SIMPLE_TEMPLATE = MappingProxyType({name: name for name in ALL_DISTRIBUTORS})
_NESTED_TEMPLATE = MappingProxyType(
    {
        name: {"prd_schema": name, "raw_schema": f"CCS_{name.removeprefix('EQTL_')}"}
        for name in ALL_DISTRIBUTORS
    }
)


def _definition(
    report_id: str,
    name: str,
    category: str,
    module_path: str,
    filename_stem: str,
    *,
    nested: bool = False,
    supporting_module_path: str | None = None,
) -> ReportDefinition:
    return ReportDefinition(
        id=report_id,
        name=name,
        category=category,
        module_path=module_path,
        filename_stem=filename_stem,
        distributor_template=_NESTED_TEMPLATE if nested else _SIMPLE_TEMPLATE,
        supporting_module_path=supporting_module_path,
    )


class ReportRegistry:
    def __init__(self, definitions: Iterable[ReportDefinition]):
        self._definitions = tuple(definitions)
        self._by_id = {definition.id: definition for definition in self._definitions}

    @classmethod
    def default(cls) -> "ReportRegistry":
        return cls(
            (
                _definition("desconto_tarifario", "Desconto Tarifário", "Contabilidade", "RELATORIOS DESCONTO TARIFÁRIO/script_relat_desc_tarif.py", "desconto_tarifario"),
                _definition("clientes_cativos", "Faturamento Cliente Cativo", "Contabilidade", "RELATÓRIO CLIENTES CATIVOS/script_relat_client_cat.py", "clientes_cativos", nested=True),
                _definition("clientes_livres", "Faturamento Cliente Livre", "Contabilidade", "RELATÓRIOS CLIENTES LIVRES/script_clientes_livres.py", "clientes_livres", nested=True),
                _definition("modicidade_tarifaria", "Modicidade Tarifária", "Contabilidade", "RELATÓRIOS MODICIDADE TARIFÁRIA/script_relat_mod_tar.py", "modicidade_tarifaria"),
                _definition("saldo_bloqueado", "Saldo Bloqueado", "Contabilidade", "RELATORIO SALDO BLOQUEADO/script_relat_saldo_bloq.py", "saldo_bloqueado", nested=True),
                _definition("mmgd", "MMGD", "Contabilidade", "RELATÓRIOS MMGD/mmgd.py", "mmgd", supporting_module_path="RELATÓRIOS MMGD/base_mmgd.py"),
                _definition("reativos_excedentes", "Reativos Excedentes", "Contabilidade", "RELATÓRIOS REATIVOS EXCEDENTE/script_relat_reativo.py", "reativos_excedentes"),
                _definition("resumo_faturamento", "Resumo Faturamento", "Contabilidade", "Resumo_Faturamento/script_resum_fat.py", "resumo_fat_tributos"),
                _definition("ultrapassagem_demanda", "Ultrapassagem de Demanda", "Contabilidade", "RELATÓRIOS ULTRAPASSAGEM DE DEMANDA/script_ultrp_dem_mudado.py", "ultrapassagem_demanda"),
                _definition("encargo_escassez_hidrica", "Encargo Escassez Hídrica", "Tributario", "RELATÓRIO ESCASSEZ HÍDRICA/script_escassez_hidric.py", "escassez_hidrica"),
                _definition("encargo_covid", "Encargo Covid", "Tributario", "RELATÓRIO ENCARGO COVID/script_encargo_covid.py", "encargo_covid"),
                _definition("icms_injetada", "ICMS Injetada", "Tributario", "RELATÓRIO ICMS INJETADA/script_relat_icms_injet.py", "icms_injetada"),
                _definition("isencao_icms_tusd", "Isenção ICMS TUSD", "Tributario", "RELATORIO ISENÇÃO ICMS TUSD/script_isen_icms_tusd.py", "isencao_icms_tusd"),
                _definition("financiamento_padrao", "Financiamento Padrão", "Tributario", "RELATÓRIOS FINANCIAMENTO PADRAO/script_finan_padrao.py", "financ_padrao"),
                _definition("consumo_proprio", "Consumo Próprio", "Tributario", "RELATÓRIOS CONSUMO PRÓPRIO/script_consum_proprio.py", "consumo_proprio"),
                _definition("retencao_tributos", "Imposto Retido", "Tributario", "RELATORIOS RETENÇÃO DE TRIBUTOS/script_reten_tribut.py", "retencao_tributos"),
            )
        )

    def all(self) -> tuple[ReportDefinition, ...]:
        return self._definitions

    def by_id(self, report_id: str) -> ReportDefinition:
        try:
            return self._by_id[report_id]
        except KeyError as exc:
            raise KeyError(f"Relatório não cadastrado: {report_id}") from exc

    def for_category(self, category: str) -> tuple[ReportDefinition, ...]:
        return tuple(definition for definition in self._definitions if definition.category == category)
