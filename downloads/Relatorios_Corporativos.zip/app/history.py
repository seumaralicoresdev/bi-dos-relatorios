from __future__ import annotations

import json
from dataclasses import asdict
from pathlib import Path

from app.models import BatchResult, ExecutionRequest


class HistoryStore:
    def __init__(self, path: Path):
        self.path = Path(path)

    def load(self) -> list[dict]:
        if not self.path.is_file():
            return []
        try:
            payload = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return []
        return payload if isinstance(payload, list) else []

    def append_batch(
        self,
        request: ExecutionRequest,
        batch: BatchResult,
        execution_error: str | None = None,
    ) -> None:
        results = []
        for result in batch.results:
            data = asdict(result)
            data["output_path"] = str(result.output_path) if result.output_path else None
            data["sheets"] = list(result.sheets)
            results.append(data)

        record = {
            "started_at": batch.started_at,
            "finished_at": batch.finished_at,
            "duration_seconds": batch.duration_seconds,
            "cancelled": batch.cancelled,
            "competencia": request.competencia,
            "report_ids": list(request.report_ids),
            "distribuidoras": list(request.distribuidoras),
            "output_root": str(request.output_root),
            "active_destination": request.active_destination,
            "separate_rs": request.separate_rs,
            "execution_error": execution_error,
            "results": results,
        }
        records = self.load()
        records.append(record)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        temporary.write_text(json.dumps(records, ensure_ascii=False, indent=2), encoding="utf-8")
        temporary.replace(self.path)
