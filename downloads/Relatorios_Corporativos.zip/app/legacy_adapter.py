from __future__ import annotations

from contextlib import redirect_stderr, redirect_stdout
import hashlib
import importlib.util
import io
from pathlib import Path
import sys
import threading
from types import ModuleType
from typing import Callable

from app.models import ExecutionRequest, ReportDefinition
from app.snowflake_session import SnowflakeSession


LogCallback = Callable[[str], None]
_IMPORT_LOCK = threading.Lock()


class _LogStream(io.TextIOBase):
    def __init__(self, callback: LogCallback):
        super().__init__()
        self.callback = callback

    def write(self, text: str) -> int:
        for line in text.splitlines():
            if line.strip():
                self.callback(line.rstrip())
        return len(text)

    def flush(self) -> None:
        return None


class LegacyAdapter:
    def __init__(self, legacy_root: Path, session: SnowflakeSession | object | None = None):
        self.legacy_root = Path(legacy_root)
        self.session = session or SnowflakeSession()

    def prepare(self) -> None:
        prepare = getattr(self.session, "prepare", None)
        if callable(prepare):
            prepare()

    def _load_module(self, path: Path) -> ModuleType:
        module_name = f"legacy_report_{hashlib.sha1(str(path).encode('utf-8')).hexdigest()}"
        spec = importlib.util.spec_from_file_location(module_name, path)
        if spec is None or spec.loader is None:
            raise ImportError(f"Não foi possível carregar o módulo: {path}")
        module = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = module

        # The original scripts create their fixed network folder at import
        # time. Suppress only that import-time side effect; the requested
        # output directory is created explicitly before main() runs.
        from pathlib import Path as ConcretePath

        original_mkdir = ConcretePath.mkdir

        def no_import_mkdir(self, *args, **kwargs):
            return None

        with _IMPORT_LOCK:
            ConcretePath.mkdir = no_import_mkdir  # type: ignore[assignment]
            try:
                spec.loader.exec_module(module)
            finally:
                ConcretePath.mkdir = original_mkdir  # type: ignore[assignment]
                sys.modules.pop(module_name, None)
        return module

    def _configure_module(
        self,
        module: ModuleType,
        definition: ReportDefinition,
        request: ExecutionRequest,
        output_path: Path,
    ) -> None:
        module.MES_COMPET = request.competencia
        module.OUTPUT_PATH = output_path
        template = dict(definition.distributor_template or getattr(module, "DISTRIBUIDORAS", {}))
        selected = set(request.distribuidoras)
        module.DISTRIBUIDORAS = {
            name: template[name]
            for name in request.distribuidoras
            if name in template and name in selected
        }
        if not module.DISTRIBUIDORAS:
            raise ValueError(f"Nenhuma distribuidora válida para {definition.name}.")

        if hasattr(module, "MAX_WORKERS"):
            module.MAX_WORKERS = min(int(getattr(module, "MAX_WORKERS", 6)), len(module.DISTRIBUIDORAS))

        if hasattr(module, "DIRETORIO_CONTABILIDADE") or hasattr(module, "PASTA_BASES"):
            module.DIRETORIO_CONTABILIDADE = output_path.parent
            module.PASTA_BASES = output_path.parent / f"base_mmgd_{request.competencia}"
            module.PASTA_BASES.mkdir(parents=True, exist_ok=True)

        connect = getattr(self.session, "connect", None)
        if callable(connect) and hasattr(module, "get_connection"):
            module.get_connection = connect

    def run(
        self,
        definition: ReportDefinition,
        request: ExecutionRequest,
        output_path: Path,
        log: LogCallback | None = None,
    ) -> Path | None:
        callback = log or (lambda _message: None)
        source_path = self.legacy_root / definition.module_path
        if not source_path.is_file():
            raise FileNotFoundError(f"Script legado não encontrado: {source_path}")

        output_path.parent.mkdir(parents=True, exist_ok=True)
        self.prepare()

        stream = _LogStream(callback)
        with redirect_stdout(stream), redirect_stderr(stream):
            module = self._load_module(source_path)
            self._configure_module(module, definition, request, output_path)
            entrypoint = getattr(module, definition.entrypoint)
            entrypoint()

        produced = Path(getattr(module, "OUTPUT_PATH", output_path))
        return produced if produced.is_file() else None
