from __future__ import annotations

from pathlib import Path


def format_row_count(value: int | None) -> str:
    """Format a row count using the Brazilian thousands separator."""
    if value is None:
        return ""
    return f"{value:,}".replace(",", ".")


def inspect_result(path: Path) -> dict:
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(path)
    if path.suffix.lower() == ".xlsx":
        from openpyxl import load_workbook

        workbook = load_workbook(path, read_only=True, data_only=True)
        try:
            sheets = tuple(workbook.sheetnames)
            rows_by_sheet = {sheet: max(0, workbook[sheet].max_row - 1) for sheet in sheets}
        finally:
            workbook.close()
        return {
            "path": str(path),
            "size_bytes": path.stat().st_size,
            "sheets": sheets,
            "rows_by_sheet": rows_by_sheet,
            "rows": sum(rows_by_sheet.values()),
        }
    if path.suffix.lower() == ".csv":
        with path.open("r", encoding="utf-8-sig", errors="replace") as handle:
            line_count = sum(1 for _ in handle)
        return {
            "path": str(path),
            "size_bytes": path.stat().st_size,
            "sheets": (),
            "rows_by_sheet": {},
            "rows": max(0, line_count - 1),
        }
    return {
        "path": str(path),
        "size_bytes": path.stat().st_size,
        "sheets": (),
        "rows_by_sheet": {},
        "rows": None,
    }
