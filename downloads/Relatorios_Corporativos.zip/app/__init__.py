"""Application domain and execution services."""
