from __future__ import annotations

from datetime import datetime
from pathlib import Path
import time
from typing import Callable, Iterable

from app.models import BatchResult, ExecutionRequest, ExecutionResult, ReportDefinition
from app.report_registry import ReportRegistry


def build_execution_jobs(request: ExecutionRequest, registry: ReportRegistry) -> list[ReportDefinition]:
    wanted = set(request.report_ids)
    return [definition for definition in registry.all() if definition.id in wanted]


class ReportWorker:
    """Qt-independent sequential batch service.

    The legacy report keeps its own distributor-level thread pool. This worker
    deliberately serializes report families so their output files and session
    lifecycle cannot overlap.
    """

    def __init__(self, runner, request: ExecutionRequest, jobs: Iterable[ReportDefinition]):
        self.runner = runner
        self.request = request
        self.jobs = list(jobs)
        self.cancel_requested = False
        self.started_at: datetime | None = None
        self.report_started_at: datetime | None = None
        self._started_clock: float | None = None
        self._finished_clock: float | None = None
        self.on_report_started: Callable[[ReportDefinition, int, int], None] = lambda *_args: None
        self.on_log: Callable[[str], None] = lambda _message: None
        self.on_report_finished: Callable[[ExecutionResult], None] = lambda _result: None
        self.on_progress_changed: Callable[[int], None] = lambda _value: None
        self.on_batch_finished: Callable[[BatchResult], None] = lambda _result: None

    @property
    def elapsed_seconds(self) -> float:
        if self._started_clock is None:
            return 0.0
        end = self._finished_clock if self._finished_clock is not None else time.perf_counter()
        return max(0.0, end - self._started_clock)

    def cancel(self) -> None:
        self.cancel_requested = True

    def run(self) -> BatchResult:
        self.started_at = datetime.now()
        self._started_clock = time.perf_counter()
        results: list[ExecutionResult] = []
        total = len(self.jobs)

        prepare = getattr(self.runner, "prepare", None)
        if callable(prepare):
            # Validate the shared authentication cache before any legacy
            # script starts its distributor-level thread pool.
            prepare(self.on_log)

        for index, definition in enumerate(self.jobs, start=1):
            if self.cancel_requested:
                break
            self.report_started_at = datetime.now()
            self.on_report_started(definition, index, total)
            try:
                result = self.runner.run(definition, self.request, self.on_log)
            except Exception as exc:  # defensive boundary for third-party runners
                result = ExecutionResult(
                    report_id=definition.id,
                    report_name=definition.name,
                    category=definition.category,
                    competencia=self.request.competencia,
                    status="failed",
                    output_path=None,
                    duration_seconds=0.0,
                    message="O relatório não pôde ser processado.",
                    error=str(exc),
                )
            results.append(result)
            self.on_report_finished(result)
            self.on_progress_changed(int(index / total * 100) if total else 100)

        self._finished_clock = time.perf_counter()
        finished_at = datetime.now()
        batch = BatchResult(
            results=tuple(results),
            started_at=self.started_at.isoformat(timespec="seconds"),
            finished_at=finished_at.isoformat(timespec="seconds"),
            duration_seconds=self.elapsed_seconds,
            cancelled=self.cancel_requested and len(results) < total,
        )
        self.on_batch_finished(batch)
        return batch
