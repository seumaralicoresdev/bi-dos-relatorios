from __future__ import annotations

from dataclasses import replace
from pathlib import Path
import time
import traceback
from typing import Callable

from app.legacy_adapter import LegacyAdapter
from app.models import ExecutionRequest, ExecutionResult, ReportDefinition
from app.path_builder import build_report_path
from app.result_inspector import inspect_result


LogCallback = Callable[[str], None]


class ReportRunner:
    def __init__(self, legacy_root: Path, session=None):
        self.adapter = LegacyAdapter(legacy_root, session=session)

    def prepare(self, log: LogCallback | None = None) -> None:
        callback = log or (lambda _message: None)
        callback("Preparando sessão Snowflake para o lote...")
        self.adapter.prepare()
        callback("Sessão Snowflake preparada antes do início dos relatórios.")

    def _run_once(
        self,
        definition: ReportDefinition,
        request: ExecutionRequest,
        output_path: Path,
        callback: LogCallback,
    ) -> Path | None:
        callback(f"Iniciando: {definition.name}")
        produced = self.adapter.run(definition, request, output_path, callback)
        if produced is None:
            return None

        if definition.supporting_module_path:
            support_definition = replace(
                definition,
                module_path=definition.supporting_module_path,
                supporting_module_path=None,
            )
            callback(f"Executando base auxiliar: {definition.name}")
            self.adapter.run(support_definition, request, output_path, callback)
        return produced

    @staticmethod
    def _inspect_outputs(paths: list[Path]) -> tuple[int | None, tuple[str, ...]]:
        inspections = [inspect_result(path) for path in paths]
        row_values = [inspection.get("rows") for inspection in inspections]
        rows = sum(row_values) if all(isinstance(value, int) for value in row_values) else None
        sheets = tuple(
            sheet
            for inspection in inspections
            for sheet in inspection.get("sheets", ())
        )
        return rows, sheets

    def run(
        self,
        definition: ReportDefinition,
        request: ExecutionRequest,
        log: LogCallback | None = None,
    ) -> ExecutionResult:
        callback = log or (lambda _message: None)
        started = time.perf_counter()
        try:
            runs: list[tuple[ExecutionRequest, Path]] = []
            rs_selected = "EQTL_RS" in request.distribuidoras
            other_distributors = tuple(name for name in request.distribuidoras if name != "EQTL_RS")
            if request.separate_rs and rs_selected and other_distributors:
                runs.append(
                    (
                        replace(request, distribuidoras=other_distributors, separate_rs=False),
                        build_report_path(request.output_root, request.competencia, definition, False),
                    )
                )
                runs.append(
                    (
                        replace(request, distribuidoras=("EQTL_RS",), separate_rs=True),
                        build_report_path(request.output_root, request.competencia, definition, True),
                    )
                )
            else:
                effective_request = replace(request, separate_rs=False) if not rs_selected else request
                runs.append(
                    (
                        effective_request,
                        build_report_path(
                            request.output_root,
                            request.competencia,
                            definition,
                            effective_request.separate_rs,
                        ),
                    )
                )

            produced_paths: list[Path] = []
            for run_request, output_path in runs:
                produced = self._run_once(definition, run_request, output_path, callback)
                if produced is None:
                    message = f"O relatório terminou sem criar o arquivo esperado: {output_path.name}."
                    callback(message)
                    return ExecutionResult(
                        report_id=definition.id,
                        report_name=definition.name,
                        category=definition.category,
                        competencia=request.competencia,
                        status="warning",
                        output_path=produced_paths[0] if produced_paths else None,
                        duration_seconds=time.perf_counter() - started,
                        message=message,
                    )
                produced_paths.append(produced)

            duration = time.perf_counter() - started
            if len(produced_paths) == 1:
                message = f"Arquivo gerado: {produced_paths[0]}"
            else:
                message = "Arquivos gerados: " + " | ".join(str(path) for path in produced_paths)
            try:
                rows, sheets = self._inspect_outputs(produced_paths)
            except Exception as exc:
                # A leitura das linhas é metadado de auditoria. Se um legado
                # produzir um arquivo não inspecionável, não devemos invalidar
                # um relatório que já foi gerado com sucesso.
                rows, sheets = None, ()
                callback(f"Não foi possível identificar a quantidade de linhas: {exc}")
            callback(message)
            return ExecutionResult(
                report_id=definition.id,
                report_name=definition.name,
                category=definition.category,
                competencia=request.competencia,
                status="success",
                output_path=produced_paths[0],
                duration_seconds=duration,
                rows=rows,
                sheets=sheets,
                message=message,
            )
        except Exception as exc:
            duration = time.perf_counter() - started
            callback(f"Erro em {definition.name}: {exc}")
            callback(traceback.format_exc())
            return ExecutionResult(
                report_id=definition.id,
                report_name=definition.name,
                category=definition.category,
                competencia=request.competencia,
                status="failed",
                output_path=None,
                duration_seconds=duration,
                message="O relatório não pôde ser processado.",
                error=str(exc),
            )
