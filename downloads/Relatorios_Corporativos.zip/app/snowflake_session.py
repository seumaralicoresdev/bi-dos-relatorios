from __future__ import annotations

import os
from dataclasses import dataclass, field
import threading
from typing import Any


DEFAULT_ACCOUNT = "khb56279.us-east-1"
DEFAULT_USER = "elias.correa@equatorialenergia.com.br"


@dataclass
class SnowflakeSession:
    """Batch authentication policy with independent connections per worker.

    The bootstrap connection is closed immediately after authentication. The
    connector's temporary credential cache is then reused by each independent
    connection created by a legacy distributor worker.
    """

    connector: Any | None = None
    account: str | None = None
    user: str | None = None
    authenticator: str | None = None
    warehouse: str = "WH_EQTLINFO"
    database: str = "SB_FATURAMENTO"
    schema: str = "PUBLIC"
    extra_kwargs: dict[str, Any] = field(default_factory=dict)
    _prepared: bool = field(default=False, init=False, repr=False)
    _prepare_lock: threading.Lock = field(default_factory=threading.Lock, init=False, repr=False)

    def _connector_module(self) -> Any:
        if self.connector is not None:
            return self.connector
        try:
            import snowflake.connector as connector
        except ImportError as exc:
            raise RuntimeError(
                "O conector Snowflake não está instalado. Execute "
                "python -m pip install -r requirements.txt."
            ) from exc
        return connector

    def _kwargs(self) -> dict[str, Any]:
        values = {
            "account": self.account or os.getenv("SNOWFLAKE_ACCOUNT", DEFAULT_ACCOUNT),
            "user": self.user or os.getenv("SNOWFLAKE_USER", DEFAULT_USER),
            "authenticator": self.authenticator or os.getenv("SNOWFLAKE_AUTHENTICATOR", "externalbrowser"),
            "warehouse": self.warehouse,
            "database": self.database,
            "schema": self.schema,
            "client_store_temporary_credential": True,
        }
        values.update(self.extra_kwargs)
        return values

    def _uses_external_browser(self) -> bool:
        return str(self._kwargs().get("authenticator", "")).lower() == "externalbrowser"

    def _ensure_credential_cache(self) -> None:
        """Fail once with an actionable message instead of opening many SSO windows."""
        if self.connector is not None or not self._uses_external_browser():
            return
        try:
            import keyring
        except ImportError as exc:
            raise RuntimeError(
                "O pacote keyring não está instalado. Instale os requisitos e gere o executável novamente "
                "para permitir o cache seguro da autenticação Snowflake."
            ) from exc
        try:
            backend = keyring.get_keyring()
        except Exception as exc:
            raise RuntimeError(
                "O armazenamento seguro de credenciais não pôde ser inicializado. "
                "Verifique o keyring do Windows antes de executar os relatórios."
            ) from exc
        backend_name = f"{backend.__class__.__module__}.{backend.__class__.__name__}".lower()
        if "fail" in backend_name:
            raise RuntimeError(
                "O keyring está sem um backend seguro disponível. Instale os requisitos no ambiente Windows "
                "e gere o executável novamente antes de iniciar o lote."
            )

    def _connect(self) -> Any:
        connector = self._connector_module()
        kwargs = self._kwargs()
        try:
            return connector.connect(**kwargs)
        except (TypeError, ModuleNotFoundError) as exc:
            message = str(exc).lower()
            optional_cache_error = (
                isinstance(exc, TypeError)
                or "secure-local-storage" in message
                or "secure_local_storage" in message
                or "keyring" in message
            )
            if not optional_cache_error:
                raise
            kwargs.pop("client_store_temporary_credential", None)
            return connector.connect(**kwargs)

    def prepare(self) -> None:
        with self._prepare_lock:
            if self._prepared:
                return
            self._ensure_credential_cache()
            bootstrap = self._connect()
            try:
                bootstrap.close()
            finally:
                self._prepared = True

    def connect(self) -> Any:
        self.prepare()
        return self._connect()

    def close(self) -> None:
        # Legacy scripts own and close their distributor connections. This
        # resets only the batch authentication state for the next batch.
        with self._prepare_lock:
            self._prepared = False
