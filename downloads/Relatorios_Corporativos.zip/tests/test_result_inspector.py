from __future__ import annotations

import unittest

from app import result_inspector


class ResultInspectorTests(unittest.TestCase):
    def test_formats_line_count_with_brazilian_thousands_separator(self) -> None:
        self.assertTrue(hasattr(result_inspector, "format_row_count"))
        formatter = getattr(result_inspector, "format_row_count", None)
        self.assertIsNotNone(formatter)
        self.assertEqual(formatter(132798), "132.798")
        self.assertEqual(formatter(1000), "1.000")
        self.assertEqual(formatter(0), "0")
        self.assertEqual(formatter(None), "")
