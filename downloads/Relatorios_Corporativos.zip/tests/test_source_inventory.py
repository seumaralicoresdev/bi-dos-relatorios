from __future__ import annotations

import hashlib
import json
from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]
LEGACY_ROOT = ROOT / "relatorios" / "legado"
MANIFEST_PATH = ROOT / "source_manifest.json"


EXPECTED_MAIN = {
    "desconto_tarifario": "RELATORIOS DESCONTO TARIFÁRIO/script_relat_desc_tarif.py",
    "clientes_cativos": "RELATÓRIO CLIENTES CATIVOS/script_relat_client_cat.py",
    "clientes_livres": "RELATÓRIOS CLIENTES LIVRES/script_clientes_livres.py",
    "modicidade_tarifaria": "RELATÓRIOS MODICIDADE TARIFÁRIA/script_relat_mod_tar.py",
    "saldo_bloqueado": "RELATORIO SALDO BLOQUEADO/script_relat_saldo_bloq.py",
    "mmgd": "RELATÓRIOS MMGD/mmgd.py",
    "reativos_excedentes": "RELATÓRIOS REATIVOS EXCEDENTE/script_relat_reativo.py",
    "resumo_faturamento": "Resumo_Faturamento/script_resum_fat.py",
    "ultrapassagem_demanda": "RELATÓRIOS ULTRAPASSAGEM DE DEMANDA/script_ultrp_dem_mudado.py",
    "encargo_escassez_hidrica": "RELATÓRIO ESCASSEZ HÍDRICA/script_escassez_hidric.py",
    "encargo_covid": "RELATÓRIO ENCARGO COVID/script_encargo_covid.py",
    "icms_injetada": "RELATÓRIO ICMS INJETADA/script_relat_icms_injet.py",
    "isencao_icms_tusd": "RELATORIO ISENÇÃO ICMS TUSD/script_isen_icms_tusd.py",
    "financiamento_padrao": "RELATÓRIOS FINANCIAMENTO PADRAO/script_finan_padrao.py",
    "consumo_proprio": "RELATÓRIOS CONSUMO PRÓPRIO/script_consum_proprio.py",
    "retencao_tributos": "RELATORIOS RETENÇÃO DE TRIBUTOS/script_reten_tribut.py",
}


class SourceInventoryTests(unittest.TestCase):
    def test_all_main_reports_and_mmgd_helper_are_present(self) -> None:
        manifest = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
        self.assertEqual(set(EXPECTED_MAIN), set(manifest["main_reports"]))
        self.assertIn("RELATÓRIOS MMGD/base_mmgd.py", manifest["supporting_files"])

        for report_id, relative_path in EXPECTED_MAIN.items():
            path = LEGACY_ROOT / relative_path
            self.assertTrue(path.is_file(), report_id)
            self.assertEqual(relative_path, manifest["main_reports"][report_id]["relative_path"])

    def test_manifest_hashes_match_source_files(self) -> None:
        manifest = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
        entries = list(manifest["main_reports"].values()) + list(manifest["supporting_files"].values())
        for entry in entries:
            path = LEGACY_ROOT / entry["relative_path"]
            digest = hashlib.sha256(path.read_bytes()).hexdigest()
            self.assertEqual(entry["sha256"], digest, entry["relative_path"])

    def test_unicode_legacy_directory_is_preserved(self) -> None:
        self.assertTrue((LEGACY_ROOT / "RELATÓRIOS MODICIDADE TARIFÁRIA").is_dir())
        self.assertTrue((LEGACY_ROOT / "RELATORIOS RETENÇÃO DE TRIBUTOS").is_dir())

    def test_expected_sql_fingerprints_are_present(self) -> None:
        manifest = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
        self.assertEqual(
            manifest["sql_fingerprints"]["desconto_tarifario"],
            "SELECT EMPRESA, MES_COMPETENCIA, ITEM_ORDENACAO",
        )
        self.assertEqual(
            manifest["sql_fingerprints"]["mmgd"],
            "BASE_MMGD_CREDITOS",
        )


if __name__ == "__main__":
    unittest.main()
