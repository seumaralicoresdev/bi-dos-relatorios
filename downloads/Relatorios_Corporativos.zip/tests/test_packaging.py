from __future__ import annotations

from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]


class PackagingTests(unittest.TestCase):
    def test_pyinstaller_spec_contains_runtime_data_and_dynamic_imports(self) -> None:
        source = (ROOT / "RelatoriosDesktop.spec").read_text(encoding="utf-8")
        for value in ("app.py", "relatorios", "ui", "snowflake.connector", "keyring", "COLLECT"):
            self.assertIn(value, source)
        self.assertNotIn("onefile specification", source)

    def test_windows_build_script_is_reproducible(self) -> None:
        source = (ROOT / "build_windows.bat").read_text(encoding="utf-8")
        self.assertIn("requirements.txt", source)
        self.assertIn("RelatoriosDesktop.spec", source)
        self.assertIn("dist\\RelatoriosDesktop\\RelatoriosDesktop.exe", source)

    def test_requirements_include_secure_local_authentication_storage(self) -> None:
        source = (ROOT / "requirements.txt").read_text(encoding="utf-8")
        self.assertIn("keyring", source)
        self.assertIn("secure-local-storage", source)

    def test_operator_guide_explains_clean_start_and_authentication(self) -> None:
        source = (ROOT / "docs" / "operator-guide.md").read_text(encoding="utf-8")
        for value in ("python app.py", "externalbrowser", "EQTL_MA", "competência", "pasta local"):
            self.assertIn(value, source)

    def test_final_zip_exists_without_generated_caches(self) -> None:
        archive = ROOT / "deliverables" / "RelatoriosDesktop-auditoria-status-exportacao.zip"
        self.assertTrue(archive.is_file())
        import zipfile

        with zipfile.ZipFile(archive) as zipped:
            names = zipped.namelist()
        self.assertTrue(any(name.endswith("app.py") for name in names))
        self.assertFalse(any("__pycache__" in name or name.endswith(".pyc") for name in names))


if __name__ == "__main__":
    unittest.main()
