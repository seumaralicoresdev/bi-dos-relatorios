from __future__ import annotations

from pathlib import Path
import tempfile
import textwrap
import unittest

from app.models import ExecutionRequest, ReportDefinition
from app.report_runner import ReportRunner


class NoopSession:
    def __init__(self) -> None:
        self.prepare_calls = 0

    def prepare(self) -> None:
        self.prepare_calls += 1

    def connect(self):
        return object()


class RunnerTests(unittest.TestCase):
    def _fake_root(self, writes_output: bool) -> tuple[Path, ReportDefinition]:
        root = Path(tempfile.mkdtemp())
        source = "OUTPUT_PATH.write_text('ok', encoding='utf-8')" if writes_output else "pass"
        (root / 'fake.py').write_text(
            textwrap.dedent(
                f"""
                from pathlib import Path
                MES_COMPET = '000000'
                DISTRIBUIDORAS = {{'EQTL_MA': 'EQTL_MA'}}
                OUTPUT_PATH = Path('old.xlsx')
                def main():
                    {source}
                """
            ),
            encoding='utf-8',
        )
        definition = ReportDefinition('fake', 'Fake', 'Contabilidade', 'fake.py', 'fake')
        return root, definition

    def test_runner_returns_success_and_duration_for_created_file(self) -> None:
        root, definition = self._fake_root(True)
        request = ExecutionRequest('202611', ('fake',), ('EQTL_MA',), root / 'out')
        session = NoopSession()
        runner = ReportRunner(root, session=session)

        result = runner.run(definition, request, lambda _: None)

        self.assertEqual(result.status, 'success')
        self.assertIsNotNone(result.output_path)
        self.assertGreaterEqual(result.duration_seconds, 0)

    def test_runner_inspects_generated_xlsx_and_counts_data_rows(self) -> None:
        root = Path(tempfile.mkdtemp())
        (root / 'fake.py').write_text(
            textwrap.dedent(
                """
                from openpyxl import Workbook
                MES_COMPET = '000000'
                DISTRIBUIDORAS = {'EQTL_MA': 'EQTL_MA'}
                OUTPUT_PATH = None
                def main():
                    workbook = Workbook()
                    sheet = workbook.active
                    sheet.title = 'EQTL_MA'
                    sheet.append(['coluna'])
                    sheet.append(['linha 1'])
                    sheet.append(['linha 2'])
                    workbook.save(OUTPUT_PATH)
                """
            ),
            encoding='utf-8',
        )
        definition = ReportDefinition('fake', 'Fake', 'Contabilidade', 'fake.py', 'fake')
        request = ExecutionRequest('202611', ('fake',), ('EQTL_MA',), root / 'out')

        result = ReportRunner(root, session=NoopSession()).run(definition, request, lambda _: None)

        self.assertEqual(result.rows, 2)
        self.assertEqual(result.sheets, ('EQTL_MA',))

    def test_runner_sums_rows_when_eqtl_rs_is_generated_separately(self) -> None:
        root = Path(tempfile.mkdtemp())
        (root / 'fake.py').write_text(
            textwrap.dedent(
                """
                from openpyxl import Workbook
                MES_COMPET = '000000'
                DISTRIBUIDORAS = {'EQTL_MA': 'EQTL_MA', 'EQTL_RS': 'EQTL_RS'}
                OUTPUT_PATH = None
                def main():
                    workbook = Workbook()
                    sheet = workbook.active
                    distributor = next(iter(DISTRIBUIDORAS))
                    sheet.title = distributor
                    sheet.append(['coluna'])
                    for index in range(2 if distributor == 'EQTL_MA' else 3):
                        sheet.append([index])
                    workbook.save(OUTPUT_PATH)
                """
            ),
            encoding='utf-8',
        )
        definition = ReportDefinition(
            'fake',
            'Fake',
            'Contabilidade',
            'fake.py',
            'fake',
            distributor_template={'EQTL_MA': 'EQTL_MA', 'EQTL_RS': 'EQTL_RS'},
        )
        request = ExecutionRequest(
            '202611',
            ('fake',),
            ('EQTL_MA', 'EQTL_RS'),
            root / 'out',
            separate_rs=True,
        )

        result = ReportRunner(root, session=NoopSession()).run(definition, request, lambda _: None)

        self.assertEqual(result.rows, 5)
        self.assertEqual(result.sheets, ('EQTL_MA', 'EQTL_RS'))

    def test_prepare_delegates_to_shared_session(self) -> None:
        root, _definition = self._fake_root(True)
        session = NoopSession()

        ReportRunner(root, session=session).prepare()

        self.assertEqual(session.prepare_calls, 1)

    def test_runner_reports_missing_artifact(self) -> None:
        root, definition = self._fake_root(False)
        request = ExecutionRequest('202611', ('fake',), ('EQTL_MA',), root / 'out')
        runner = ReportRunner(root, session=NoopSession())

        result = runner.run(definition, request, lambda _: None)

        self.assertEqual(result.status, 'warning')
        self.assertIsNone(result.output_path)
        self.assertIn('arquivo', result.message.lower())

    def test_separates_rs_from_other_distributors_when_requested(self) -> None:
        root = Path(tempfile.mkdtemp())
        (root / 'fake.py').write_text(
            textwrap.dedent(
                """
                from pathlib import Path
                MES_COMPET = '000000'
                DISTRIBUIDORAS = {'EQTL_MA': 'EQTL_MA', 'EQTL_RS': 'EQTL_RS'}
                OUTPUT_PATH = Path('old.xlsx')
                def main():
                    OUTPUT_PATH.write_text(','.join(DISTRIBUIDORAS), encoding='utf-8')
                """
            ),
            encoding='utf-8',
        )
        definition = ReportDefinition(
            'fake', 'Fake', 'Contabilidade', 'fake.py', 'fake',
            distributor_template={'EQTL_MA': 'EQTL_MA', 'EQTL_RS': 'EQTL_RS'},
        )
        request = ExecutionRequest(
            '202611', ('fake',), ('EQTL_MA', 'EQTL_RS'), root / 'out', separate_rs=True
        )

        result = ReportRunner(root, session=NoopSession()).run(definition, request, lambda _: None)

        normal = root / 'out' / '202611' / 'Contabilidade' / 'fake_202611.xlsx'
        rs = root / 'out' / '202611' / 'Contabilidade' / 'Gerados_RS' / 'fake_rs_202611.xlsx'
        self.assertEqual(result.status, 'success')
        self.assertTrue(normal.is_file())
        self.assertTrue(rs.is_file())
        self.assertEqual(normal.read_text(encoding='utf-8'), 'EQTL_MA')
        self.assertEqual(rs.read_text(encoding='utf-8'), 'EQTL_RS')


if __name__ == '__main__':
    unittest.main()
