from __future__ import annotations

from pathlib import Path
import tempfile
import time
import unittest

from app.batch import ReportWorker, build_execution_jobs
from app.models import ExecutionRequest, ExecutionResult
from app.report_registry import ReportRegistry


class FakeRunner:
    def __init__(self) -> None:
        self.calls: list[str] = []

    def run(self, definition, request, log):
        self.calls.append(definition.id)
        log(f"executando {definition.id}")
        time.sleep(0.001)
        return ExecutionResult(
            report_id=definition.id,
            report_name=definition.name,
            category=definition.category,
            competencia=request.competencia,
            status="success",
            output_path=Path(f"{definition.id}.xlsx"),
            duration_seconds=0.001,
            message="ok",
        )


class PreparedRunner(FakeRunner):
    def __init__(self) -> None:
        super().__init__()
        self.prepare_calls = 0

    def prepare(self, _log=None) -> None:
        self.prepare_calls += 1


class BatchTests(unittest.TestCase):
    def _request(self, ids: tuple[str, ...]) -> ExecutionRequest:
        return ExecutionRequest("202611", ids, ("EQTL_MA",), Path(tempfile.mkdtemp()))

    def test_jobs_follow_catalog_order(self) -> None:
        registry = ReportRegistry.default()
        request = self._request(("retencao_tributos", "desconto_tarifario"))

        jobs = build_execution_jobs(request, registry)

        self.assertEqual([job.id for job in jobs], ["desconto_tarifario", "retencao_tributos"])

    def test_worker_runs_sequentially_and_exposes_timers(self) -> None:
        registry = ReportRegistry.default()
        request = self._request(("desconto_tarifario", "encargo_covid"))
        runner = FakeRunner()
        worker = ReportWorker(runner, request, build_execution_jobs(request, registry))
        started: list[str] = []
        worker.on_report_started = lambda definition, _index, _total: started.append(definition.id)

        batch = worker.run()

        self.assertEqual(runner.calls, ["desconto_tarifario", "encargo_covid"])
        self.assertEqual(started, runner.calls)
        self.assertEqual(len(batch.results), 2)
        self.assertIsNotNone(worker.started_at)
        self.assertIsNotNone(worker.report_started_at)
        self.assertGreaterEqual(worker.elapsed_seconds, 0)
        self.assertGreaterEqual(batch.duration_seconds, 0)

    def test_cancel_stops_before_next_report(self) -> None:
        registry = ReportRegistry.default()
        request = self._request(("desconto_tarifario", "encargo_covid"))
        runner = FakeRunner()
        worker = ReportWorker(runner, request, build_execution_jobs(request, registry))
        worker.on_report_finished = lambda _result: worker.cancel()

        batch = worker.run()

        self.assertEqual(runner.calls, ["desconto_tarifario"])
        self.assertTrue(batch.cancelled)

    def test_worker_prepares_shared_session_before_first_report(self) -> None:
        registry = ReportRegistry.default()
        request = self._request(("desconto_tarifario", "encargo_covid"))
        runner = PreparedRunner()
        worker = ReportWorker(runner, request, build_execution_jobs(request, registry))

        worker.run()

        self.assertEqual(runner.prepare_calls, 1)
        self.assertEqual(runner.calls, ["desconto_tarifario", "encargo_covid"])


if __name__ == "__main__":
    unittest.main()
