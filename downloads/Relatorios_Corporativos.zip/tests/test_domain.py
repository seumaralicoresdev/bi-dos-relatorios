from __future__ import annotations

from pathlib import Path
import tempfile
import unittest

from app.models import ExecutionRequest, ReportDefinition
from app.path_builder import build_report_path, validate_competencia
from app.report_registry import ReportRegistry


class DomainTests(unittest.TestCase):
    def test_competencia_accepts_valid_month(self) -> None:
        self.assertEqual(validate_competencia("202611"), "202611")

    def test_competencia_rejects_invalid_values(self) -> None:
        for value in ("2026", "202613", "202600", "20A611", ""):
            with self.subTest(value=value):
                with self.assertRaises(ValueError):
                    validate_competencia(value)

    def test_registry_exposes_sixteen_reports_in_two_categories(self) -> None:
        registry = ReportRegistry.default()
        self.assertEqual(len(registry.all()), 16)
        self.assertEqual(len(registry.for_category("Contabilidade")), 9)
        self.assertEqual(len(registry.for_category("Tributario")), 7)
        self.assertEqual(registry.by_id("mmgd").category, "Contabilidade")

    def test_registry_keeps_nested_schema_metadata(self) -> None:
        definition = ReportRegistry.default().by_id("clientes_cativos")
        self.assertEqual(
            definition.distributor_template["EQTL_MA"],
            {"prd_schema": "EQTL_MA", "raw_schema": "CCS_MA"},
        )

    def test_builds_normal_category_path(self) -> None:
        definition = ReportRegistry.default().by_id("desconto_tarifario")
        with tempfile.TemporaryDirectory() as temp:
            path = build_report_path(Path(temp), "202611", definition)
            self.assertEqual(path, Path(temp) / "202611" / "Contabilidade" / "desconto_tarifario_202611.xlsx")

    def test_builds_optional_rs_path(self) -> None:
        definition = ReportRegistry.default().by_id("encargo_covid")
        with tempfile.TemporaryDirectory() as temp:
            path = build_report_path(Path(temp), "202611", definition, separate_rs=True)
            self.assertEqual(path, Path(temp) / "202611" / "Tributario" / "Gerados_RS" / "encargo_covid_rs_202611.xlsx")

    def test_execution_request_is_immutable(self) -> None:
        request = ExecutionRequest(
            competencia="202611",
            report_ids=("mmgd",),
            distribuidoras=("EQTL_MA",),
            output_root=Path("C:/saida"),
        )
        with self.assertRaises(AttributeError):
            request.competencia = "202612"  # type: ignore[misc]

    def test_report_definition_is_immutable(self) -> None:
        definition = ReportDefinition(
            id="x",
            name="X",
            category="Contabilidade",
            module_path="x.py",
            filename_stem="x",
        )
        with self.assertRaises(AttributeError):
            definition.name = "Y"  # type: ignore[misc]


if __name__ == "__main__":
    unittest.main()
