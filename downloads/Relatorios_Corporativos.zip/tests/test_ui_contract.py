from __future__ import annotations

from pathlib import Path
import re
import unittest


ROOT = Path(__file__).resolve().parents[1]
UI_PATH = ROOT / "ui" / "main_window.py"
STYLE_PATH = ROOT / "ui" / "styles.qss"
APP_PATH = ROOT / "app.py"
ICON_PATH = ROOT / "ui" / "assets" / "app_icon.svg"


class UiContractTests(unittest.TestCase):
    def test_qt_checkbox_uses_check_state_enum(self) -> None:
        source = UI_PATH.read_text(encoding="utf-8")
        self.assertRegex(source, r"from PySide6\.QtCore import .*\bQt\b")
        self.assertIn("Qt.CheckState.Unchecked", source)
        self.assertIn("Qt.CheckState.Checked", source)
        self.assertNotRegex(source, r"setCheckState\(\s*[02]\s*\)")
        self.assertNotRegex(source, r"checkState\(\)\s*==\s*[02]\b")

    def test_ui_contains_selection_execution_timer_and_history_contract(self) -> None:
        source = UI_PATH.read_text(encoding="utf-8")
        for text in (
            "Competência",
            "Distribuidoras",
            "Executar selecionados",
            "Cancelar",
            "Tempo total",
            "Duração",
            "Histórico",
        ):
            self.assertIn(text, source)
        self.assertNotIn("self.resize(1280, 900)", source)

    def test_status_is_clickable_and_exports_are_available_in_tabs(self) -> None:
        source = UI_PATH.read_text(encoding="utf-8")
        for text in (
            "QTabWidget",
            "self.status_button",
            "self.status_button.clicked.connect(self._show_status_detail)",
            "self._show_status_detail",
            "export_results",
            "export_history",
            "Baixar resultados",
            "Baixar histórico",
            'self.tabs.addTab(results_page, "Resultados")',
            'self.tabs.addTab(history_page, "Histórico")',
        ):
            self.assertIn(text, source)

    def test_layout_uses_balanced_controls_and_readable_status_dialog(self) -> None:
        source = UI_PATH.read_text(encoding="utf-8")
        for text in (
            "class StatusDetailDialog(QDialog)",
            "dialog.exec()",
            "setPlainText(summary.detail)",
            "parameter_grid.setColumnStretch(2, 1)",
            "browse.setFixedWidth(170)",
            "self.report_list.setMinimumHeight(170)",
            "self.dist_list.setMinimumHeight(170)",
        ):
            self.assertIn(text, source)

    def test_window_adapts_to_notebook_area_and_can_scroll_vertically(self) -> None:
        source = UI_PATH.read_text(encoding="utf-8")
        for text in (
            "QScrollArea",
            "layout.setSizeConstraint(QLayout.SizeConstraint.SetMinimumSize)",
            "scroll.setWidgetResizable(True)",
            "scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)",
            "scroll.setWidget(root)",
            "availableGeometry()",
        ):
            self.assertIn(text, source)

    def test_export_messages_use_readable_application_dialog(self) -> None:
        source = UI_PATH.read_text(encoding="utf-8")
        for text in (
            "class ApplicationMessageDialog(QDialog)",
            "def _show_message(",
            'self._show_message("Histórico baixado"',
            'self._show_message("Resultados baixados"',
            "message_dialog.exec()",
        ):
            self.assertIn(text, source)
        self.assertNotIn("QMessageBox.information", source)
        self.assertNotIn("QMessageBox.critical", source)
        self.assertNotIn("QMessageBox.warning", source)

    def test_results_table_formats_line_counts_in_brazilian_style(self) -> None:
        source = UI_PATH.read_text(encoding="utf-8")
        self.assertIn("format_row_count(result.rows)", source)

    def test_application_sets_a_taskbar_icon(self) -> None:
        source = APP_PATH.read_text(encoding="utf-8")
        self.assertIn("QIcon", source)
        self.assertIn("setWindowIcon", source)
        self.assertIn("app_icon.svg", source)
        self.assertTrue(ICON_PATH.is_file())

    def test_ui_style_declares_dark_text_for_light_controls(self) -> None:
        style = STYLE_PATH.read_text(encoding="utf-8")
        self.assertRegex(style, r"QWidget\s*\{[^}]*color:\s*#1f2937")
        self.assertRegex(style, r"QListWidget::item\s*\{[^}]*color:\s*#1f2937")
        self.assertRegex(style, r"QPushButton\s*\{[^}]*color:\s*#1f2937")

    def test_notebook_layout_uses_compact_readable_typography(self) -> None:
        style = STYLE_PATH.read_text(encoding="utf-8")
        self.assertRegex(style, r"QWidget\s*\{[^}]*font-size:\s*9pt")
        self.assertRegex(style, r"QLabel#appTitle\s*\{[^}]*font-size:\s*18pt")
        self.assertRegex(style, r"QLineEdit, QComboBox\s*\{[^}]*min-height:\s*24px")
        self.assertRegex(style, r"QLineEdit, QComboBox\s*\{[^}]*padding:\s*2px 8px")
        self.assertRegex(style, r"QGroupBox\s*\{[^}]*padding:\s*10px 8px 8px")

    def test_app_entrypoint_does_not_import_snowflake(self) -> None:
        source = APP_PATH.read_text(encoding="utf-8")
        self.assertIn("QApplication", source)
        self.assertNotIn("snowflake.connector", source)


if __name__ == "__main__":
    unittest.main()
