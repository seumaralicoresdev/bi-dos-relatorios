from __future__ import annotations

from pathlib import Path
import tempfile
import unittest

from openpyxl import load_workbook

from app.audit import (
    export_history,
    export_results,
    summarize_batch,
    summarize_history_record,
)
from app.models import ExecutionResult


def make_result(
    report_id: str,
    report_name: str,
    status: str,
    *,
    message: str = "",
    error: str | None = None,
) -> ExecutionResult:
    return ExecutionResult(
        report_id=report_id,
        report_name=report_name,
        category="Tributario",
        competencia="202611",
        status=status,
        output_path=Path(r"C:\Relatorios") / f"{report_id}.xlsx" if status == "success" else None,
        duration_seconds=12.5,
        rows=10 if status == "success" else None,
        sheets=("EQTL_MA",) if status == "success" else (),
        message=message,
        error=error,
    )


class AuditTests(unittest.TestCase):
    def test_success_summary_explains_complete_process(self) -> None:
        summary = summarize_batch((make_result("a", "Relatório A", "success", message="Arquivo gerado"),))

        self.assertEqual(summary.level, "success")
        self.assertEqual(summary.label, "Concluído")
        self.assertIn("devidamente concluído", summary.detail)

    def test_warning_summary_contains_report_and_warning_message(self) -> None:
        summary = summarize_batch(
            (make_result("a", "Relatório A", "warning", message="Arquivo não foi criado"),)
        )

        self.assertEqual(summary.level, "warning")
        self.assertEqual(summary.label, "Concluído com alerta")
        self.assertIn("Relatório A", summary.detail)
        self.assertIn("Arquivo não foi criado", summary.detail)

    def test_failure_summary_contains_failure_reason(self) -> None:
        summary = summarize_batch(
            (make_result("a", "Relatório A", "failed", error="Conexão recusada"),)
        )

        self.assertEqual(summary.level, "failed")
        self.assertEqual(summary.label, "Falha na execução")
        self.assertIn("Conexão recusada", summary.detail)

    def test_cancelled_summary_is_explicit(self) -> None:
        summary = summarize_batch((), cancelled=True)

        self.assertEqual(summary.level, "cancelled")
        self.assertEqual(summary.label, "Execução cancelada")
        self.assertIn("cancelada", summary.detail.lower())

    def test_history_summary_reuses_persisted_report_details(self) -> None:
        summary = summarize_history_record(
            {
                "cancelled": False,
                "results": [
                    {
                        "report_name": "Relatório A",
                        "status": "warning",
                        "message": "Arquivo não foi criado",
                        "error": None,
                    }
                ],
            }
        )

        self.assertEqual(summary.level, "warning")
        self.assertIn("Arquivo não foi criado", summary.detail)

    def test_history_summary_reports_worker_failure_without_report_rows(self) -> None:
        summary = summarize_history_record(
            {
                "cancelled": False,
                "execution_error": "keyring indisponível",
                "results": [],
            }
        )

        self.assertEqual(summary.level, "failed")
        self.assertIn("keyring indisponível", summary.detail)

    def test_exports_results_and_history_to_auditable_workbooks(self) -> None:
        results = (
            make_result("a", "Relatório A", "success", message="Arquivo gerado"),
            make_result("b", "Relatório B", "failed", error="Timeout"),
        )
        history = [
            {
                "started_at": "2026-11-05T08:25:28",
                "finished_at": "2026-11-05T08:35:16",
                "duration_seconds": 588,
                "cancelled": False,
                "competencia": "202611",
                "report_ids": ["a", "b"],
                "distribuidoras": ["EQTL_MA"],
                "output_root": r"C:\Relatorios",
                "results": [
                    {
                        "report_name": "Relatório A",
                        "status": "success",
                        "message": "Arquivo gerado",
                        "error": None,
                    },
                    {
                        "report_name": "Relatório B",
                        "status": "failed",
                        "message": "Não processado",
                        "error": "Timeout",
                    },
                ],
            }
        ]
        with tempfile.TemporaryDirectory() as temp:
            results_path = Path(temp) / "resultados.xlsx"
            history_path = Path(temp) / "historico.xlsx"

            self.assertEqual(export_results(results, results_path), results_path)
            self.assertEqual(export_history(history, history_path), history_path)

            results_workbook = load_workbook(results_path, read_only=True, data_only=True)
            try:
                sheet = results_workbook["Resultados"]
                headers = [cell.value for cell in next(sheet.iter_rows(max_row=1))]
                values = [cell.value for cell in next(sheet.iter_rows(min_row=2, max_row=2))]
                self.assertIn("Detalhes", headers)
                self.assertIn("Arquivo gerado", values)
            finally:
                results_workbook.close()

            history_workbook = load_workbook(history_path, read_only=True, data_only=True)
            try:
                sheet = history_workbook["Histórico"]
                headers = [cell.value for cell in next(sheet.iter_rows(max_row=1))]
                values = [cell.value for cell in next(sheet.iter_rows(min_row=2, max_row=2))]
                self.assertIn("Detalhes", headers)
                self.assertIn("Falha na execução", values)
            finally:
                history_workbook.close()


if __name__ == "__main__":
    unittest.main()
