from __future__ import annotations

from pathlib import Path
import tempfile
import unittest

from app.history import HistoryStore
from app.models import BatchResult, ExecutionRequest, ExecutionResult


class HistoryTests(unittest.TestCase):
    def test_batch_history_round_trip(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "user-data" / "history.json"
            store = HistoryStore(path)
            request = ExecutionRequest("202611", ("mmgd",), ("EQTL_MA",), Path(temp) / "out")
            result = ExecutionResult(
                report_id="mmgd",
                report_name="MMGD",
                category="Contabilidade",
                competencia="202611",
                status="success",
                output_path=Path(temp) / "out" / "mmgd.xlsx",
                duration_seconds=12.5,
                rows=10,
                sheets=("EQTL_MA",),
                message="ok",
            )
            batch = BatchResult((result,), "2026-11-04T10:00:00", "2026-11-04T10:00:12", 12.5)

            store.append_batch(request, batch)
            records = HistoryStore(path).load()

            self.assertEqual(len(records), 1)
            self.assertEqual(records[0]["competencia"], "202611")
            self.assertEqual(records[0]["results"][0]["output_path"], str(result.output_path))
            self.assertEqual(records[0]["duration_seconds"], 12.5)

    def test_missing_history_is_empty(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            self.assertEqual(HistoryStore(Path(temp) / "missing.json").load(), [])

    def test_batch_history_can_record_failure_before_first_report(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "user-data" / "history.json"
            store = HistoryStore(path)
            request = ExecutionRequest("202611", ("mmgd",), ("EQTL_MA",), Path(temp) / "out")
            batch = BatchResult((), "2026-11-05T08:00:00", "2026-11-05T08:00:01", 1.0)

            store.append_batch(request, batch, execution_error="keyring indisponível")
            record = HistoryStore(path).load()[0]

            self.assertEqual(record["execution_error"], "keyring indisponível")


if __name__ == "__main__":
    unittest.main()
