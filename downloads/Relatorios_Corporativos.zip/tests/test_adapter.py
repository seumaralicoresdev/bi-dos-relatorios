from __future__ import annotations

from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import tempfile
import textwrap
import time
import unittest

from app.legacy_adapter import LegacyAdapter
from app.models import ExecutionRequest, ReportDefinition
from app.snowflake_session import SnowflakeSession


class FakeSession:
    def __init__(self) -> None:
        self.prepare_calls = 0
        self.connect_calls = 0

    def prepare(self) -> None:
        self.prepare_calls += 1

    def connect(self):
        self.connect_calls += 1
        return object()


class FakeConnection:
    def __init__(self, number: int) -> None:
        self.number = number
        self.closed = False

    def close(self) -> None:
        self.closed = True


class FakeConnector:
    def __init__(self, delay: float = 0.0) -> None:
        self.connections: list[FakeConnection] = []
        self.delay = delay

    def connect(self, **kwargs):
        if self.delay:
            time.sleep(self.delay)
        connection = FakeConnection(len(self.connections) + 1)
        self.connections.append(connection)
        return connection


class AdapterTests(unittest.TestCase):
    def test_snowflake_session_bootstraps_once_and_opens_independent_connections(self) -> None:
        connector = FakeConnector()
        session = SnowflakeSession(connector=connector, account='account', user='user')

        session.prepare()
        first = session.connect()
        second = session.connect()
        session.close()

        self.assertEqual(len(connector.connections), 3)
        self.assertIsNot(first, second)
        self.assertTrue(connector.connections[0].closed)
        self.assertFalse(first.closed)
        self.assertFalse(second.closed)

    def test_snowflake_cache_uses_secure_credential_flag_without_deprecated_mfa_flag(self) -> None:
        session = SnowflakeSession(connector=FakeConnector(), account='account', user='user')

        kwargs = session._kwargs()

        self.assertTrue(kwargs["client_store_temporary_credential"])
        self.assertNotIn("client_request_mfa_token", kwargs)

    def test_concurrent_first_connections_share_one_bootstrap(self) -> None:
        connector = FakeConnector(delay=0.01)
        session = SnowflakeSession(connector=connector, account='account', user='user')

        with ThreadPoolExecutor(max_workers=6) as executor:
            connections = list(executor.map(lambda _item: session.connect(), range(6)))

        self.assertEqual(len(connections), 6)
        self.assertEqual(len(connector.connections), 7)
        self.assertTrue(connector.connections[0].closed)

    def _make_module(self, body: str) -> tuple[Path, ReportDefinition]:
        root = Path(tempfile.mkdtemp())
        module_path = root / "relatório_fake.py"
        module_path.write_text(textwrap.dedent(body), encoding="utf-8")
        definition = ReportDefinition(
            id="fake",
            name="Fake",
            category="Contabilidade",
            module_path=module_path.name,
            filename_stem="fake",
            distributor_template={
                "EQTL_MA": {"prd_schema": "EQTL_MA", "raw_schema": "CCS_MA"},
                "EQTL_PA": {"prd_schema": "EQTL_PA", "raw_schema": "CCS_PA"},
            },
        )
        return root, definition

    def test_overrides_runtime_globals_and_returns_output(self) -> None:
        root, definition = self._make_module(
            """
            from pathlib import Path
            MES_COMPET = '000000'
            DISTRIBUIDORAS = {'OLD': 'OLD'}
            OUTPUT_PATH = Path('old.xlsx')
            PASTA_BASES = Path('old-base')
            def get_connection():
                raise AssertionError('adapter did not replace get_connection')
            def main():
                assert MES_COMPET == '202611'
                assert list(DISTRIBUIDORAS) == ['EQTL_PA']
                assert OUTPUT_PATH.name == 'fake_202611.xlsx'
                assert PASTA_BASES.name == 'base_mmgd_202611'
                print('fake executed')
                OUTPUT_PATH.write_text('ok', encoding='utf-8')
            """
        )
        session = FakeSession()
        logs: list[str] = []
        adapter = LegacyAdapter(root, session=session)
        request = ExecutionRequest('202611', ('fake',), ('EQTL_PA',), root / 'output')
        output = root / 'output' / '202611' / 'Contabilidade' / 'fake_202611.xlsx'

        result = adapter.run(definition, request, output, logs.append)

        self.assertEqual(result, output)
        self.assertTrue(output.is_file())
        self.assertEqual(session.prepare_calls, 1)
        self.assertTrue(any('fake' in line.lower() for line in logs))

    def test_adapter_does_not_import_with_default_network_mkdir(self) -> None:
        root, definition = self._make_module(
            """
            from pathlib import Path
            OUTPUT_PATH = Path(r'\\\\server\\default\\file.xlsx')
            OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)
            DISTRIBUIDORAS = {'EQTL_MA': 'EQTL_MA'}
            MES_COMPET = '000000'
            def main():
                OUTPUT_PATH.write_text('ok', encoding='utf-8')
            """
        )
        session = FakeSession()
        adapter = LegacyAdapter(root, session=session)
        request = ExecutionRequest('202611', ('fake',), ('EQTL_MA',), root / 'output')
        output = root / 'output' / '202611' / 'Contabilidade' / 'fake_202611.xlsx'

        self.assertEqual(adapter.run(definition, request, output, lambda _: None), output)


if __name__ == '__main__':
    unittest.main()
