// RASCUNHO: criar parâmetro Texto pCompetencia.
// Substituir Empresas pela lista desejada abaixo. Começar com UMA empresa/competência.
// A consulta falha como um todo se uma chamada falhar: não ignora empresas com erro.
// pCompetencia valida uma competência. Para histórico, iterar lista explícita de meses sem sobreposição.
let
    Empresas = {"EQTL_MA"},
    // Após homologar, ampliar para {"EQTL_MA", "EQTL_PA", "EQTL_PI", "EQTL_AL", "EQTL_AP", "EQTL_RS"}.
    Resultados = List.Transform(Empresas,
        each fnConsultaSQL("modelo/01_fato_faturamento.sql", _, pCompetencia)),
    Combinado = Table.Combine(Resultados),
    Tipos = Table.TransformColumnTypes(Combinado, {
        {"EmpresaChave", type text}, {"DataCompetencia", type date}, {"DataReferencia", type date},
        {"Mercado", type text}, {"Grupo", type text}, {"SubGrupoTensao", type text},
        {"CategoriaTarifa", type text}, {"ItemDocumento", type text}, {"ClasseOrigem", type text},
        {"ValorFaturado", Currency.Type}, {"COFINS", Currency.Type}, {"ICMS", Currency.Type},
        {"PIS", Currency.Type}, {"ValorSemImposto", Currency.Type}, {"ConsumoOrigem", type number}
    })
in
    Tipos
// Currency.Type usa 4 casas; conferir precisão da fonte e tolerância contábil antes de aplicar.
