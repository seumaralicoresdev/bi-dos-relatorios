// RASCUNHO: criar consulta em branco e nomear fnConsultaSQL.
// Parâmetros Texto: pServidorSnowflake (host aprovado), pWarehouse, pPastaSQL.
// pPastaSQL aponta para a pasta entrega/sql. Credenciais ficam no conector, nunca no M.
// Não usa a sessão Python/externalbrowser. Revisar autenticação no Desktop e no Service.
(ArquivoRelativo as text, Empresa as text, Competencia as text, optional MesInicio as nullable text) as table =>
let
    Empresas = {"EQTL_MA", "EQTL_PA", "EQTL_PI", "EQTL_AL", "EQTL_AP", "EQTL_RS"},
    EmpresaValidada = if List.Contains(Empresas, Empresa) then Empresa else error "Distribuidora inválida",
    ValidaMes = (s as text) as text =>
        if Text.Length(s) <> 6 or Text.Select(s, {"0".."9"}) <> s then error "Use YYYYMM"
        else let d = try Date.FromText(s & "01", [Format="yyyyMMdd", Culture="en-US"])
             in if d[HasError] then error "Competência inválida" else s,
    Mes = ValidaMes(Competencia),
    Inicio = if MesInicio = null then Mes else ValidaMes(MesInicio),
    Intervalo = if Inicio <= Mes then Inicio else error "Mês inicial posterior ao final",
    TextoSQL = Text.FromBinary(File.Contents(pPastaSQL & "/" & ArquivoRelativo), TextEncoding.Utf8),
    Regras = {
        {"{EMP}", EmpresaValidada}, {"{SCHEMA}", EmpresaValidada},
        {"{PRD_SCHEMA}", EmpresaValidada}, {"{RAW_SCHEMA}", "CCS_" & Text.AfterDelimiter(EmpresaValidada,"EQTL_")},
        {"{MES}", Mes}, {"{MES_COMPET}", Mes}, {"{MES_INICIO}", Intervalo}, {"{MES_FIM}", Mes}
    },
    SQL = List.Accumulate(Regras, TextoSQL, (s, par) => Text.Replace(s, par{0}, par{1})),
    Conexao = Snowflake.Databases(pServidorSnowflake, pWarehouse, [Implementation="2.0"]),
    Banco = Conexao{[Name="SB_FATURAMENTO", Kind="Database"]}[Data],
    Resultado = Value.NativeQuery(Banco, SQL, null, [EnableFolding=true])
in
    Resultado
