# Páginas e visuais do painel

Desenho para Power BI Desktop, sem dados simulados. Layout 16:9, filtros no topo, quatro indicadores principais, evolução à esquerda e composição à direita, matriz de detalhe na parte inferior. O SVG da página executiva ilustra a disposição sem representar valores medidos.

## 1. Visão contábil e financeira

**Pergunta:** como evolui o valor faturado e o que explica sua composição?

| Visual | Campos e medidas | Interação |
|---|---|---|
| Segmentações | DimData[AnoMes], DimEmpresa[UF], DimMercado[Mercado] | AnoMes ordenado; seleção mensal para MoM |
| Faixa de qualidade | Cobertura da carga %, Ultima extracao validada | Avisar carga incompleta; não apresentar ausência como zero |
| Quatro cards | Valor faturado; Tributos destacados; Valor sem ICMS PIS COFINS; Valor faturado MoM % | Formato monetário só após confirmação de moeda; MoM em branco se incompleto |
| Linha mensal | X=AnoMes; Y=Valor faturado e Valor sem ICMS PIS COFINS | Comparar na mesma unidade; filtro da competência |
| Barras por empresa | Y=UF; X=Valor faturado; legenda=Mercado | Ordenação por valor; tooltip com participação tributária |
| Matriz | Linhas=UF→Mercado→CategoriaTarifa→ItemDocumento; medidas=valor, tributos, valor sem três tributos e MoM | Totais por medida, sem soma de outras famílias |

Tooltip de página: competência, mercado, valor, três tributos, participação tributária e cobertura. Sem CPF/CNPJ, nomes ou endereços. Na página principal, não usar ClasseOrigem como classe universal.

## 2. Faturamento e tributos

- Cards: ICMS faturado, PIS faturado, COFINS faturada, Participacao tributaria %.
- Colunas empilhadas: eixo UF ou AnoMes, séries dos três tributos. Não misturar percentual no mesmo eixo de dinheiro.
- Matriz: UF → Mercado → ItemDocumento, três tributos, valor faturado e participação tributária recalculada no total.
- Dispersão opcional: X=Valor faturado, Y=Participacao tributaria %, detalhe=empresa/mês, somente períodos completos. Uma correlação não prova mudança legal de alíquota.
- Referência alternativa: filtros DimDataReferencia[AnoMes] com título “mês de referência”. Competência e referência são filtros distintos.

## 3. Descontos e modicidade

- Dois blocos separados: Desconto tarifario assinado e Modicidade assinada; sem total somando recortes sobrepostos.
- Barras horizontais divergentes por empresa/item para descontos, mantendo sinais. Matriz item ordenação/documento/suboperação e marcador GD.
- Matriz de modicidade por Operacao → SubOperacao → Bloqueio, com ValorModicidadeAssinado; filtro por mês de REFERENCIA. MES_LANCAMENTO é um atributo temporal próprio.
- Não publicar “perda de receita” ou “subsídio recuperável” sem definição do sinal e regra contábil.

## 4. Reativos e ultrapassagem de demanda

- Dois cards: Reativos faturados e Ultrapassagem faturada. São grandezas financeiras em blocos independentes.
- Tendências mensais em gráficos separados; barras de concentração por instalação, com empresa sempre visível.
- Matriz empresa → instalação → item, valor faturado e valor sem ICMS/PIS/COFINS de cada fato.
- Drill-through por instalação **somente nessas fatos**, com chave empresa+instalação. Se for implantado, criar dimensão compartilhada validada; não ligar uma fato à outra.
- Não mostrar demanda contratada, kW excedente, fator de potência ou economia potencial: esses campos não estão disponíveis na saída.

## 5. Financiamento e consumo próprio

- Bloco Financiamento: segmentação de moeda e rótulo “mês de entrada”; cards de montante documental e compensação, sem tratá-los como recebimento/saldo devedor.
- Matriz de documentos: empresa, mandante, nota, número documento, moeda, montante. Status só na matriz de compensações, pois uma nota pode ter mais de um status.
- Não contar QTD_PARCELAS como parcelas únicas: a fonte conta TEXTO_ITEM não nulo. Exibir apenas em detalhe com esse nome, se necessário.
- Bloco Consumo Próprio: valor das faturas, ICMS, barras por TipoSistema e matriz por SituacaoDocumento. O consumo fica oculto até homologar unidade e evitar repetição de cabeçalhos.

## 6. MMGD e saldo bloqueado

- Dois blocos com unidades independentes: créditos registrados em kWh e quantidade bloqueada na unidade de origem a confirmar.
- Linha de MMGD por DimMesCredito[AnoMes], ranking de geradoras e matriz competência × mês do crédito. Rótulos temporais definitivos dependem de homologar MES e MES_COMPETENCIA.
- Saldo bloqueado: seleção de uma fotografia, card de quantidade e ranking de contratos. Linha mensal possível por fotografias, mas total de vários meses não é saldo.
- Não criar percentual “bloqueado / MMGD” antes de provar unidade e população equivalentes. Não chamar esses campos de saldo em reais ou créditos a vencer.

## 7. Encargos, isenção e injetada

- Linhas separadas para Covid e Escassez, ambas no período explícito da carga.
- Barras de redução assinada de isenção por município fiscal. Não usar mapa até validar códigos e geografia.
- Série de valor dos itens de Injetada. Consumo/total injetado ficam ocultos até validar unidade e regra da soma dos ZPGAT.
- Cards mantêm nomes literais: “Redução assinada” e “Valor dos itens selecionados”. Nenhum é automaticamente o valor do imposto devido ou recuperável.

## 8. Conciliação e retenções

**Página condicionada aos metadados reais**, sem números ou medidas fictícias no pacote.

- Matriz de conciliação por empresa/competência: núcleo de faturamento, valor equivalente do resumo, diferença absoluta, diferença relativa e motivo da diferença.
- Antes de construir o visual, mapear as colunas de RESUMO_FAT_TRIBUTOS e confirmar o efeito de CLASSE IS NOT NULL, mercado, estornos e impostos.
- Bloco de retenções com tributos e valores efetivamente existentes em BASE_IMPOSTO_RETIDO; cards e matriz por empresa/competência após definir grão.
- Indicadores técnicos em um painel de suporte: empresas esperadas/carregadas, datas de extração, chaves duplicadas, linhas sem dimensão e regras não homologadas. Não inventar um semáforo “conciliado” baseado só em bruto−tributos−líquido=0.

## Regras visuais comuns

- Tema em `visuais/tema_contabilidade.json`: azul para faturamento, verde para valor sem os três tributos e âmbar para atenção. Texto/ícones acompanham status; cor sozinha não comunica sucesso/falha.
- Fundo claro, contraste alto, títulos que informam medida e período. Fonte mínima de 11–12 pt nas tabelas; valores monetários abreviados com unidade explícita.
- Mostrar negativos com sinal; BLANK aparece como “Sem base/carga”, não como zero. Valores efetivamente zero permanecem zero.
- Sincronizar somente filtros suportados pelas páginas: Mercado não filtra MMGD/Financiamento; DimMesCredito não filtra faturamento.
- Habilitar interações conscientemente. Selecionar um item da fato de reativos não deve aparentar filtrar o faturamento por relação inexistente.
- Detalhes pessoais e caminhos de arquivos ficam fora das páginas gerenciais. RLS por empresa é uma proposta futura, condicionada aos públicos e papéis de acesso, não implantada nesta entrega.
