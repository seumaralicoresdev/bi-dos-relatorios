# Implantação e validação

## Limite da validação desta entrega

Os arquivos foram verificados localmente como textos e contratos: extração dos SQLs, hashes de módulos principais, sintaxe Snowflake por parser, referências entre medidas e campos projetados e integridade do pacote. O relatório `validacao_estatica.json` registra exatamente os resultados. Parser não verifica existência de colunas, permissões, multiplicação de joins ou regra contábil. **DAX e M não foram executados no Power BI; consultas não foram executadas no Snowflake.**

Não foi criado PBIX, nem simulada uma conexão ou uma publicação. O gerador `New-PowerBIModelWizard.ps1` referenciado na skill não está acessível como arquivo/ferramenta nesta sessão e PowerShell/Desktop não estão disponíveis. Os mesmos componentes de desenho foram preparados em arquivos-texto para revisão e aplicação no Desktop.

## Sequência de montagem no Desktop

1. **Homologar uma empresa e uma competência.** Começar pelo núcleo cativo/livre. Definir moeda, sinais, tributos, mercado, chaves e escopo; aprovar especificamente a política RS antes de incluí-lo em um total consolidado.
2. **Preparar a conexão.** Usar o conector Snowflake do Power BI com servidor, warehouse e função de acesso aprovados. O warehouse e os bancos precisam das permissões de leitura, incluindo os três bancos usados pelo projeto. O SSO do Python não fornece automaticamente autenticação de refresh do Power BI Service. Não colocar credenciais no SQL/M.
3. **Descobrir os dois schemas ausentes.** Executar o bloco de INFORMATION_SCHEMA em `sql/modelo/12_diagnosticos_snowflake.sql`. Obter uma amostra anonimizada de Resumo/Retenção e respectivas chaves/unidades. Não inventar essas colunas.
4. **Criar parâmetros Texto** `pServidorSnowflake`, `pWarehouse`, `pPastaSQL` (caminho à pasta sql) e `pCompetencia` (YYYYMM). Em consulta em branco, colar `power_query/fnConsultaSQL.m` e nomear `fnConsultaSQL`. Criar a consulta `FatoFaturamento` com o segundo M. Editar inicialmente a lista de empresas para uma só. Aprovar consulta nativa após revisar o texto.
5. **Validar a carga inicial e o histórico.** O exemplo carrega um mês. Para MoM, carregar pelo menos o anterior; para YoY, o correspondente do ano anterior, além do calendário contínuo. Iterar meses explícitos apenas em fontes de competência exata. Nunca repetir a janela MMGD em cada mês e anexar tudo.
6. **Criar as demais fatos** chamando a mesma função com cada SQL mapeado em `02_modelo_e_relacionamentos.md`. Ex.: `fnConsultaSQL("modelo/02_fato_desconto.sql", "EQTL_MA", pCompetencia)`. Para encargos/isenção passar MesInicio explicitamente: a função usa pCompetencia como mês final. Nenhum script faz provisionamento de tabelas no banco.
7. **Materializar FatoControleCarga.** Uma linha única por combinação empresa/mês/mercado, preenchida pelo resultado validado da extração. Sem essa tabela, importar somente as medidas independentes de cobertura; MoM/YoY protegidos permanecem desabilitados. Não usar uma tabela manual preenchida com TRUE por suposição.
8. **Criar dimensões**, renomear Date para Data, marcar DimData e configurar relações da planilha CSV. Criar primeiro relações do núcleo. As relações opcionais/condicionais só entram após suas fatos existirem e passarem nos contratos. Ocultar colunas numéricas brutas para impedir somas acidentais por arraste.
9. **Criar medidas individualmente** dos arquivos DAX. As medidas dependentes de fatos ainda não carregadas não devem ser coladas antes delas. Configurar formato monetário após confirmar moeda; percentuais como 0,0%; quantidades na unidade homologada. `Financiamento` retorna branco quando há várias moedas.
10. **Montar oito páginas**, aplicar tema, testar filtros/interações e totais. Salvar como PBIP no Desktop para permitir revisão textual. Aplicar DAX/TMDL ao PBIP apenas após a revisão do desenho e validar no Desktop; o pacote não modifica um PBIP existente.

## Checks que precisam de dados reais

| Check | Critério de aceite |
|---|---|
| Cabeçalho FATURAMENTO | Chave empresa+competência+documentos única ou regra documentada para selecionar a versão válida |
| Dicionário de item/mandante | Uma correspondência por item/empresa/idioma; não aceitar seis mandantes como correspondências aditivas |
| Cadastros, fotos e operandos | Uma correspondência válida por chave/data, sem vigências sobrepostas |
| Junções | Comparar quantidade de registros e soma por chave antes/depois, explicando exclusões/expansões; igualdade bruto−tributos−líquido não basta |
| Mercado | Confirmar NULL/X e listar outros marcadores; provar disjunção e cobertura de Cativos/Livres |
| Conciliação | Por empresa/mês/item/mercado, comparar legado, extração adaptada e fonte contábil aprovada; tolerância acordada pelo negócio |
| Encargos | Sem linha artificial; consumo de cabeçalho contado uma vez por documento; período da carga explícito |
| Financiamento | Chave candidata única na nota e regra válida para associação de itens financeiros; não replicar montante da nota por status |
| MMGD | Uma única versão por chave lógica ou snapshot selecionado; sem sobreposição duplicada; conciliar número decimal com CSV formatado |
| Saldo bloqueado | Unidade, corte de datas, contrato/conta e diferença decorrente de remover TRUNC documentados; total temporal bloqueado |
| Valores/códigos | Preservar zeros de IDs, escala decimal e sinais; nenhum CPF/CNPJ/endereço no painel gerencial |
| Cobertura | Uma linha de controle por combinação esperada, incluindo zero válido; ausência e erro distintos de zero |
| Power BI | Relações 1:*, filtros únicos, totais coerentes, BLANK/zero distintos; Desktop sem erros de M/DAX |
| Casos temporais | Sem mês anterior → MoM em branco; carga parcial → MoM em branco; múltiplos meses no card MoM → em branco; variação de linha mensal calculada por ponto |

`12_diagnosticos_snowflake.sql` inicia as verificações, mas não é uma suíte completa de reconciliação. Há múltiplos SELECTs: executar cada bloco separadamente na worksheet; não usar esse arquivo como uma única tabela no Power Query.

## Atualização e acesso

Refresh no Service exige definição separada de autenticação, conexão, caminho de arquivos/gateway se usado e agenda. Se a função M ler arquivos SQL locais, esses arquivos e o caminho precisam estar disponíveis ao mecanismo de refresh; alternativa preferida de produção é centralizar consultas em views aprovadas ou incorporar o SQL revisado no M. O exemplo de arquivos externos é para desenvolvimento e revisão, não prova de refresh cloud funcionando.

RLS por distribuidora pode ser implementada após receber o mapa usuário/grupo→empresa; aplicar as mesmas regras a todas as fatos. Não publicar dados pessoais apenas porque estão no legado. Não há alteração de permissões ou publicação autorizada/realizada nesta entrega.
