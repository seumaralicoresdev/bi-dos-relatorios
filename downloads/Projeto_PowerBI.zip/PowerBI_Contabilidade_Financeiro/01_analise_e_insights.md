# Análise e insights possíveis

## Conclusões comprovadas pelo código

1. **Os relatórios têm populações sobrepostas.** Descontos, reativos, demanda e encargos selecionam itens que podem estar no faturamento. São diagnósticos, não receitas adicionais para um total geral.
2. **A competência da tela não controla todas as consultas.** Covid/Escassez usam os seis meses completos anteriores à data atual; Isenção usa os três anteriores. O período no nome do arquivo pode divergir do período dos dados.
3. **Os grãos são diferentes.** Cativos é agregado; Livres tem detalhe que a tabela comum não conserva; saldos são retratos; financiamento agrega itens financeiros junto a atributos de nota.
4. **RS não tem regras uniformes com as outras empresas.** Há diferenças de códigos, documentos excluídos, SUM/MAX de tributos e fonte MMGD. O desktop separa arquivos RS sem selecionar automaticamente essas variantes.
5. **O nome do relatório não garante o significado do valor.** “ICMS Injetada” projeta receita/consumo/injeção, sem coluna de ICMS. “Saldo Bloqueado” projeta quantidade, não dinheiro. “Valor sem imposto” subtrai apenas ICMS, PIS e COFINS; não demonstra lucro ou receita líquida contábil.

Evidências completas e referências arquivo:linha constam em `06_inventario_sql_detalhado.md` e em `inventario_consultas.json`.

## Como cada família entra no painel

“Insight” nesta tabela é uma análise a realizar com dados, **não um resultado já constatado**.

| Família / categoria no app | O que analisar | Medida / visual proposto | Condição para confiar |
|---|---|---|---|
| Clientes Cativos / Contabilidade | Empresas e itens que explicam a variação do faturamento cativo | Valor faturado cativo; tendência e matriz empresa × item | Validar joins de cadastro/classes/mandantes; sem contagem de clientes |
| Clientes Livres / Contabilidade | Participação e evolução do mercado livre | Valor faturado livre; colunas por mercado e drill-through do staging livre | Agregar ao grão comum; validar cobertura do marcador X |
| Desconto Tarifário / Contabilidade | Concentração do valor assinado por item, empresa e marcador GD | Desconto tarifario assinado; barras divergentes e matriz | Sinal e GD precisam de definição; GD não é cadastro universal |
| Modicidade / Contabilidade | Valores por operação, bloqueio e mês de lançamento | Modicidade assinada; matriz operação/suboperação e linha temporal | `VALOR` é agrupado no original; não comprova transação única |
| Saldo Bloqueado / Contabilidade | Contratos com maior quantidade no retrato selecionado | Saldo bloqueado quantidade; ranking de contratos, fotografia mensal | Unidade e vínculo contrato/conta; não somar saldos entre meses |
| MMGD / Contabilidade | Concentração dos créditos registrados por mês e geradora | MMGD creditos kWh; linha e ranking | Não equivale a geração ou saldo disponível; evitar append de janelas |
| Reativos Excedentes / Contabilidade | Itens e empresas com valores elevados/recorrentes | Reativos faturados; ranking e matriz | Não inferir energia/tarifa; RS altera cálculo de tributos |
| Resumo Faturamento / Contabilidade | Conciliação de populações e totais contra o núcleo | Matriz de diferença por empresa/competência, após mapear colunas | Schema desconhecido; filtro `CLASSE IS NOT NULL` muda cobertura |
| Ultrapassagem / Contabilidade | Concentração dos valores de ultrapassagem | Ultrapassagem faturada; ranking de instalações e série | Não existe demanda contratada/medida projetada; não calcular fator de ultrapassagem |
| Financiamento Padrão / Tributário | Montantes documentais e compensações por moeda e mês de entrada | Cards separados e matriz nota/status | Cabeçalho separado dos grupos de compensação; não é fluxo de caixa |
| Consumo Próprio / Tributário | Valor das faturas e ICMS por tipo de sistema | Consumo proprio valor de faturas; matriz sistema/situação | Fotos/intervalos únicos; resolver `NUMERO` duplicado; confirmar unidade de consumo |
| Isenção ICMS TUSD / Tributário | Redução assinada por município/competência | Isencao reducao assinada; barras por município | Nova extração pré-agrega itens e não soma ICMS do cabeçalho repetido |
| ICMS Injetada / Tributário | Valores dos itens selecionados e volumes a validar | Injetada valor de itens; série de valores | Pré-agregar ZPGAT; não apresentar receita como imposto; unidade pendente |
| Encargo Covid / Tributário | Evolução do valor dos itens ZENCOV | Covid valor assinado; linha mensal | Excluir linha artificial e juntar por chave completa; intervalo explícito |
| Escassez Hídrica / Tributário | Evolução do valor dos itens ZESCAS | Escassez valor assinado; linha mensal | Mesmos cuidados de Covid; consumo de cabeçalho não é aditivo por item |
| Retenção de Tributos / Tributário | Composição dos valores retidos e reconciliação | Matriz de tributo × empresa, depois de descobrir o schema | Não inferir nomes de tributos, bases, valores ou alíquotas a partir de SELECT * |

## Indicadores principais

| Indicador | Definição | Decisão que apoia |
|---|---|---|
| Valor faturado | Soma de `VALOR_FATURADO` dos dois mercados, após validação | Acompanhar movimento mensal e sua composição |
| Tributos destacados | ICMS + PIS + COFINS das mesmas linhas | Explicar a diferença entre o valor faturado e o valor sem os três tributos |
| Participação tributária | Soma dos tributos / soma do valor faturado | Investigar mudanças de mix e tratamento tributário; não determina alíquota legal |
| MoM / YoY | Variação contra mês/ano anterior, com cargas completas em ambos | Identificar mudanças que merecem investigação |
| Cobertura da carga | Combinações empresa/mês/mercado validadas / esperadas | Evitar interpretar empresa ausente como queda de faturamento |

Os demais indicadores são diagnósticos temáticos. Metas e tolerâncias financeiras não foram inventadas: devem vir dos responsáveis contábeis, considerando moeda, arredondamento e materialidade.

## Leituras úteis quando os dados estiverem disponíveis

- Decompor variação mensal por empresa, mercado, categoria tarifária e item. Separar mudança de população de mudança de valor.
- Comparar participação tributária dentro de grupos comparáveis. Uma mudança de mix pode explicar a taxa agregada sem alteração de regra legal.
- Identificar concentração e reversões de sinal em descontos, modicidade, reativos e ultrapassagem. Valores negativos não são automaticamente erros.
- Comparar faturamento e resumo com mesma população e mesma competência. Uma igualdade aritmética interna não valida o total contra o razão.
- Analisar financiamento pelo mês de entrada e moeda. Compensação não prova recebimento bancário; ATIVO/INATIVO não prova inadimplência.
- Identificar concentração de créditos por geradora e mês, sem concluir vencimento a partir de uma coluna cujo significado não foi homologado.

Não há base suficiente para inadimplência, contas a receber, aging, margem, EBITDA, recebimentos, ticket médio por cliente ou projeção de caixa.
