# Modelo semântico e relacionamentos

## Estrutura escolhida

Uma constelação de fatos com dimensões conformadas. Alternativas avaliadas: (a) anexar todos os relatórios em uma fato, descartado por misturar grãos/unidades e duplicar receita; (b) usar apenas Excel/CSV do desktop, possível como fase transitória, mas herda arredondamento, janelas sobrepostas e ausência de controle por empresa; (c) extração Snowflake parametrizada, recomendada para rastreabilidade e reconciliação. Essas são decisões propostas pelo desenho, ainda sujeitas à homologação dos dados.

```mermaid
flowchart LR
 E[DimEmpresa] --> F[FatoFaturamento]
 D[DimData: competência] --> F
 R[DimDataReferencia] --> F
 M[DimMercado] --> F
 I[DimItemFaturamento] --> F
 T[DimTarifa] --> F
 E --> C[FatoControleCarga]
 D --> C
 M --> C
 E --> X[Fatos temáticas separadas]
 D --> X
 O[DimMesCredito] --> G[FatoMMGDCreditos]
 D --> G
 E --> G
```

Todas as setas representam relações **1 para muitos, filtro único dimensão → fato**. Não há relações diretas entre fatos financeiras. `relacionamentos.csv` enumera as relações individuais e suas condições de ativação.

## Grãos e consultas de carga

| Tabela de destino | Grão contratado / cautela | SQL em sql/modelo |
|---|---|---|
| FatoFaturamento | Empresa, competência, referência, mercado, grupo/subgrupo, tarifa, item/descrição, etapa, CNR e classe original; valores somados nesse conjunto comum | 01_fato_faturamento.sql |
| FatoDesconto | Linhas da projeção agrupada original; não declarar documento como chave única | 02_fato_desconto.sql |
| FatoReativos | Linhas derivadas de documento/cálculo/ordenação, parte da chave omitida pelo legado | 03_fato_reativos.sql |
| FatoUltrapassagem | Mesmo cuidado: chave intermediária mais rica que a saída | 04_fato_ultrapassagem.sql |
| FatoModicidade | Combinação dos atributos originais com valor; não prova grão transacional | 05_fato_modicidade.sql |
| FatoConsumoProprio | Cabeçalho de fatura, após validar unicidade das fotos/operandos | 06_fato_consumo_proprio.sql |
| FatoMMGDCreditos | Empresa + MES_COMPETENCIA + MES + contrato geradora + conta, preservados como campos diferentes | 07_mmgd_creditos_numericos.sql |
| FatoSaldoBloqueado | Fotografia por referência + empresa + contrato + mês legado de origem + conta | 08_saldo_bloqueado_numerico.sql |
| FatoFinanciamentoNota | Empresa + mandante + nota + documento, **chave candidata a validar** | 09_financiamento_notas.sql |
| FatoFinanciamentoCompensacao | Grupos originais da nota/status; não é uma parcela individual | 10_financiamento_compensacao.sql |
| FatoEncargoCovid / FatoEncargoEscassez | Empresa + competência + documento impressão + documento cálculo | 11_encargo_*_por_documento.sql |
| FatoIsencaoReducao | Empresa + competência + documentos + município fiscal; somente redução dos itens | 13_isencao_reducao_por_documento.sql |
| FatoInjetada | Empresa + competência + documentos; itens e ZPGAT agregados separadamente antes do join | 14_injetada_itens_preagregados.sql |
| FatoResumo / FatoRetencao | **Pendente:** schema, grão e campos não conhecidos; não criar relações até mapeá-los | originais/resumo_faturamento.sql e retencao_tributos.sql |
| FatoControleCarga | Empresa + competência + mercado, uma linha por combinação esperada | Nova tabela da ingestão, não contida no ZIP |

O staging original de Livres deve conservar instalação, documentos, fatura e conta para uso específico. A fato comum deliberadamente agrega esses detalhes para ser compatível com Cativos. Descrições divergentes de um mesmo item ainda podem criar grupos distintos; reconciliar antes de criar atributos descritivos únicos.

## Dimensões

- **DimEmpresa:** `EmpresaChave` texto único, seis valores EQTL_XX. Nunca relacionar ESTADO, CCS_RS e EQTL_RS sem normalizar. O M usa uma lista permitida, não texto livre de schema.
- **DimData:** calendário diário contínuo marcado como tabela de datas; fatos mensais gravam competência no dia 01. Usar AnoMes nos visuais e filtros mensais; filtro por dia diferente do primeiro pode esconder fatos mensais.
- **DimDataReferencia:** papel temporal independente, ligado somente a `FatoFaturamento[DataReferencia]` no núcleo. Permite filtrar competência e referência simultaneamente, formando uma interseção deliberada.
- **DimMesCredito:** calendário independente ligado ao campo MES da MMGD. O rótulo não certifica se MES significa geração, alocação ou vencimento; confirmar com o proprietário.
- **DimMercado:** Cativo/Livre, derivado da família de origem. Verificar cobertura de NULL/X e outros marcadores no cabeçalho.
- **DimItemFaturamento:** código único; não relacionar por descrição nem pressupor descrição única entre empresas. Uma descrição universal exige mapa homologado. Se variar por empresa, usar chave substituta de empresa + item e ajustar ambas as pontas.
- **DimTarifa:** código CategoriaTarifa único para o núcleo, após validação de semântica entre empresas. Se códigos tiverem significados distintos, usar chave empresa + código.
- **DimClassePadronizada:** somente depois de criar mapa Empresa + Mercado + ClasseOrigem → ClassePadronizada. Até lá, usar campos originais com mercado explícito. Não criar relacionamento por classe textual.
- **DimContratoGeradora/DimInstalacao:** opcionais, apenas nas fatos que realmente têm os campos. Usar chave substituta com empresa; não tentar filtrar Cativos por instalação.
- **DimNotaFinanciamento:** opcional para navegação entre notas/compensações, com chave validada; não ligar as duas fatos diretamente. Status de compensação não filtra montante de nota sem regra explícita.

Valores nulos de dimensão exigem membro “Não informado” ou tratamento explícito antes da relação. IDs e códigos são texto; não perder zeros iniciais. Tipo de valor monetário e escala precisam de contrato da fonte.

## Controle temporal e de carga

`FatoControleCarga` é requisito para habilitar MoM/YoY protegidos. Deve ser alimentada com o resultado efetivo de cada extração cativo/livre por empresa/mês, inclusive uma extração válida com zero linhas. Campos: EmpresaChave (texto), DataCompetencia (date), Mercado (texto), CargaValida (booleano), ExtracaoEm (datetime). Chave única obrigatória; não marcar como válida apenas porque um XLSX existe. Não preencher essa tabela com valores presumidos.

As relações de DimEmpresa, DimData e DimMercado também filtram essa tabela. O número esperado é empresas selecionadas × meses selecionados × mercados selecionados. As medidas MoM/YoY exigem um mês selecionado e cobertura completa nos dois períodos. Após confirmar cobertura, ausência de linha no recorte é interpretada como zero: mês atual zero contra anterior positivo resulta em -100%; denominador anterior zero fica em branco. Carga incompleta nunca vira zero. YTD exige cobertura de todo o acumulado do ano. A regra de capacidade/cobertura é do núcleo; fatos temáticas precisam de controle próprio antes de comparações equivalentes.

MMGD: substituir a extração inteira ou manter snapshots com chave de extração e usar exatamente um deles. A SQL adaptada assume uma única versão corrente da extração. Não anexar sucessivamente janelas de até 61 meses. Sem homologar MES_COMPETENCIA, não publicar interpretação temporal contábil dos créditos.

Saldo Bloqueado: DataCompetencia é a fotografia solicitada. A medida de quantidade fica em branco para mais de um mês; em linha mensal cada ponto mostra sua fotografia. A SQL numérica remove TRUNC e pode divergir do Excel na fração: mudança deliberada, a reconciliar.

Financiamento: DataCompetencia deriva do mês de DATA_ENTRADA, diferente da competência de faturamento. A visualização deve dizer “mês de entrada”. Não somar moedas distintas; nunca inferir saldo devedor como montante menos compensação sem regra.

## O que as SQL adaptadas corrigem e o que ainda exigem

- Faturamento normaliza o schema e agrega as duas populações pelas dimensões comuns. Conserva os cálculos legados e **herda seus riscos de join**.
- Encargos agregam os itens antes da junção por competência + dois documentos e removem a linha fictícia. Cabeçalho precisa ser único nesse grão.
- Isenção propõe fato apenas da redução; não replica ICMS nem valor da fatura por item. Janela passa a ser explícita. Eventual análise de faturas deve ter uma fato de cabeçalhos separada.
- Injetada soma ZPGAT por documento antes da junção. Essa é uma regra nova proposta; a equivalência contábil ao legado deve ser aprovada.
- Financiamento separa atributos da nota e grupos de compensação. DISTINCT elimina só atributos idênticos; divergências não são resolvidas por MAX arbitrário. Falha na chave candidata **bloqueia a carga**. A consulta de compensações ainda herda o join por número de documento.
- Consumo próprio ainda herda os riscos de fotos/operandos. A cópia SQL normalizada renomeia os dois NUMERO para NUMERO_FATURA e NUMERO_ENDERECO dentro do CTE, evitando nomes duplicados; a projeção final evita dados pessoais no modelo. O legado não foi alterado.
- Resumo/Retenção permanecem em staging até o schema real ser obtido. Não há DAX com nomes de campos inventados.
