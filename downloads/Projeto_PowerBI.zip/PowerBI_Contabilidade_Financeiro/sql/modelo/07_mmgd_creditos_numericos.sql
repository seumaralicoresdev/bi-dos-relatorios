-- RASCUNHO: preserva ambas as colunas de mês; não declara saldo ou expiração.
-- Janela de MES inclusiva, até 61 meses distintos. Não anexar extrações sobrepostas.
SELECT '{EMP}' AS "EmpresaChave",
       TRY_TO_DATE(TO_VARCHAR(A.MES_COMPETENCIA)||'01','YYYYMMDD') AS "DataCompetencia",
       TRY_TO_DATE(TO_VARCHAR(A.MES)||'01','YYYYMMDD') AS "DataMesCredito",
       TO_VARCHAR(A.CONTRATO_GERADORA) AS "ContratoGeradora",
       COALESCE(TO_VARCHAR(A.CONTA_CONTRATO_GERADORA),'SEM_CONTA') AS "ContaContratoGeradora",
       SUM(A.KWH) AS "CreditoKWh"
FROM SB_FATURAMENTO.{SCHEMA}.BASE_MMGD_CREDITOS A
WHERE A.MES BETWEEN TO_CHAR(ADD_MONTHS(TO_DATE('{MES}'||'01','YYYYMMDD'),-60),'YYYYMM') AND '{MES}'
GROUP BY A.MES_COMPETENCIA, A.MES, A.CONTRATO_GERADORA, A.CONTA_CONTRATO_GERADORA
HAVING SUM(A.KWH) <> 0
