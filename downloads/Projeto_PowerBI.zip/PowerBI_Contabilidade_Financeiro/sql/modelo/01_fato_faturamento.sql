-- RASCUNHO: uma distribuidora/competência; renderizar placeholders antes de executar.
-- Resultados dos legados, sem soma de relatórios acessórios sobrepostos.
WITH CATIVO AS (
SELECT 
    '{EMP}' as  empresa, mes_referencia, a.mes_competencia, nvl(cl2.codigo_classe,cl.codigo_classe) AS codigo_classe, 
nvl(cl2.classe_principal,CL.CLASSE_PRINCIPAL) AS classe_principal, NVL(DECODE(B.SUBCLASSE,' ',NULL,B.SUBCLASSE),CAD.CODIGO_SUBCLASSE) AS subclasse,
nvl(cl2.subclasse_descricao,CL.SUBCLASSE_DESCRICAO) AS SUBCLASSE_DESCRICAO, cnr, substr(NVL(categoria_tarifa,TIPO_TARIFA),1,1) AS grupo,
substr(NVL(categoria_tarifa,TIPO_TARIFA),1,2) as sub_grupo_tensao, NVL(categoria_tarifa,TIPO_TARIFA) as cod_categoria_tarifa, b.cliente_livre, a.item_documento, TEXT30 AS descricao_item_documento, etapa,
SUM(valor_faturado) AS valor_faturado,
SUM(a.consumo_faturado) AS consumo_faturado,
SUM(montante_cofins) AS montante_cofins,
SUM(montante_icms) AS montante_icms,
SUM(montante_pis) AS montante_pis,
SUM(valor_faturado) - (SUM(montante_cofins)+SUM(montante_icms)+SUM(montante_pis)) as valor_sem_imposto
  from 
       (
        select mes_competencia,  documento_calculo,  documento_impressao,  item_ordenacao,
 				max(item_documento)as item_documento,
 				sum(consumo)consumo_faturado,
 				sum(receita) valor_faturado,
 				max(NVL(icms,0)) montante_icms,
 				max(NVL(pis,0)) montante_pis ,
				max(NVL(cofins,0)) montante_cofins
          from 
              (
               select mes_COMPETENCIA,  documento_calculo, documento_impressao, case when item_documento <> 'SUBT' then item_documento end as item_documento,
		               nvl(item_ordenacao, item_documento) as item_ordenacao, consumo,
		               sum(receita) as receita,
		               (SUM(case when tipo_imposto = 'MW2' THEN RECEITA END)) ICMS,
		               (SUM(case when tipo_imposto = 'PIS' THEN RECEITA END)) PIS,
		               (SUM(case when tipo_imposto = 'COF' THEN RECEITA END)) COFINS
                 from EQTLINFO_PRD.{PRD_SCHEMA}.ITENS_FATURAMENTO
                where 1=1
                  AND mes_competencia = '{MES}'
                  and documento_impressao in (
                                           select b.documento_impressao
                                             from EQTLINFO_PRD.{PRD_SCHEMA}.FATURAMENTO B
                                            where 1=1
                                              AND b.mes_competencia = '{MES}'
                                              AND CLIENTE_LIVRE IS NULL
                                          )
                  and flag in ('C', 'R')
                group by ALL
                )
		   group by  ALL
      )a  inner join EQTLINFO_PRD.{PRD_SCHEMA}.FATURAMENTO b on  a.mes_competencia = b.mes_competencia
				                                     and a.documento_impressao = b.documento_impressao
				                                     and a.documento_calculo = b.documento_calculo 
    left join EQTLINFO_RAW.{RAW_SCHEMA}.TE835T c on a.item_documento = C.BELZART AND SPRAS = 'P' and c.mandt in ('401','402','403','404','405','406')
   LEFT JOIN EQTLINFO_PRD.{PRD_SCHEMA}.TAB_CADASTRO CAD ON CAD.INSTALACAO = B.INSTALACAO
   LEFT JOIN SB_FATURAMENTO.EQTL_RS.DESCRICAO_CLASSE_SUBCLASSE CL ON CL.SUBCLASSE = NVL(DECODE(B.SUBCLASSE,' ',NULL,B.SUBCLASSE),CAD.CODIGO_SUBCLASSE)
   LEFT JOIN EQTLINFO_PRD.{PRD_SCHEMA}.TAB_DESCRICAO_CLASSE CL2 ON CL2.SUBCLASSE = NVL(DECODE(B.SUBCLASSE,' ',NULL,B.SUBCLASSE),CAD.CODIGO_SUBCLASSE)
GROUP BY all
), LIVRE AS (
SELECT EMPRESA,
       INSTALACAO,
       DOCUMENTO_IMPRESSAO,
       NUMERO_FATURA,
       CONTA_CONTRATO,
       MES_REFERENCIA,
       MES_COMPETENCIA,
       CLASSE,
       CNR,
       GRUPO,
       SUB_GRUPO_TENSAO,
       COD_CATEGORIA_TARIFA,
       CLIENTE_LIVRE,
       ITEM_DOCUMENTO,
       DESCRICAO_ITEM_DOCUMENTO,
       ETAPA,
       VALOR_FATURADO,
       CONSUMO_FATURADO,
       MONTANTE_COFINS,
       MONTANTE_ICMS,
       MONTANTE_PIS,
       VALOR_sem_imposto
FROM (
       SELECT A.empresa, A.instalacao, documento_impressao, numero_fatura, A.conta_contrato, mes_referencia, mes_competencia, nvl(classe,substr(nvl(CL2.classe_principal,cl.classe_principal),1,2)) AS classe,
       cnr, nvl(grupo,grupo_tensao) AS grupo, substr(nvl(cod_categoria_tarifa,tipo_tarifa),1,2) AS sub_grupo_tensao, ETAPA, nvl(cod_categoria_tarifa,tipo_tarifa) AS cod_categoria_tarifa,
       A.cliente_livre, max(a.item_documento) as item_documento, substr(max(a.item_documento||'  '||TEXT30),7,100) AS descricao_item_documento, documento_calculo, item_ordenacao,
			 nvl(sum(consumo),0) AS consumo_faturado,
			 nvl(sum(receita),0) valor_faturado,
			 nvl(max(icms),0) montante_icms,
			 nvl(max(pis),0) montante_pis,
			 nvl(max(cofins),0) montante_cofins,
			 nvl(sum(receita),0)-(nvl(max(icms),0)+nvl(max(pis),0)+nvl(max(cofins),0)) AS VALOR_sem_imposto
 		 FROM 
 			 (
				select '{EMP}' as empresa,
			      b.instalacao,
			      a.documento_impressao,
			      b.fatura as numero_fatura,
			      b.conta_contrato,
			      b.mes_referencia,
			      a.mes_competencia,
			      substr(b.subclasse,1,2) as classe,
			      b.subclasse,
					b.cnr,
					b.grupo,
					substr(b.categoria_tarifa,1,2) as sub_grupo_tensao,
					b.categoria_tarifa as cod_categoria_tarifa,
					b.cliente_livre,
					b.etapa,
					consumo,
					case when item_documento <> 'SUBT' then item_documento end as item_documento,
					a.documento_calculo,
			       nvl(item_ordenacao, item_documento) as item_ordenacao,
			       sum(receita) as receita,
			       (SUM(case when tipo_imposto = 'MW2' THEN RECEITA END)) ICMS,
			       (SUM(case when tipo_imposto = 'PIS' THEN RECEITA END)) PIS,
			       (SUM(case when tipo_imposto = 'COF' THEN RECEITA END)) COFINS
			        from EQTLINFO_PRD.{PRD_SCHEMA}.FATURAMENTO b
			             inner join EQTLINFO_PRD.{PRD_SCHEMA}.ITENS_FATURAMENTO A on a.mes_competencia = b.mes_competencia
			                     											and a.documento_impressao = b.documento_impressao
										                                     and a.documento_calculo = b.documento_calculo
										                                     and flag in ('C', 'R')
			       where 1=1
			         AND b.MES_COMPETENCIA = '{MES}'
			         AND cliente_livre = 'X'
			       group by ALL
			      ) a 
  left join EQTLINFO_RAW.{RAW_SCHEMA}.TE835T c on a.item_documento = c.belzart AND c.spras = 'P' and c.mandt in ('401','402','403','404','405','406')
    LEFT JOIN EQTLINFO_PRD.{PRD_SCHEMA}.TAB_CADASTRO CAD ON CAD.INSTALACAO = a.INSTALACAO
   LEFT JOIN SB_FATURAMENTO.EQTL_RS.DESCRICAO_CLASSE_SUBCLASSE CL ON CL.SUBCLASSE = NVL(DECODE(A.SUBCLASSE,' ',NULL,A.SUBCLASSE),CAD.CODIGO_SUBCLASSE)
   LEFT JOIN EQTLINFO_PRD.{PRD_SCHEMA}.TAB_DESCRICAO_CLASSE CL2 ON CL2.SUBCLASSE = NVL(DECODE(A.SUBCLASSE,' ',NULL,A.SUBCLASSE),CAD.CODIGO_SUBCLASSE)
		GROUP BY ALL
		)
		GROUP BY ALL
), UNIFICADO AS (
SELECT TO_VARCHAR(EMPRESA) AS "EmpresaChave",
       TRY_TO_DATE(TO_VARCHAR(MES_COMPETENCIA)||'01','YYYYMMDD') AS "DataCompetencia",
       TRY_TO_DATE(TO_VARCHAR(MES_REFERENCIA)||'01','YYYYMMDD') AS "DataReferencia",
       'Cativo' AS "Mercado", TO_VARCHAR(GRUPO) AS "Grupo",
       TO_VARCHAR(SUB_GRUPO_TENSAO) AS "SubGrupoTensao",
       TO_VARCHAR(COD_CATEGORIA_TARIFA) AS "CategoriaTarifa",
       TO_VARCHAR(ITEM_DOCUMENTO) AS "ItemDocumento",
       TO_VARCHAR(DESCRICAO_ITEM_DOCUMENTO) AS "DescricaoItemDocumento",
       TO_VARCHAR(ETAPA) AS "Etapa", TO_VARCHAR(CNR) AS "CNR",
       TO_VARCHAR(CLASSE_PRINCIPAL) AS "ClasseOrigem",
       VALOR_FATURADO AS "ValorFaturado", CONSUMO_FATURADO AS "ConsumoOrigem",
       MONTANTE_COFINS AS "COFINS", MONTANTE_ICMS AS "ICMS", MONTANTE_PIS AS "PIS",
       VALOR_SEM_IMPOSTO AS "ValorSemImposto"
FROM CATIVO
UNION ALL
SELECT TO_VARCHAR(EMPRESA), TRY_TO_DATE(TO_VARCHAR(MES_COMPETENCIA)||'01','YYYYMMDD'),
       TRY_TO_DATE(TO_VARCHAR(MES_REFERENCIA)||'01','YYYYMMDD'),
       'Livre', TO_VARCHAR(GRUPO), TO_VARCHAR(SUB_GRUPO_TENSAO),
       TO_VARCHAR(COD_CATEGORIA_TARIFA), TO_VARCHAR(ITEM_DOCUMENTO),
       TO_VARCHAR(DESCRICAO_ITEM_DOCUMENTO), TO_VARCHAR(ETAPA), TO_VARCHAR(CNR),
       TO_VARCHAR(CLASSE), VALOR_FATURADO, CONSUMO_FATURADO,
       MONTANTE_COFINS, MONTANTE_ICMS, MONTANTE_PIS, VALOR_SEM_IMPOSTO
FROM LIVRE
)
SELECT "EmpresaChave", "DataCompetencia", "DataReferencia", "Mercado", "Grupo", "SubGrupoTensao",
       "CategoriaTarifa", "ItemDocumento", "DescricaoItemDocumento", "Etapa", "CNR", "ClasseOrigem",
       SUM("ValorFaturado") AS "ValorFaturado", SUM("ConsumoOrigem") AS "ConsumoOrigem",
       SUM("COFINS") AS "COFINS", SUM("ICMS") AS "ICMS", SUM("PIS") AS "PIS",
       SUM("ValorSemImposto") AS "ValorSemImposto"
FROM UNIFICADO GROUP BY ALL
