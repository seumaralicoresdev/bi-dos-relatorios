-- RASCUNHO de redução: não soma ICMS/VALOR_FATURA do cabeçalho repetido por item.
-- A moeda e o significado contábil do sinal continuam pendentes de confirmação.
-- Intervalo explícito substitui a janela móvel de três meses do original.
SELECT '{EMP}' AS "EmpresaChave",
       TO_DATE(MES_COMPETENCIA||'01','YYYYMMDD') AS "DataCompetencia",
       TO_VARCHAR(DOCUMENTO_IMPRESSAO) AS "DocumentoImpressao",
       TO_VARCHAR(DOCUMENTO_CALCULO) AS "DocumentoCalculo",
       SUBSTR(DOMICILIO_FISCAL,4,7) AS "MunicipioOrigem",
       SUM(RECEITA) AS "ReducaoAssinada"
FROM EQTLINFO_PRD.{SCHEMA}.ITENS_FATURAMENTO
WHERE OPERACAO='0153' AND MES_COMPETENCIA BETWEEN '{MES_INICIO}' AND '{MES_FIM}'
GROUP BY MES_COMPETENCIA,DOCUMENTO_IMPRESSAO,DOCUMENTO_CALCULO,SUBSTR(DOMICILIO_FISCAL,4,7)
