-- RELATÓRIO EXCEDENTE REATIVO
SELECT  
    '{EMP}' AS empresa, 
    b.instalacao, 
    a.documento_impressao, 
    b.mes_referencia,
    a.mes_competencia,
    SUBSTR(NVL(DECODE(b.subclasse, ' ', NULL, b.subclasse), cad.codigo_subclasse), 1, 2) AS classe, 
    NVL(DECODE(b.subclasse, ' ', NULL, b.subclasse), cad.codigo_subclasse) AS subclasse, 
    SUBSTR(NVL(DECODE(b.categoria_tarifa, ' ', NULL, b.categoria_tarifa), cad.tipo_tarifa), 1, 1) AS grupo,
    SUBSTR(NVL(DECODE(b.categoria_tarifa, ' ', NULL, b.categoria_tarifa), cad.tipo_tarifa), 1, 2) AS sub_grupo_tensao,
    a.item_ordenacao, 
    a.item_documento, 
    c.item_documento_descricao AS descricao_item_documento,
    a.valor_faturado,
    a.valor_faturado - (a.montante_cofins + a.montante_icms + a.montante_pis) AS valor_sem_imposto
FROM (
    SELECT 
        mes_competencia, 
        documento_calculo, 
        documento_impressao, 
        item_ordenacao,
        MAX(item_documento) AS item_documento,  
        SUM(consumo) AS consumo_faturado, 
        SUM(receita) AS valor_faturado,
        MAX(icms) AS montante_icms, 
        MAX(pis) AS montante_pis,
        MAX(cofins) AS montante_cofins
    FROM (
        SELECT 
            mes_competencia, 
            documento_calculo, 
            documento_impressao, 
            CASE WHEN item_documento <> 'SUBT' THEN item_documento END AS item_documento, 
            NVL(item_ordenacao, item_documento) AS item_ordenacao, 
            consumo,
            SUM(receita) AS receita,
            SUM(CASE WHEN tipo_imposto = 'MW2' THEN receita ELSE 0 END) AS icms,
            SUM(CASE WHEN tipo_imposto = 'PIS' THEN receita ELSE 0 END) AS pis,
            SUM(CASE WHEN tipo_imposto = 'COF' THEN receita ELSE 0 END) AS cofins
        FROM EQTLINFO_PRD.{SCHEMA}.itens_faturamento
        WHERE item_ordenacao IN (
                'ZCRF','ZCRP','ZCRR','ZCRE','ZDRE','ZDRF','ZDRP','YCRE',
                'YCRF','YCRI','YCRP','YCRR','YDRE','YDRF','YDRP','YPD1',
                'YPD2','YPD3','YTR1','YTR2','YTR3','YTR4','YTR5','Z565',
                'Z566','Z567','ZCRE','ZCRF','ZCRI','ZCRP','ZCRR','ZDRE',
                'ZDRF','ZDRP','ZPD1','ZPD2','ZPD3','ZTR1','ZTR2','ZTR3',
                'ZTR4','ZTR5','ZCFI','ZCNI'
            ) 
            AND flag IN ('C', 'R')
            AND mes_competencia = '{MES}'
            AND documento_impressao <> '500000002466' -- <-- 1. Filtrado na origem dos dados
        GROUP BY 
            consumo, 
            mes_competencia, 
            CASE WHEN item_documento <> 'SUBT' THEN item_documento END, 
            NVL(item_ordenacao, item_documento), 
            documento_calculo, 
            documento_impressao
    ) zxc 
    GROUP BY   
        mes_competencia, 
        documento_calculo,      
        documento_impressao,      
        item_ordenacao
) a
INNER JOIN EQTLINFO_PRD.{SCHEMA}.faturamento b 
    ON a.mes_competencia = b.mes_competencia 
   AND a.documento_impressao = b.documento_impressao 
   AND a.documento_calculo = b.documento_calculo 
LEFT JOIN EQTLINFO_PRD.{SCHEMA}.tab_item_documento c 
    ON a.item_documento = c.item_documento
INNER JOIN EQTLINFO_PRD.{SCHEMA}.tab_cadastro cad 
    ON cad.instalacao = b.instalacao
WHERE b.documento_impressao <> '500000002466' -- <-- 2. Garantia na junção final
