SELECT 
    '{EMP}' as empresa, 
    mes_referencia, 
    a.mes_competencia, 
    nvl(cl2.codigo_classe,cl.codigo_classe) AS codigo_classe, 
    nvl(cl2.classe_principal,CL.CLASSE_PRINCIPAL) AS classe_principal, 
    NVL(DECODE(B.SUBCLASSE,' ',NULL,B.SUBCLASSE),CAD.CODIGO_SUBCLASSE) AS subclasse, 
    nvl(cl2.subclasse_descricao,CL.SUBCLASSE_DESCRICAO) AS SUBCLASSE_DESCRICAO, 
    cnr, 
    substr(NVL(categoria_tarifa,TIPO_TARIFA),1,1) AS grupo, 
    substr(NVL(categoria_tarifa,TIPO_TARIFA),1,2) as sub_grupo_tensao, 
    NVL(categoria_tarifa,TIPO_TARIFA) as cod_categoria_tarifa, 
    b.cliente_livre, 
    a.item_documento, 
    TEXT30 AS descricao_item_documento, 
    etapa, 
    SUM(valor_faturado) AS valor_faturado, 
    SUM(a.consumo_faturado) AS consumo_faturado, 
    SUM(montante_cofins) AS montante_cofins, 
    SUM(montante_icms) AS montante_icms, 
    SUM(montante_pis) AS montante_pis, 
    SUM(valor_faturado) - (SUM(montante_cofins)+SUM(montante_icms)+SUM(montante_pis)) as valor_sem_imposto 
FROM ( 
    SELECT 
        mes_competencia, 
        documento_calculo, 
        documento_impressao, 
        item_ordenacao, 
        max(item_documento)as item_documento, 
        sum(consumo)consumo_faturado, 
        sum(receita) valor_faturado, 
        max(NVL(icms,0)) montante_icms, 
        max(NVL(pis,0)) montante_pis , 
        max(NVL(cofins,0)) montante_cofins 
    FROM ( 
        SELECT 
            mes_COMPETENCIA, 
            documento_calculo, 
            documento_impressao, 
            case when item_documento <> 'SUBT' then item_documento end as item_documento, 
            nvl(item_ordenacao, item_documento) as item_ordenacao, 
            consumo, 
            sum(receita) as receita, 
            (SUM(case when tipo_imposto = 'MW2' THEN RECEITA END)) ICMS, 
            (SUM(case when tipo_imposto = 'PIS' THEN RECEITA END)) PIS, 
            (SUM(case when tipo_imposto = 'COF' THEN RECEITA END)) COFINS 
        FROM EQTLINFO_PRD.{PRD_SCHEMA}.ITENS_FATURAMENTO 
        WHERE 1=1 
          AND mes_competencia = '{MES}' 
          AND documento_impressao in ( 
              SELECT b.documento_impressao 
              FROM EQTLINFO_PRD.{PRD_SCHEMA}.FATURAMENTO B 
              WHERE 1=1 
                AND b.mes_competencia = '{MES}' 
                AND CLIENTE_LIVRE IS NULL 
                AND b.documento_impressao <> '500000002466' -- <-- 1. Adicionado aqui
          ) 
          AND flag in ('C', 'R') 
        GROUP BY ALL 
    ) 
    GROUP BY ALL 
) a 
INNER JOIN EQTLINFO_PRD.{PRD_SCHEMA}.FATURAMENTO b 
  ON a.mes_competencia = b.mes_competencia 
  AND a.documento_impressao = b.documento_impressao 
  AND a.documento_calculo = b.documento_calculo 
LEFT JOIN EQTLINFO_RAW.{RAW_SCHEMA}.TE835T c 
  ON a.item_documento = C.BELZART 
  AND SPRAS = 'P' 
  AND c.mandt in ('401','402','403','404','405','406') 
LEFT JOIN EQTLINFO_PRD.{PRD_SCHEMA}.TAB_CADASTRO CAD 
  ON CAD.INSTALACAO = B.INSTALACAO 
LEFT JOIN SB_FATURAMENTO.EQTL_RS.DESCRICAO_CLASSE_SUBCLASSE CL 
  ON CL.SUBCLASSE = NVL(DECODE(B.SUBCLASSE,' ',NULL,B.SUBCLASSE),CAD.CODIGO_SUBCLASSE) 
LEFT JOIN EQTLINFO_PRD.{PRD_SCHEMA}.TAB_DESCRICAO_CLASSE CL2 
  ON CL2.SUBCLASSE = NVL(DECODE(B.SUBCLASSE,' ',NULL,B.SUBCLASSE),CAD.CODIGO_SUBCLASSE) 
WHERE b.documento_impressao <> '500000002466' -- <-- 2. Adicionado aqui para garantir o filtro na junção final
GROUP BY all
