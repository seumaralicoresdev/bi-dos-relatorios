# Inventário estático das consultas legadas

Análise somente leitura de `origem/relatorios/legado`, em 05/11/2026. Nenhum módulo legado foi importado/executado e não houve conexão ao Snowflake. Grãos abaixo são os grãos expressos pelo SELECT/GROUP BY, não garantias de unicidade das fontes. Colunas não projetadas não estão disponíveis para DAX sobre os arquivos de saída. Valores reais, tipos de banco, moedas, cardinalidades e totais precisam de validação com dados.

## Cobertura e fontes

O catálogo contém 16 famílias: desconto tarifário, clientes cativos, clientes livres, modicidade tarifária, saldo bloqueado, MMGD, reativos excedentes, resumo faturamento, ultrapassagem de demanda, escassez hídrica, Covid, ICMS injetada, isenção ICMS TUSD, financiamento padrão, consumo próprio e retenção de tributos. Evidência: `origem/app/report_registry.py:50`.

Distribuidoras previstas no aplicativo: EQTL_MA, EQTL_PA, EQTL_PI, EQTL_AL, EQTL_AP, EQTL_RS. O esquema PRD é `EQTL_XX`; RAW é `CCS_XX`. Evidência: `origem/app/report_registry.py:10` e `:15`.

Objetos de origem observados (normalizados os placeholders SCHEMA/PRD_SCHEMA/RAW_SCHEMA):

| Banco | Objetos |
|---|---|
| EQTLINFO_PRD.{EQTL_UF} | ITENS_FATURAMENTO; FATURAMENTO; TAB_CADASTRO; SIGLA_MUNICIPIOS; TAB_CONTRATO; TAB_DESCRICAO_CLASSE; TAB_PARCEIRO_NEGOCIO; FOTO_CADASTRO; TAB_OPERANDOS_MEDICAO; FINPAD_NOTAS; ITENS_FINANCEIRO; TAB_ITEM_DOCUMENTO |
| EQTLINFO_RAW.{CCS_UF} | EENRGY_CR_BR; TE835T |
| SB_FATURAMENTO.{EQTL_UF} | BASE_IMPOSTO_RETIDO; BASE_MMGD_CREDITOS; BASE_MODIC_TAR_NOVO; RESUMO_FAT_TRIBUTOS |
| SB_FATURAMENTO.EQTL_RS, fixo | DESCRICAO_CLASSE_SUBCLASSE, usado como fallback inclusive nos SQL principais de cativos e livres |

São 19 objetos normalizados, desconsiderando a repetição por distribuidora. Os caminhos/linhas de cada família abaixo identificam suas referências FROM/JOIN.

## Inventário por família

### 1. Desconto tarifário

- SQL: `origem/relatorios/legado/RELATORIOS DESCONTO TARIFÁRIO/script_relat_desc_tarif.py:56`.
- Fontes: ITENS_FATURAMENTO e FATURAMENTO; junção por DOCUMENTO_IMPRESSAO + DOCUMENTO_CALCULO (:78-79).
- Saída: EMPRESA, MES_COMPETENCIA, ITEM_ORDENACAO, ITEM_DOCUMENTO, SUB_OPERACAO, CHAVE_RECONCILIACAO, INSTALACAO, CONTA_CONTRATO, CONTRATO, FATURA, CATEGORIA_TARIFA, SUBCLASSE, RECEITA, DOCUMENTO_IMPRESSAO, GD (:57-60).
- Grão: combinação de todos os atributos acima, agregando RECEITA. LINHA participa de agrupamento interno mas é suprimida na saída. DOCUMENTO_CALCULO não é projetado.
- Filtros: competência exata `{MES}`; lista de ITEM_ORDENACAO e prefixo `ZL%`; exclui ITEM_DOCUMENTO=ZBTLBR, receita zero e SUB_OPERACAO 0053/0063; HAVING receita diferente de zero (:81-91).
- Regras: SUBT vira ITEM_ORDENACAO; SUB_OPERACAO é escolhida por MAX de janela por documento/ordenação; GD='X' se ITEM_ORDENACAO diferente de ZBTL (:60,66-67). Preservar receita com sinal. GD é regra deste relatório, não cadastro universal de geração distribuída.
- Risco: receita já está em cativos/livres/resumo; somá-la a essas famílias gera dupla contagem. Unicidade dos dois documentos em FATURAMENTO não é provada.

### 2. Clientes cativos

- SQL: `origem/relatorios/legado/RELATÓRIO CLIENTES CATIVOS/script_relat_client_cat.py:51`.
- Fontes: ITENS_FATURAMENTO, FATURAMENTO, RAW.TE835T, TAB_CADASTRO, SB_FATURAMENTO.EQTL_RS.DESCRICAO_CLASSE_SUBCLASSE fixo, TAB_DESCRICAO_CLASSE (:80,85,94-100).
- Saída: EMPRESA, MES_REFERENCIA, MES_COMPETENCIA, CODIGO_CLASSE, CLASSE_PRINCIPAL, SUBCLASSE, SUBCLASSE_DESCRICAO, CNR, GRUPO, SUB_GRUPO_TENSAO, COD_CATEGORIA_TARIFA, CLIENTE_LIVRE, ITEM_DOCUMENTO, DESCRICAO_ITEM_DOCUMENTO, ETAPA, VALOR_FATURADO, CONSUMO_FATURADO, MONTANTE_COFINS, MONTANTE_ICMS, MONTANTE_PIS, VALOR_SEM_IMPOSTO (:53-62).
- Grão: agregado por todos os atributos dimensionais listados; instalação, fatura, documento de impressão, documento de cálculo e conta contrato **não** aparecem na saída. Não é base de clientes individual.
- Filtros: competência exata em itens e faturamento; CLIENTE_LIVRE IS NULL; FLAG C/R; TE835T idioma P e mandantes 401..406 (:82-90,97).
- Tributos: extraídos de RECEITA com TIPO_IMPOSTO MW2/PIS/COF; no estágio por ordenação usa MAX por tributo, depois SUM na saída (:69-79). Líquido = faturado - (COFINS + ICMS + PIS).
- Riscos: cadastro por instalação sem vigência/conta e descrições sem deduplicação podem multiplicar a receita. TE835T permite seis mandantes sem vinculá-los à empresa, exigindo testar unicidade de BELZART+SPRAS após filtro. COUNTROWS não mede clientes/UC/faturas.

### 3. Clientes livres

- SQL: `origem/relatorios/legado/RELATÓRIOS CLIENTES LIVRES/script_clientes_livres.py:42`.
- Fontes e descrições: mesmas de cativos; junção itens/cabeçalho por competência + documento impressão + documento cálculo (:100-113).
- Saída: EMPRESA, INSTALACAO, DOCUMENTO_IMPRESSAO, NUMERO_FATURA, CONTA_CONTRATO, MES_REFERENCIA, MES_COMPETENCIA, CLASSE, CNR, GRUPO, SUB_GRUPO_TENSAO, COD_CATEGORIA_TARIFA, CLIENTE_LIVRE, ITEM_DOCUMENTO, DESCRICAO_ITEM_DOCUMENTO, ETAPA, VALOR_FATURADO, CONSUMO_FATURADO, MONTANTE_COFINS, MONTANTE_ICMS, MONTANTE_PIS, VALOR_SEM_IMPOSTO (:43-64).
- Grão interno: documento cálculo + documento impressão + item ordenação + atributos da fatura. A projeção externa suprime DOCUMENTO_CALCULO e ITEM_ORDENACAO e aplica GROUP BY ALL, podendo ocultar combinações distintas se os demais valores coincidirem (:66-74,114-116).
- Filtros: competência exata, CLIENTE_LIVRE='X', FLAG C/R, idioma/mandantes como cativos (:104-110).
- Medidas: somas de consumo/receita e MAX de tributos no nível intermediário; líquido já vem calculado. Riscos de junções de descrição/cadastro idênticos a cativos. Distinctcount instalação só é defensável após conferir documentos e filtros e incluir empresa na chave.

### 4. Modicidade tarifária

- SQL: `origem/relatorios/legado/RELATÓRIOS MODICIDADE TARIFÁRIA/script_relat_mod_tar.py:43`.
- Fonte: SB_FATURAMENTO.{SCHEMA}.BASE_MODIC_TAR_NOVO (:51).
- Saída: EMPRESA, REFERENCIA, MES_LANCAMENTO, CATEGORIA_DOC_SUBSTITUTO, STATUS_DOC_SUBST, OPERACAO, SUB_OPERACAO, DESCRICAO, ITEM_ESTATISTICO, CLASSE, CONTA_CONTRATO, NUMERO_DOCUMENTO, BLOQUEIO, VALOR (:48-50).
- Grão: todos os campos da projeção exceto CLASSE; CLASSE=MAX(CLASSE). VALOR é campo de agrupamento, **não** SUM(VALOR). Duplicatas idênticas da fonte podem ser colapsadas pelo GROUP BY; valores/classes divergentes exigem regra de negócio.
- Filtro: REFERENCIA='{MES}' (:52). REFERENCIA e MES_LANCAMENTO são papéis temporais diferentes.

### 5. Saldo bloqueado

- SQL: `origem/relatorios/legado/RELATORIO SALDO BLOQUEADO/script_relat_saldo_bloq.py:47`.
- Fontes: RAW.EENRGY_CR_BR, PRD.TAB_CONTRATO; junção CONTRATO=CONTRATO_GERACAO (:56,62-63).
- Saída: EMPRESA, REFERENCIA, CONTRATO_GERACAO, QUANTIDADE, MES_ORIGEM_CREDITO, CONTA_CONTRATO (:48-55).
- Grão: empresa + referência de extração + contrato geração + mês origem crédito; a associação com conta ocorre depois da agregação e pode gerar várias linhas por contrato.
- Filtros: RUSE_ENDDATE anterior ao primeiro dia da referência menos 60 meses; CREATEDDATE anterior ao dia 6 do mês seguinte; QUANTIDADE diferente de zero (:58-64). Isso é a regra observada; não está demonstrado que RUSE_ENDDATE represente data de geração do crédito.
- QUANTIDADE=TO_CHAR(TRUNC(SUM(QUANT))) (:54): texto com perda de frações; unidade não declarada no SQL. Referência é fotografia de saldo: não somar snapshots de meses diferentes para saldo atual. A junção TAB_CONTRATO não deduplica contratos; pode repetir todo o saldo.

### 6. MMGD

- Consolidado: `origem/relatorios/legado/RELATÓRIOS MMGD/mmgd.py:44`; fonte SB_FATURAMENTO.{SCHEMA}.BASE_MMGD_CREDITOS (:49); saída EMPRESA, MES, KWH=SUM(KWH), por empresa/mês (:45-54).
- Janela: MES da referência menos 60 meses até a referência inclusiva (:50-52), potencialmente 61 meses distintos, sem filtrar MES_COMPETENCIA.
- Detalhado: `origem/relatorios/legado/RELATÓRIOS MMGD/base_mmgd.py:46`; mesma fonte; saída MES_COMPETENCIA, MES, KWH, CONTRATO_GERADORA, CONTA_CONTRATO_GERADORA; grão competência + mês crédito + contrato + conta (:48-61); HAVING soma KWH diferente de zero (:62). Empresa é identificada pelo arquivo e precisa ser adicionada ao combinar arquivos.
- KWH detalhado é formatado como texto com vírgula em SQL (:50). Preferir número decimal nativo no modelo; se consumir CSV existente, converter com localidade adequada antes de medidas. Não somar detalhado e consolidado.
- `mmgd.py` não chama `base_mmgd.py` no main, mas o desktop executa a base auxiliar depois de produzir o consolidado: `origem/app/report_runner.py:40-47`. O detalhe é CSV por empresa na pasta `base_mmgd_{competencia}` (`base_mmgd.py:130`); a lista principal de caminhos produzidos contabiliza os XLSX, não os CSV auxiliares (`report_runner.py:101-117`).
- Meses sobrepostos em extrações sucessivas: incluir referência de extração/snapshot e escolher uma versão. Appendar todos os arquivos de janelas móveis duplica períodos.
- RS usa fonte/grão diferentes; ver seção de variantes.

### 7. Reativos excedentes

- SQL: `origem/relatorios/legado/RELATÓRIOS REATIVOS EXCEDENTE/script_relat_reativo.py:43`.
- Fontes: ITENS_FATURAMENTO, FATURAMENTO, TAB_ITEM_DOCUMENTO, TAB_CADASTRO (:84,109-116).
- Saída: EMPRESA, INSTALACAO, DOCUMENTO_IMPRESSAO, MES_REFERENCIA, MES_COMPETENCIA, CLASSE, SUBCLASSE, GRUPO, SUB_GRUPO_TENSAO, ITEM_ORDENACAO, ITEM_DOCUMENTO, DESCRICAO_ITEM_DOCUMENTO, VALOR_FATURADO, VALOR_SEM_IMPOSTO (:45-59).
- Grão interno: competência + documento cálculo + documento impressão + item ordenação (:103-107). DOCUMENTO_CALCULO não é projetado; consumo/tributos calculados internamente também não são projetados. Tributos individuais não estão disponíveis para DAX a partir da saída.
- Filtros: lista explícita de 44 entradas de códigos de ordenação, 37 distintos; FLAG C/R; competência exata (:85-94). Código repetido em IN não duplica linha.
- Tributos: SUM por tipo no estágio interno e SUM no seguinte (:69-83), diferente do MAX utilizado em outras famílias/variante RS.
- Cadastro usa INNER JOIN (:115), podendo remover faturas sem cadastro e multiplicar quando houver várias linhas por instalação; descrição usa LEFT JOIN por item sem deduplicação.

### 8. Resumo faturamento

- SQL: `origem/relatorios/legado/Resumo_Faturamento/script_resum_fat.py:43`.
- Fonte: SB_FATURAMENTO.{SCHEMA}.RESUMO_FAT_TRIBUTOS (:47).
- Saída: literal EMPRESA + A.*; só MES_COMPETENCIA e CLASSE são demonstrados pelos filtros (:45-49). Demais colunas, medidas, unidades, chaves e grão não podem ser determinados com segurança pelo código.
- Filtros: CLASSE IS NOT NULL e competência exata. Se a fonte já tiver EMPRESA, literal + A.* pode gerar nomes duplicados; verificar esquema. Usar para conciliação apenas após confirmar cobertura e definição dos valores.

### 9. Ultrapassagem de demanda

- SQL ativo no catálogo: `origem/relatorios/legado/RELATÓRIOS ULTRAPASSAGEM DE DEMANDA/script_ultrp_dem_mudado.py:44`.
- Fontes: ITENS_FATURAMENTO, FATURAMENTO, TAB_ITEM_DOCUMENTO, TAB_CADASTRO (:83,105-112).
- Saída: EMPRESA, INSTALACAO, DOCUMENTO_IMPRESSAO, MES_REFERENCIA, MES_COMPETENCIA, CLASSE, SUBCLASSE, GRUPO, SUB_GRUPO_TENSAO, ITEM_DOCUMENTO, DESCRICAO_ITEM_DOCUMENTO, VALOR_FATURADO, VALOR_SEM_IMPOSTO (:45-58).
- Grão interno: competência + documento cálculo + documento impressão + item ordenação (:99-103), mas DOCUMENTO_CALCULO/ITEM_ORDENACAO não são projetados; podem existir linhas visualmente semelhantes. Consumo e tributos internos não aparecem na saída.
- Filtros: lista explícita de 23 códigos de ordenação; FLAG C/R; competência exata (:84-90).
- Tributos intermediários usam MAX (:68-70). Cadastro por instalação é LEFT JOIN. O arquivo `script_ultrp_dem.py` é outra variante, não o selecionado pelo catálogo; preservar escolha consciente.
- Não há demanda contratada/medida ou quantidade de ultrapassagem projetada; não é possível calcular fator de ultrapassagem apenas com esta saída. Não chamar CONSUMO de kW/kWh sem dicionário de itens.

### 10 e 11. Encargos Covid e escassez hídrica

- SQL: `origem/relatorios/legado/RELATÓRIO ENCARGO COVID/script_encargo_covid.py:41`; `origem/relatorios/legado/RELATÓRIO ESCASSEZ HÍDRICA/script_escassez_hidric.py:41`.
- Fontes: ITENS_FATURAMENTO e FATURAMENTO; junção só por DOCUMENTO_IMPRESSAO (:53-55 em ambos), sem competência/documento cálculo. Não há GROUP BY ou deduplicação.
- Saída comum: ESTADO, MES_COMPETENCIA, MES_REFERENCIA, DOCUMENTO_IMPRESSAO, ESTORNADO, INSTALACAO, MWH, RECEITA, DATA_DADOS (:44-52). ESTADO recebe identificador da empresa, não necessariamente a sigla UF.
- Filtros: ITEM_DOCUMENTO=ZENCOV (Covid)/ZESCAS (escassez); seis meses completos anteriores ao CURRENT_DATE, ignorando MES_COMPET selecionado (:56-59). Em 05/11/2026 a janela corresponde a 202605..202610, independente do nome do arquivo.
- MWH=B.CONSUMO_FATURADO/1000 (:50) herda o consumo do cabeçalho por item, podendo repeti-lo. Validar que consumo original está em kWh e agregar consumo uma vez por chave completa do cabeçalho. RECEITA é do item, não do cabeçalho.
- Cada SQL insere **sempre** uma linha com zeros e documentos/instalação nulos via UNION ALL (:64-76 Covid; :64-75 escassez). Não usar COUNTROWS para faturas/UC; remover/marcar linhas artificiais antes de contagens. Não eliminar faturas genuínas de valor zero indiscriminadamente.
- DATA_DADOS Covid é horário de extração (CURRENT_TIMESTAMP); escassez usa B.DATA_DADOS, e a linha artificial tem NULL. Esses campos não são equivalentes como evidência de frescor da origem.

### 12. ICMS injetada

- SQL: `origem/relatorios/legado/RELATÓRIO ICMS INJETADA/script_relat_icms_injet.py:41`.
- Fontes: ITENS_FATURAMENTO A; autojunção a itens ZZ de código ZPGAT; FATURAMENTO B; TAB_PARCEIRO_NEGOCIO; TAB_CADASTRO (:67-110).
- Saída: EMPRESA, MES_COMPETENCIA, MES_REFERENCIA, DOCUMENTO_IMPRESSAO, DATA_EMISSAO, NUMERO_NF3E, CHAVE_ACESSO, NOME, ENDERECO, CPF_CNPJ, INSCRICAO_ESTADUAL, INSTALACAO, CONSUMO, RECEITA, TOTAL_INJET (:42-63).
- DATA_EMISSAO, NUMERO_NF3E e CHAVE_ACESSO são NULL fixos (:46-48), não lacunas cuja taxa de preenchimento represente qualidade do banco.
- Grão: combinação de competência/referência/documento/cliente/instalação e valor de consumo ZZ; GROUP BY também contém expressão de domicílio fiscal (:116-126), mas a saída EMPRESA não a inclui. DOCUMENTO_CALCULO não é projetado.
- Filtro final: competência exata, OPERACAO em 0100/0200/0300 e SUB_OPERACAO em 0016/0026/0010 (:112-114).
- CONSUMO soma cinco itens ZEG*; RECEITA soma os mesmos mais cinco ZTG* (:55-61); TOTAL_INJET vem do item ZPGAT (:63). Não há ICMS projetado apesar do nome do relatório.
- Riscos: múltiplos ZPGAT por documento+documento cálculo multiplicam as linhas A e suas somas (:88-89). TOTAL_INJET não é somado, é atributo do GROUP BY; não pode ser tratado como aditivo por linha sem regra. Cadastro/PN podem multiplicar. Pré-agregar cada origem no mesmo grão de documento é a correção a avaliar.

### 13. Isenção ICMS TUSD

- SQL: `origem/relatorios/legado/RELATORIO ISENÇÃO ICMS TUSD/script_isen_icms_tusd.py:43`.
- Fontes: ITENS_FATURAMENTO, SIGLA_MUNICIPIOS, FATURAMENTO, TAB_CADASTRO (:68-78).
- Saída: EMPRESA, MES_COMPETENCIA, MES_REFERENCIA, MUNICIPIO, INSTALACAO, CONTA_CONTRATO, NOME, CPF, CNPJ, GRUPO, TARIFA, CLASSE, REDUCAO, ICMS, VALOR_FATURA (:87-101).
- Grão: atributos listados, incluindo VALOR_FATURA no GROUP BY, sem documento cálculo/impressão (:103-116). Faturas distintas com mesmo conjunto podem ser agregadas.
- Filtros: OPERACAO='0153'; três meses completos anteriores ao CURRENT_DATE (:81-84), sem respeitar MES_COMPET. Em 05/11/2026 usa 202608..202610.
- REDUCAO=SUM(A.RECEITA); ICMS=SUM(C.ICMS) do cabeçalho; VALOR_FATURA não é somado (:64-66,99-101). Vários itens 0153 por fatura repetem ICMS; somar valor de fatura entre linhas também exige grão de fatura que a saída suprimiu.
- Junção cabeçalho apenas por DOCUMENTO_IMPRESSAO; município por substring fiscal; cadastro por instalação+conta (:70-78). Classe é regra explícita residencial/comercial/outros (:58-62), diferente da dimensão completa de subclasses em outros relatórios.

### 14. Financiamento padrão

- SQL: `origem/relatorios/legado/RELATÓRIOS FINANCIAMENTO PADRAO/script_finan_padrao.py:41`.
- Fontes: FINPAD_NOTAS DOC + ITENS_FINANCEIRO SUB; junção apenas por NUMERO_DOCUMENTO (:88-90).
- Colunas DOC projetadas: NOTA, MANDANTE, INSTALACAO, CONTA_CONTRATO, PARCEIRO_NEGOCIO, PEP_ODS, TIPO, DATA_CADASTRO, NUMERO_DOCUMENTO, CANCELAMENTO, DATA_CANC, ORGANIZACAO_VENDAS, NOME, SOBRENOME, NR_ID_FISCAL, MONTANTE, TIPO_DOC_VENDAS, QTD_ORDEM, STATUS_INTERFACE, ALTERADO_POR, MATERIAL, RUA, ENDERECO_EMAIL, CODIGO_POSTAL, NUMERO, CIDADE, PAIS, MOEDA, CRIADO_POR, NUMERO_NFSE, DATA_ENTRADA, CENTRO_LUCRO, REGIAO, COD_DOMI_FISCAL, DOCUMENTO_VENDAS, NR_NOTA_FISCAL; adiciona EMPRESA, STATUS_FINANCIAMENTO_FAT, QTD_PARCELAS, MONTANTE_COMPENSACAO (:43-87).
- Filtros: TIPO_DOC_VENDAS='ZPAD'; mês DATA_ENTRADA='{MES}' (:91-92), não competência de faturamento.
- Grão: atributos DOC + status derivado do item financeiro; itens mistos ativos/inativos podem dividir a mesma nota em mais de uma linha. MONTANTE é atributo DOC, não soma (:59,80-93).
- Status: INATIVO quando STATUS_COMPENSACAO='9' e MOTIVO_COMPENSACAO='05'; demais casos ATIVO (:80-85).
- QTD_PARCELAS=COUNT(SUB.TEXTO_ITEM), não contagem distinta de identificador de parcela (:86). MONTANTE_COMPENSACAO=SUM; valores nulos não são contados. Não inferir inadimplência, saldo devedor ou parcelas restantes com essas colunas sem regras adicionais. MOEDA deve compor agregações de valores até confirmar moeda única.

### 15. Consumo próprio

- SQL: `origem/relatorios/legado/RELATÓRIOS CONSUMO PRÓPRIO/script_consum_proprio.py:47`.
- Fontes: FATURAMENTO, FOTO_CADASTRO, TAB_OPERANDOS_MEDICAO, ITENS_FATURAMENTO em CTE BASE_ICMS, TAB_PARCEIRO_NEGOCIO (:48-59,108-122).
- Saída: EMPRESA, CNPJ_OU_CPF, RAZAO_SOCIAL, INSTALACAO, CONTA_CONTRATO, NUMERO, PARCEIRO_NEGOCIO, TIPO_CALCULO, TIPO_FATURAMENTO, COD_TP_FAT, FATURA, CONTRATO, DOCUMENTO_IMPRESSAO, TIPO_SISTEMA, CLASSE_CONSUMO, REGIONAL, DISTRITAL, SECCIONAL, MUNICIPIO, LOCALIDADE, ENDERECO, BAIRRO, NUMERO, COMPLEMENTO, COMPLEMENTO2, COMPETENCIA, SITUACAO_DOCUMENTO, CLASSE_PRINCIPAL, CDC, BC_ICMS, ICMS_TOTAL, VALOR_TOTAL, CONSUMO_FATURADO (:61-107).
- Atenção: NUMERO é projetado duas vezes: SUBSTR(A.FATURA,8) AS NUMERO (:66) e B.NUMERO de endereço (:93). Nome duplicado deve ser resolvido antes do modelo; não usar posição/renomeação implícita.
- Grão pretendido: cabeçalho de faturamento por documentos, sem agregação externa. Documento cálculo não é projetado. Cadastro foto é relacionado por instalação e mês referência; operandos por instalação e intervalo de validade (:109-120).
- Filtros: competência exata; TIPO_CALCULO CP/CF; SUBCLASSE prefixo CP; ESTORNO_PLENO IS NULL (:124-127).
- BC_ICMS agrega BASE_IMPOSTO de itens MW2 e FLAG R por documento impressão+cálculo (:48-59). CTE não filtra competência; confirmar unicidade do par de documentos na origem. SISTEMA_ISOLADO depende da existência de operando válido FL_ISOLADO, com interligado como ELSE (:80-84).
- Empresa vem de B.EMPRESA, não literal (:61); ausência de FOTO_CADASTRO produz empresa nula. Intervalos de operandos sobrepostos e fotos duplicadas multiplicam cabeçalhos. CPF/CNPJ/endereço são atributos pessoais: uso no painel depende da necessidade do usuário final.

### 16. Retenção de tributos

- SQL: `origem/relatorios/legado/RELATORIOS RETENÇÃO DE TRIBUTOS/script_reten_tribut.py:47`.
- Fonte: SB_FATURAMENTO.{SCHEMA}.BASE_IMPOSTO_RETIDO; filtro MES_COMPETENCIA='{MES_COMPET}' (:48-50).
- SELECT *: grão, colunas financeiras, tributos e identificadores não podem ser reconstruídos pelo código. Não inventar ICMS/PIS/COFINS/IRRF/ISS ou total de retenções sem esquema real. A SQL não acrescenta EMPRESA; no arquivo ela pode ser inferida da aba/arquivo, mas isso precisa ser materializado ao combinar.

## Chaves e unidades para o modelo

1. Identificadores como INSTALACAO, CONTA_CONTRATO, CONTRATO, DOCUMENTO_IMPRESSAO, DOCUMENTO_CALCULO, CPF/CNPJ e códigos são textos, preservando zeros. Empresa deve compor as chaves porque identificadores podem se repetir entre schemas.
2. Candidato de chave de cabeçalho: empresa + competência + documento impressão + documento cálculo, refletindo junções robustas dos relatórios (:94-96 cativos). Chave de item precisa também de LINHA ou outro identificador estável validado, e possivelmente item/tributo/flag conforme fonte. Não declarar as combinações únicas sem testar.
3. MES_COMPETENCIA, MES_REFERENCIA, REFERENCIA, MES_LANCAMENTO, MES/MES_ORIGEM_CREDITO e DATA_ENTRADA têm semânticas diferentes. Use dimensão de mês/data com papéis explícitos; não relacionar todas automaticamente ao mesmo campo ativo. YYYYMM deve virar data de primeiro dia do mês e manter chave texto/número ordenável.
4. RECEITA, VALOR_FATURADO, VALOR_TOTAL, REDUCAO e MONTANTE não têm declaração de moeda nos SQL, exceto presença de MOEDA em financiamento. Confirmar BRL antes de rotular R$. Preservar sinais de estorno/crédito.
5. MMGD declara KWH e encargos declaram MWH por divisão de consumo/1000. Outras colunas CONSUMO/QUANTIDADE não demonstram unidade universal. Reativos/demanda podem representar grandezas diferentes por código de item; não somar todas como energia.
6. Fotografias de saldo bloqueado e possíveis saldos MMGD são semiaditivos no tempo. Definir saldo de fechamento, movimento e referência de extração antes de DAX. KWh de crédito por mês não demonstra geração efetiva ou energia compensada.
7. DAX não corrige multiplicação já ocorrida na SQL. Corrigir grão/joins na extração e conciliar somas antes/depois; DISTINCT de todas as colunas pode tanto manter multiplicações com atributos diferentes quanto apagar transações legítimas.

## Requisitos de validação antes de publicar medidas

- Obter esquema real/metadata de RESUMO_FAT_TRIBUTOS e BASE_IMPOSTO_RETIDO, mais amostras sem dados pessoais; confirmar tipos, nulos e grão.
- Para cada JOIN, comparar número de linhas e soma de valores antes/depois por chave; testar unicidade de dimensões e documentar versões/vigências.
- Conciliar cativos/livres com resumo por empresa+competência e definições de tributo; não usar todos como fatos financeiros aditivos entre si. Relatórios temáticos são recortes sobrepostos, não componentes de um total geral.
- Conferir FLAG C/R e regras de estorno/estornado/pleno por família, já que não são uniformes.
- Parametrizar explicitamente data de corte de encargos/isenção para que competência selecionada e histórico sejam reproduzíveis. Separar data de extração de data de atualização da origem.
- Remover ou marcar linhas artificiais, resolver nomes duplicados, padronizar EMPRESA/ESTADO/COMPETENCIA e carregar números como números.

## Variantes RS/AP

| Variante | Diferença observada e evidência relativa a `origem/relatorios/legado` |
|---|---|
| Desconto RS | Acrescenta ITEM_ORDENACAO ZBIL à lista: `RELATORIOS DESCONTO TARIFÁRIO/script_relat_desc_tarif_rs.py:84`. |
| Cativos RS | Exclui documento impressão 500000002466 no filtro e depois da junção: `RELATÓRIO CLIENTES CATIVOS/script_relat_client_cat_rs.py:99` e `:120`. Não consta no principal. |
| Reativos RS | Usa MAX de ICMS/PIS/COFINS na segunda agregação, enquanto principal usa SUM: `RELATÓRIOS REATIVOS EXCEDENTE/script_relat_reativo_rs.py:69` e `script_relat_reativo.py:69`. Exclui mesmo documento em `:95` e `:118`. |
| MMGD RS consolidado | Fonte RAW.CCS_RS.EENRGY_CR_BR; MES=SUBSTR(ALLOC_DATE,1,6); energia=SUM(QUANT): `RELATÓRIOS MMGD/mmgd_rs.py:44`. Principal usa SB_FATURAMENTO.BASE_MMGD_CREDITOS/MES/KWH. O literal EMPRESA resulta CCS_RS, não EQTL_RS, devido ao dicionário `mmgd_rs.py:15`. |
| Base MMGD RS | Fonte RAW; usa GEN_CONTRACT e TAB_CONTRATO agrupada por contrato com MAX(CONTA_CONTRATO); grão mês alocação+contrato+conta, sem MES_COMPETENCIA: `RELATÓRIOS MMGD/base_mmgd_rs.py:45-63`. Principal preserva MES_COMPETENCIA. KWH também é texto com vírgula em `:46`. MAX da conta escolhe um valor, não demonstra vínculo histórico correto. |
| Arquivo Retenção AP | Nome não reflete escopo ativo: AP comentado e RS ativo em `RELATORIOS RETENÇÃO DE TRIBUTOS/script_reten_tribut_ap.py:14-15`. SQL igual ao principal em `:48`. |

SQLs equivalentes após normalizar espaços: Isenção ICMS TUSD, Saldo Bloqueado, Covid, Escassez Hídrica, ICMS Injetada, Clientes Livres, Consumo Próprio, Financiamento Padrão, Modicidade e Resumo Faturamento. Os três SQLs de Ultrapassagem (antigo, mudado e RS) também são equivalentes; mudam dicionários de empresa, competência fixa e destino.

Principais já incluem seis empresas, salvo dicionários originais de Ultrapassagem antigo/mudado que omitem RS. Anexar saída principal a saídas RS sem conferir escopo pode duplicar dados. Competências padrão são diferentes entre arquivos, em geral principais 202608, RS 202606 e MMGD RS 202607; o adaptador substitui competência no desktop, mas isso não reescreve SQLs baseados em CURRENT_DATE.

O catálogo desktop usa apenas módulos principais para todas as distribuidoras e o adaptador muda competência/distribuidoras, sem rotear automaticamente para variantes (`origem/app/report_registry.py:50-65`; `origem/app/legacy_adapter.py:80-88`,`:112`). A opção de separar RS divide requisições/caminhos, preservando a mesma definição de módulo (`origem/app/report_runner.py:72-103`). Portanto, selecionar RS não aplica as regras de Desconto, Cativos, Reativos e MMGD RS acima. Para Power BI, a regra por empresa deve ser explicitada antes de unificar as extrações.
