# Power BI — Contabilidade e Financeiro

Análise do arquivo **RelatoriosDesktop-auditoria-status-exportacao.zip**, em 05/11/2026.

**Entrega: projeto de modelo e painel, com SQL, Power Query e DAX em rascunho.** Não é um arquivo PBIX/PBIP executado. Foram analisados código e consultas; não foram fornecidos dados extraídos nem acesso autenticado ao Snowflake. Não há resultados financeiros calculados, refresh validado ou publicação.

## O que o projeto permite construir

O aplicativo PySide6 é um executor e exportador de **16 famílias**, organizadas em **9 de Contabilidade e 7 de Tributário**, para **MA, PA, PI, AL, AP e RS**. O painel proposto reúne contabilidade e financeiro, conforme solicitado, preservando os recortes tributários que fazem parte desses relatórios.

O núcleo será o valor faturado dos mercados cativo e livre, com tributos e comparações mensais. Descontos, modicidade, reativos, demanda, financiamento, consumo próprio e MMGD serão analisados em fatos e páginas específicas. **Não há um total que some todos os relatórios:** várias famílias são recortes do mesmo faturamento.

## Arquivos para usar

| Material | Conteúdo |
|---|---|
| [01_analise_e_insights.md](01_analise_e_insights.md) | Achados do código, indicadores e perguntas de negócio por relatório |
| [02_modelo_e_relacionamentos.md](02_modelo_e_relacionamentos.md) | Grãos, dimensões, relações, regras temporais e contratos |
| [relacionamentos.csv](relacionamentos.csv) | Mapa de relações a configurar no Desktop, com fatos ainda condicionais identificadas |
| [03_paginas_e_visuais.md](03_paginas_e_visuais.md) | Oito páginas, medidas, campos e comportamento dos visuais |
| [visuais/pagina_executiva.svg](visuais/pagina_executiva.svg) | Desenho da primeira página, sem dados fictícios |
| [04_implantacao_e_validacao.md](04_implantacao_e_validacao.md) | Ordem de implantação, reconciliação e pendências |
| [05_auditoria_operacional.md](05_auditoria_operacional.md) | Apêndice opcional sobre histórico de execuções |
| [06_inventario_sql_detalhado.md](06_inventario_sql_detalhado.md) | Evidências por arquivo/linha, fontes, filtros e variantes RS/AP |
| sql/originais/ | 16 SQLs ativos e uma base auxiliar MMGD, extraídos sem executar os módulos |
| sql/variantes/ | Consultas das variantes adicionais; não devem ser anexadas automaticamente às principais |
| sql/modelo/ | 15 rascunhos SQL: normalização, separação de grãos e diagnósticos de leitura |
| power_query/ | Função parametrizada Snowflake e exemplo de carga do núcleo de faturamento |
| dax/ | Dimensões calculadas e medidas financeiras propostas, com dependências documentadas |
| visuais/tema_contabilidade.json | Tema visual para importar no Power BI |
| validacao_estatica.json | Resultado das verificações locais; não substitui executar no Snowflake/Desktop |

## Decisões do desenho

- **Modelo estrela com múltiplas fatos**, em vez de uma tabela única de relatórios: conserva unidades e granularidades.
- **Import como ponto de partida**, assumido para validação mensal; DirectQuery só após avaliar volume, latência e governança.
- Consultas normalizadas de cativos/livres ficam agregadas no conjunto de dimensões comuns. O staging conserva os detalhes próprios de cada fonte. Não há contagem de clientes totais nem drill-through de cativos até a fatura.
- Descrições/classes originais permanecem distintas até haver um mapa homologado. `CLASSE` de livres não equivale automaticamente a `CLASSE_PRINCIPAL` de cativos.
- Valores financeiros usam sinal original. Moeda BRL é hipótese a confirmar antes de formatar como R$; financiamento mantém `MOEDA`.
- Toda diferença entre SQL adaptado e original é proposta para revisão, não alteração aplicada ao aplicativo.

## O que falta para executar o painel

1. Metadados/amostras de `BASE_IMPOSTO_RETIDO` e `RESUMO_FAT_TRIBUTOS`, cujas consultas usam `SELECT *`.
2. Confirmação das regras RS, sinais, unidades, chaves e vigências cadastrais.
3. Conexão Snowflake aprovada no Power BI Desktop e execução das validações por empresa/mês.
4. PBIP salvo no Desktop, aplicação das medidas e relações, conferência visual e reconciliação. Não há Power BI Desktop ou PowerShell disponível nesta sessão; o gerador PowerShell mencionado na skill não pôde ser executado. O pacote foi preparado como desenho e arquivos-texto revisáveis.

Nenhuma senha, credencial ou identificação pessoal do código-fonte foi copiada para o pacote. O projeto original e o repositório Git não foram alterados.
