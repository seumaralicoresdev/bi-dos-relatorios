# Apêndice — Auditoria operacional das execuções

## Finalidade e prioridade

Este desenho é um apêndice para acompanhar a execução do gerador desktop. A prioridade da conversão para Power BI continua sendo o modelo financeiro e tributário derivado das consultas, dos seus grãos e das regras de negócio. O histórico do aplicativo contém metadados de processamento; não contém os montantes financeiros dos relatórios e não deve ser usado para calcular faturamento, tributos, créditos ou saldos.

O apêndice permite monitorar tentativas, falhas, cancelamentos, duração e volume dos arquivos. Sua implantação é opcional e pode ocorrer após a validação do modelo principal. Não há métricas apuradas neste documento: as fórmulas e indicadores são propostas de definição, sem valores numéricos inventados.

Análise exclusivamente estática da origem. Não foram executados Python, testes, consultas ou conexões. Os testes citados representam contratos encontrados no código, sem alegação de aprovação nesta análise.

## Fonte disponível e grão real

O aplicativo persiste um arquivo `history.json` junto dos dados do usuário, no mesmo diretório do `settings.json`. Cada elemento do array principal representa um lote; cada elemento de `results[]` representa uma família de relatório processada nesse lote. As distribuidoras são uma seleção do lote, não uma dimensão registrada individualmente em cada resultado.

Evidências: [localização do histórico](/workspace/analise_relatorios/origem/ui/main_window.py:216), [diretório de dados do usuário](/workspace/analise_relatorios/origem/app/settings.py:21), [persistência do lote](/workspace/analise_relatorios/origem/app/history.py:36), [campos do resultado](/workspace/analise_relatorios/origem/app/models.py:32).

| Nível | Campos existentes |
|---|---|
| Lote | `started_at`, `finished_at`, `duration_seconds`, `cancelled`, `competencia`, `report_ids[]`, `distribuidoras[]`, `output_root`, `active_destination`, `separate_rs`, `execution_error`, `results[]` |
| Resultado | `report_id`, `report_name`, `category`, `competencia`, `status`, `output_path`, `duration_seconds`, `rows`, `sheets[]`, `message`, `error` |

O histórico não fornece identificador estável de lote, usuário, máquina, versão da consulta por execução, identificador de consulta Snowflake, início/fim individual persistido, resultados por distribuidora ou inventário estruturado de todos os arquivos gerados. Essas ausências limitam atribuição de desempenho, rastreabilidade e comparação entre ambientes.

## Modelo proposto: duas fatos

### FatoLote

**Grão:** uma tentativa de execução registrada no array principal do histórico, inclusive uma falha ocorrida antes do primeiro relatório.

| Campo proposto | Origem ou regra |
|---|---|
| `LoteKey` | Chave técnica criada na ingestão; ausente na origem |
| `FonteHistoricoKey` | Identifica o arquivo/dispositivo de origem, quando disponível |
| `OrdemRegistroOrigem` | Posição do registro no arquivo; preservar durante a ingestão |
| `CompetenciaKey` | `competencia`, convertida em chave mensal validada |
| `DataInicioKey`, `InicioLocal`, `FimLocal` | `started_at`, `finished_at`; fuso não informado na origem |
| `DuracaoLoteSegundos` | `duration_seconds` do lote |
| `Cancelado` | `cancelled` |
| `Destino` | `active_destination` |
| `SepararRS` | `separate_rs` |
| `PastaSaida` | `output_root` |
| `ErroExecucao` | `execution_error` |
| `StatusLote` | Reproduzir a precedência da função `summarize_batch` |
| `QtdRelatoriosSolicitados` | Quantidade de IDs em `report_ids[]` |
| `QtdRelatoriosProcessados` | Quantidade de elementos em `results[]` |
| `QtdDistribuidorasSelecionadas` | Quantidade de elementos em `distribuidoras[]` |

A chave deve permanecer estável entre atualizações. Uma estratégia inicial para uma fonte local é combinar identificação estável da fonte com a posição preservada do registro, desde que o arquivo continue apenas acrescentando registros. Se forem coletadas cópias/snapshots do mesmo histórico, é necessário um manifesto de ingestão para não carregar os mesmos lotes novamente. Timestamp em segundos e caminho de arquivo não são chaves únicas confiáveis.

Falhas antes do primeiro relatório são persistidas com `results=[]` e `execution_error`. Não as descartar por falta de registros filhos. Evidências: [gravação da falha do worker](/workspace/analise_relatorios/origem/ui/main_window.py:681), [teste que documenta a falha anterior ao primeiro relatório](/workspace/analise_relatorios/origem/tests/test_history.py:43).

### FatoExecucaoRelatorio

**Grão:** um elemento de `results[]`, isto é, uma família de relatório processada em um lote, abrangendo o conjunto de distribuidoras selecionadas.

| Campo proposto | Origem ou regra |
|---|---|
| `ExecucaoRelatorioKey` | Chave técnica, por exemplo `LoteKey` + posição do resultado |
| `LoteKey` | Herdada do registro pai |
| `RelatorioKey` | `report_id`; enriquecer nome e categoria pelo catálogo |
| `CompetenciaKey` | `competencia` do resultado, validada contra a do lote |
| `DataInicioLoteKey` | Herdada do lote, para filtro de data de execução; não é início individual |
| `StatusResultado` | `status`: `success`, `warning` ou `failed` |
| `DuracaoRelatorioSegundos` | `duration_seconds` do resultado |
| `LinhasArquivo` | `rows`, preservando nulos |
| `ContagemLinhasDisponivel` | Indica se `rows` foi identificado |
| `PrimeiroCaminhoSaida` | `output_path`; pode representar somente parte dos artefatos |
| `AbasInformadas` | `sheets[]`, mantidas como informação auxiliar, sem expandir o grão da fato |
| `Mensagem`, `Erro` | `message`, `error` |

Não incluir uma `DistribuidoraKey` individual artificial nesta fato. Expandir o array de distribuidoras sobre cada resultado repetiria a duração e as linhas de uma execução conjunta, produzindo atribuições incorretas por empresa.

Evidências: [estrutura do resultado](/workspace/analise_relatorios/origem/app/models.py:32), [execução por família](/workspace/analise_relatorios/origem/app/batch.py:62), [agregação das saídas de uma família](/workspace/analise_relatorios/origem/app/report_runner.py:50).

## Pontes e relacionamentos

Criar `DimLote` com uma linha por `LoteKey`, `DimRelatorio`, `DimDistribuidora`, `DimCompetencia`, `DimDataExecucao`, `DimStatusLote` e `DimStatusResultado`. A separação dos status evita equiparar cancelamento do lote com falha de um relatório já processado.

### PonteLoteDistribuidora

**Grão:** uma combinação distinta de `LoteKey` e distribuidora selecionada em `distribuidoras[]`.

O vínculo significa **“a distribuidora estava selecionada no lote”**. Não significa que cada consulta dessa empresa foi concluída, que o arquivo contém dados dessa empresa, nem que o volume e a duração do lote pertencem exclusivamente a ela. O histórico não oferece essas evidências individuais.

Um filtro `EQTL_MA` pode selecionar “execuções de relatórios em lotes que incluíram MA”. Deve usar esse título explícito; não deve apresentar as mesmas medidas como “tempo de processamento de MA” ou “linhas de MA”. Lotes com várias empresas aparecem em mais de uma seleção; portanto os subtotais por empresa não são aditivos.

### PonteLoteRelatorioSolicitado

**Grão:** uma combinação distinta de `LoteKey` e `report_id` presente em `report_ids[]`.

Permite comparar solicitação e processamento, pois relatórios não iniciados por cancelamento não aparecem em `results[]`. Um item solicitado sem resultado deve ser denominado “não processado/sem resultado registrado”, sem criar um resultado financeiro ou imputar duração zero como se tivesse ocorrido processamento.

O cancelamento é verificado antes da próxima família; não interrompe imediatamente a consulta atual. Evidências: [checagem de cancelamento](/workspace/analise_relatorios/origem/app/batch.py:62), [flag final de cancelamento](/workspace/analise_relatorios/origem/app/batch.py:92), [explicação operacional](/workspace/analise_relatorios/origem/docs/operator-guide.md:35).

### Relações sugeridas

| Origem | Destino | Cardinalidade e filtro |
|---|---|---|
| `DimLote` | `FatoLote` | 1:1 lógica; configurar a fato no lado muitos se necessário, com unicidade verificada e filtro simples dimensão → fato |
| `DimLote` | `FatoExecucaoRelatorio` | 1:*; filtro simples dimensão → fato |
| `DimLote` | Cada ponte | 1:*; filtro simples dimensão → ponte |
| `DimDistribuidora` | `PonteLoteDistribuidora` | 1:*; filtro simples dimensão → ponte |
| `DimRelatorio` | `FatoExecucaoRelatorio` e `PonteLoteRelatorioSolicitado` | 1:*; filtros simples |
| `DimCompetencia` | Ambas as fatos | 1:*; filtros simples |
| `DimDataExecucao` | Ambas as fatos | 1:*; usar data de início do lote, herdada pela fato de resultados |
| `DimStatusLote` | `FatoLote` | 1:*; filtro simples |
| `DimStatusResultado` | `FatoExecucaoRelatorio` | 1:*; filtro simples |

Não ligar diretamente as duas fatos entre si, nem relacioná-las por caminho de arquivo. Nas relações acima, a seleção de distribuidora filtra a ponte, mas não volta automaticamente até `DimLote`. As medidas de “lotes que incluíram a distribuidora” devem aplicar o conjunto distinto de `LoteKey` da ponte ao contexto do lote, por exemplo com `TREATAS`. Aplicar o mesmo princípio ao calcular lotes que solicitaram um relatório. Isso mantém a intenção do filtro explícita e evita relações bidirecionais generalizadas ou caminhos ambíguos.

Medidas de duração e de quantidade de resultados continuam respeitando seu grão mesmo quando recebem esse filtro de pertencimento. Uma fato financeira por distribuidora não deve receber duração da família como se ela tivesse sido observada individualmente.

## Status e KPIs permitidos

O status consolidado do lote respeita esta ordem: `execution_error` → `cancelled` → nenhum resultado → resultado falho → resultado com alerta → sucesso. Um lote cancelado pode conter resultados já concluídos ou falhos; conservar ambos os níveis. Evidência: [precedência do resumo](/workspace/analise_relatorios/origem/app/audit.py:55).

| Indicador proposto | Definição | Limite de interpretação |
|---|---|---|
| Lotes registrados | Contagem de `FatoLote` | Abrange apenas históricos efetivamente coletados; não mede todos os usuários sem coleta centralizada |
| Falhas antes do primeiro relatório | Lotes com `execution_error` preenchido e sem resultados | Separar de falhas de uma família |
| Relatórios solicitados | Contagem da ponte de solicitações | Verificar integridade dos IDs com o catálogo |
| Relatórios processados | Contagem de `FatoExecucaoRelatorio` | Não equivale a consultas por distribuidora |
| Concluídos / alertas / falhos | Contagem dos resultados em cada status | Sucesso operacional não comprova validade financeira |
| Taxa de conclusão dos processados | Resultados `success` / resultados processados | Denominador zero deve resultar em vazio; cancelamentos podem retirar relatórios do denominador |
| Cobertura bem-sucedida do solicitado | Resultados `success` / relatórios solicitados | Complementa a taxa anterior, incorporando relatórios solicitados sem processamento |
| Não processados | Solicitações sem resultado correspondente no mesmo lote | Não classificar automaticamente como falha ou cancelamento individual |
| Duração por lote e família | Média, mediana ou percentil das respectivas durações | Comparar escopos equivalentes de empresas, competência e separação RS |
| Volume de linhas dos arquivos | Soma de `rows` conhecido, acompanhada da cobertura da contagem | Não equivale a clientes, faturas, UCs, documentos ou valores monetários |
| Última execução com sucesso | Maior início de lote entre resultados `success`, por família e competência | Não mede atualização real do dado no Snowflake nem completude por empresa |
| Resultados com caminho registrado | Contagem de resultados com `output_path` preenchido | Não chamar de quantidade de arquivos físicos gerados |

Não definir SLA, metas, limites de anomalia ou baseline histórico sem dados reais e decisão de negócio. Tampouco criar KPI financeiro a partir de linhas ou status do gerador.

## Limitações de auditoria que afetam a leitura dos KPIs

1. **Sucesso significa existência do arquivo esperado.** Após executar o módulo, o adapter verifica `is_file()`. Não verifica atualização do arquivo, reconciliação financeira ou sucesso individual de todas as distribuidoras. Como o caminho depende de competência e relatório, um arquivo antigo pode permanecer no destino; sua mera existência não atesta geração na tentativa atual. Evidências: [verificação do artefato](/workspace/analise_relatorios/origem/app/legacy_adapter.py:123), [caminho determinístico](/workspace/analise_relatorios/origem/app/path_builder.py:28), [atribuição de sucesso](/workspace/analise_relatorios/origem/app/report_runner.py:133).

2. **Quantidade de linhas é metadado do arquivo.** Para Excel, soma `max_row - 1` em todas as abas. Para CSV, conta linhas físicas menos cabeçalho. Abas podem ter grãos distintos; CSV pode conter conteúdo com quebras de linha. Uma falha de inspeção mantém sucesso com linhas nulas. Evidências: [contagem Excel e CSV](/workspace/analise_relatorios/origem/app/result_inspector.py:17), [inspeção não invalida geração](/workspace/analise_relatorios/origem/app/report_runner.py:124).

3. **RS pode produzir mais de um arquivo para um único resultado.** O runner soma linhas e abas das saídas, mas persiste somente o primeiro `output_path`; os demais caminhos ficam no texto da mensagem. O export atual calcula “Arquivos gerados” contando resultados com caminho, subcontando esse caso. Não reconstruir uma fato de artefatos apenas pelo primeiro caminho. Evidências: [separação do escopo RS](/workspace/analise_relatorios/origem/app/report_runner.py:74), [mensagem e primeiro caminho](/workspace/analise_relatorios/origem/app/report_runner.py:119), [contador do export](/workspace/analise_relatorios/origem/app/audit.py:179).

4. **Separação RS não seleciona os módulos legados `*_rs.py`.** O runner usa a mesma definição nos dois escopos. Os módulos principais estão no catálogo, e a opção altera seleção e destino. Não presumir equivalência entre variantes legadas sem comparação das consultas. Evidências: [catálogo principal](/workspace/analise_relatorios/origem/app/report_registry.py:50), [reutilização da definição](/workspace/analise_relatorios/origem/app/report_runner.py:101).

5. **Bases auxiliares MMGD não têm inventário completo no resultado.** O runner executa o módulo de apoio, mas não verifica seu retorno nem registra seus arquivos como artefatos independentes. Evidências: [definição MMGD](/workspace/analise_relatorios/origem/app/report_registry.py:55), [execução auxiliar](/workspace/analise_relatorios/origem/app/report_runner.py:40).

6. **Durações não têm o mesmo alcance.** A duração total inclui preparo de autenticação e etapas de callback; a duração do relatório é obtida antes da inspeção de linhas. Não tratar diferença entre soma individual e total como erro aritmético. Evidências: [início do lote e bootstrap](/workspace/analise_relatorios/origem/app/batch.py:50), [fim do lote](/workspace/analise_relatorios/origem/app/batch.py:85), [duração antes da inspeção](/workspace/analise_relatorios/origem/app/report_runner.py:119).

7. **Horários não informam fuso.** A persistência usa `datetime.now()` e ISO com precisão de segundos. Definir fuso de coleta e conversão antes de juntar dispositivos ou comparar com refresh do Power BI. Evidência: [timestamps persistidos](/workspace/analise_relatorios/origem/app/batch.py:86).

8. **Histórico vazio não comprova ausência de execuções.** Arquivo ausente, JSON inválido ou erro de leitura retornam lista vazia. Na coleta analítica, distinguir indisponibilidade/corrupção de uma fonte lida com sucesso e sem registros. Evidência: [tratamento de leitura](/workspace/analise_relatorios/origem/app/history.py:14).

9. **O Excel/CSV do histórico é menos completo que o JSON.** Exporta uma linha por lote com contadores e listas, sem todos os resultados filhos. A tela mostra somente os últimos vinte registros, mas o botão exporta os registros carregados integralmente. Preferir ingestão do JSON para estas duas fatos. Evidências: [colunas do export histórico](/workspace/analise_relatorios/origem/app/audit.py:155), [linhas agregadas](/workspace/analise_relatorios/origem/app/audit.py:173), [limite apenas visual](/workspace/analise_relatorios/origem/ui/main_window.py:707), [exportação completa](/workspace/analise_relatorios/origem/ui/main_window.py:759).

10. **O aplicativo não estabelece a autenticação do refresh agendado.** Usa bootstrap de SSO interativo com `externalbrowser` e conexões independentes por worker. A atualização no Power BI Service exige desenho próprio de credenciais e infraestrutura; não inferir funcionamento pelo login desktop. Evidências: [configuração Snowflake](/workspace/analise_relatorios/origem/app/snowflake_session.py:45), [preparo e conexões](/workspace/analise_relatorios/origem/app/snowflake_session.py:104).

## Controles antes de publicar este apêndice

- Validar unicidade de `LoteKey` e `ExecucaoRelatorioKey`, inclusive quando houver snapshots do mesmo histórico.
- Conferir integridade de `report_id`, competência do lote versus resultado e datas/durações interpretáveis.
- Preservar registros com erro sem filhos, e nulos de linhas sem convertê-los em zero.
- Testar medidas com lote contendo várias distribuidoras, cancelamento parcial e separação RS; os testes devem avaliar a semântica dos filtros e não alegar métricas individuais inexistentes.
- Exibir cobertura de coleta: fontes incluídas, intervalo observado e data da última ingestão. Não extrapolar o arquivo local para toda a organização.

Para futura rastreabilidade por distribuidora ou artefato será necessária instrumentação adicional na origem, fora deste desenho opcional: identificadores estáveis, versão da consulta, horário e status por distribuidora, e lista de arquivos com tamanho/data/hash. Esses campos não podem ser inferidos com segurança dos dados existentes.
